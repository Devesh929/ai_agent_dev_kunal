This **Post-Modelling Module** is designed for in-depth analysis following both univariate and multivariate forecasting. It provides a comprehensive suite of post-modelling approaches to **confirm model fit** and deliver an **extensive overview of actual data versus predictions**. 
Notably, it uses the same output paths as the core modelling processes.

###Purpose

The purpose of this documentation is to provide a comprehensive guide to the post-modelling approaches and code, detailing **what each approach does**, **how to use it**, and **when it's most appropriate** to apply for effective model validation and insight generation.




###Architecture
Post Modelling takes modeling output as input and outputs post modeled results of all models in an experiment.

### Code Folder Structure

    forecasting/ post_modelling_analysis/

    ├── logger.py
    ├── analysis_store.py
    ├── analysis_visualize.py     
    ├── main.py             
    ├── config.json
    ├── visualize.ipynb


### Codebase Files
The Post-Modelling Module is organized into the following key Python files:
1.  `Logger.py`:  
Responsible for directing console output to both the terminal and a persistent log file, capturing all informational messages, warnings, and errors during execution.
        
2.  `analysis_store.py`:  
    Contains the core logic of the Post-Modelling Module. This file houses all the essential classes and methods responsible for data reading, processing, and performing various post-modelling analyses. It serves as the backend engine for all analytical operations. **This _store file is the one that will be used when we want to store the outputs in blob.**

3.  `analysis_visualize.py`:  
    Contains the core logic of the Post-Modelling Module. This file houses all the essential classes and methods responsible for data reading, processing, and performing various post-modelling analyses. It serves as the backend engine for all analytical operations. **This _visualize file is the one that will be used when we want to use ipynb to visualize the results.**
        
4.  ` main.py`:  
    Acts as the primary execution script for post-modelling workflows. This file imports and calls the necessary classes and methods from `analysis_store.py` to run comprehensive analyses. It is used when the objective is to store the results persistently or use terminal.
        
4.  `config.json`:  
    Serves as the configuration for the module. This file allows users to define and customize parameters and settings, such as experiment names, modelling levels, sheet names, and data paths, which are utilized by `main_oops.py` during execution.
        
5.  `visualize.ipynb`:  
    Provides an interactive environment, a Jupyter notebook, for visualizing post-modelling outputs. This file is designed for **exploratory data analysis and ad-hoc visualization**, offering a quick way to inspect model results without the need to store processed outputs.

# Class and Methods

This module consists of following classes.

1. CommonFunctions
2. DataReading
3. ResidualAnalyzer
4. Plotter
5. VarianceAnalyzer
6. LevelChecker
7. ProphetComponentsPlotter
8. STLDecomposer
9. ShapExplainerVisualizer
10. ProphetRegressorCoefficientsPlotter


This module starts with loading all the necessary libraries.

## Reading from Data Asset


**Since, the input of this module is to read data from forecasting output data assets setting up blob/asset connection in important.**

Important libraries to load to set up connection :

`pip install -U azureml-fsspec mltable azure-ai-ml`

`import mltable`

`from azure.ai.ml import MLClient`

`from azure.identity import DefaultAzureCredential`

**The complete input data is in blob, the URI of the data asset can be matched with data_asset.path line to verify if the file is being read correctly or not.**

Then the reading  of the excels is same as we read in python. 



#Important Things to Remember

1. Blob Storage - Currently using "Outputs" Container created by Satyam, This will change when MLOps team setsup dedicated container. 
2. To read /write for credentials we load library from azure.identity import DefaultAzureCredential and put DefaultAzureCredential in credentials.
3. If a new key is added in config, it needs to be initialized in data reading
4. If I want to store results for all the models of different modelling_levels in an experiment, put those in config and everything will be stored in one run.
5. For cases where we have to extract the name of actual column like in LevelChecker class we have 
`if '____' in modelling_level:`
this can be changed if in future the format of modelling_level changes but we need a fixed format to the actual name of column.
6. Prophet coefficients was used for importance and if feature_importance sheet is there then that should be used.
7. For feature importance, features with 0 importance are skipped.
8. For waterfall plots one start and one end date is needed to make plots, if want to see just future mention only future and leave the pred empty.
9. Any coefficient value that is 0 after rounding upto 3 is skipped.(Prophet)
10. Add common functions class where ever saving is required.
11. If any df or function output is null, check the column name
12. Add the prophet_multivariate model check while reading not plotting prophet plots. No need to show trend and seasonality plots if model is not prophet
13. Remove column names from all classes if needed and put in config
14. Add one more sheet for external features forecast in class UnivariateFeatureFitVisualizer
15. Right now modelling level prefix is being removed manually
Univariate external forecast needs to be read and input in UnivariateFeatureFitVisualizer
16. Ask on where lagged internal data will be stored to be fed into UnivariateFeatureFitVisualizer , so far structure and sheet names should be same



