## Objective
The objective here is to set up Tempo for storing and sending Traces from projects or experiments. Tempo helps use get a better understanding how service flow through each other.

---
## Pre-requisites
- EntraID app
- Storage account
- Azure CLI
- YAML
- AKS
- Kubernetes
---
## Steps
These steps are to set up Tempo in an AKS cluster using a YAML template

### Setting up an AKS Cluster

- If you want to create a Cluster follow the _**Create AKS**_ runbook.

- Bind the cluster to kubectl
```
az aks get-credentials --resource-group <MY_RESOURCE_GROUP_NAME> --name <MY_AKS_CLUSTER_NAME>
```

### Creating Federated Token in EntraId assigning storage blob contributor role
- To Create Federated Token See the **_Create Federated Token_** runbook.
- Assign the **Storage Blob Data Contributor** role to the Entra app
### Deploy helm chart
1. Add the Grafana chart repo to Helm
```
helm repo add grafana https://grafana.github.io/helm-charts
```
2. Update Chart Repo
```
helm repo update
```
3. Create the namespace for tempo
```
kubectl create namespace <namespace-name>
```
---
### Deploying Tempo in kubernetes in distributed mode
1. This YAML template help in creating service
```YAML
mode: Distributed

  

serviceAccount:

  name: <service-account-name>

  annotations:

    "azure.workload.identity/client-id": "<ENTRA-APP-CLIENT-ID>"

  labels:

    "azure.workload.identity/use": "true"

  
  

searchEnabled: true

  

memberlist:

  join_members:

    - tempo-gossip-ring:7946

    - tempo-ingester-0:7946

    - tempo-ingester-1:7946

    - tempo-ingester-2:7946

  
  

compactor:

  compaction:

      block_retention: 1h

  extraVolumes:

    - name: federated-token

      projected:

        sources:

          - serviceAccountToken:

              path: azure-identity-token

              expirationSeconds: 3600

              audience: api://AzureADTokenExchange

  extraVolumeMounts:

    - name: federated-token

      mountPath: /var/run/secrets/azure/tokens

      readOnly: true

  extraArgs:

    - "-config.expand-env=true"

  extraEnv:

    - name: AZURE_CLIENT_ID

      value: "<ENTRA-APP-CLIENT-ID>"

    - name: AZURE_TENANT_ID

      value: "<ENTRA-APP-TENANT-ID>"

    - name: AZURE_FEDERATED_TOKEN_FILE

      value: /var/run/secrets/azure/tokens/azure-identity-token

  

ingester:

  trace_idle_period: 10s

  max_block_bytes: 1_000_000

  max_block_duration: 5m

  replicaCount: 3

  extraVolumes:

    - name: federated-token

      projected:

        sources:

          - serviceAccountToken:

              path: azure-identity-token

              expirationSeconds: 3600

              audience: api://AzureADTokenExchange

  extraVolumeMounts:

    - name: federated-token

      mountPath: /var/run/secrets/azure/tokens

      readOnly: true

  extraArgs:

    - "-config.expand-env=true"

  extraEnv:

    - name: AZURE_CLIENT_ID

      value: "<ENTRA-APP-CLIENT-ID>"

    - name: AZURE_TENANT_ID

      value: "<ENTRA-APP-TENANT-ID>"

    - name: AZURE_FEDERATED_TOKEN_FILE

      value: /var/run/secrets/azure/tokens/azure-identity-token

  

querier:

  replicaCount: 2

  extraVolumes:

    - name: federated-token

      projected:

        sources:

          - serviceAccountToken:

              path: azure-identity-token

              expirationSeconds: 3600

              audience: api://AzureADTokenExchange

  extraVolumeMounts:

    - name: federated-token

      mountPath: /var/run/secrets/azure/tokens

      readOnly: true

  extraArgs:

    - "-config.expand-env=true"

  extraEnv:

    - name: AZURE_CLIENT_ID

      value: "<ENTRA-APP-CLIENT-ID>"

    - name: AZURE_TENANT_ID

      value: "<ENTRA-APP-TENANT-ID>"

    - name: AZURE_FEDERATED_TOKEN_FILE

      value: /var/run/secrets/azure/tokens/azure-identity-token

  

traces:

  otlp:

    grpc:

      enabled: true

    http:

      enabled: true

  

distributor:

  log_received_spans:

    enabled: true

  log_discarded_spans:

    enabled: true

  receivers:

    otlp:

      protocols:

        grpc: 0.0.0.0:4317

        http: 0.0.0.0:4318

  service:

    type: LoadBalancer

    ports:

      - name: otlp-grpc

        port: 4317

        targetPort: 4317

      - name: otlp-http

        port: 4318

        targetPort: 4318

      - name: http-metrics

        port: 3200

        targetPort: 3200

      - name: grpc-metrics

        port: 9095

        targetPort: 9095

  extraVolumes:

    - name: federated-token

      projected:

        sources:

          - serviceAccountToken:

              path: azure-identity-token

              expirationSeconds: 3600

              audience: api://AzureADTokenExchange

  extraVolumeMounts:

    - name: federated-token

      mountPath: /var/run/secrets/azure/tokens

      readOnly: true

  extraArgs:

    - "-config.expand-env=true"

  extraEnv:

    - name: AZURE_CLIENT_ID

      value: "<ENTRA-APP-CLIENT-ID>"

    - name: AZURE_TENANT_ID

      value: "<ENTRA-APP-TENANT-ID>"

    - name: AZURE_FEDERATED_TOKEN_FILE

      value: /var/run/secrets/azure/tokens/azure-identity-token

  
  

queryFrontend:

  service:

    type: LoadBalancer

    ports:

      - name: http-query

        port: 3200

        targetPort: 3200

      - name: grpc-query

        port: 9095

        targetPort: 9095

  extraVolumes:

    - name: federated-token

      projected:

        sources:

          - serviceAccountToken:

              path: azure-identity-token

              expirationSeconds: 3600

              audience: api://AzureADTokenExchange

  extraVolumeMounts:

    - name: federated-token

      mountPath: /var/run/secrets/azure/tokens

      readOnly: true

  extraArgs:

    - "-config.expand-env=true"

  extraEnv:

    - name: AZURE_CLIENT_ID

      value: "<ENTRA-APP-CLIENT-ID>"

    - name: AZURE_TENANT_ID

      value: "<ENTRA-APP-TENANT-ID>"

    - name: AZURE_FEDERATED_TOKEN_FILE

      value: /var/run/secrets/azure/tokens/azure-identity-token

  
  

storage:

  trace:

    backend: azure

    blocklist_poll: 5m

    azure:

      container_name: "<CONTIANER-NAME>"

      storage_account_name: "<STOAGE-ACCOUNT>"

      use_federated_token: true

    pool:

      max_workers: 400

      queue_depth: 20000

    search:

      prefetch_trace_count: 1000

    wal:

      path: /var/tempo/wal
```

2. Deploy Tempo with helm
```
helm -n <namespace> install tempo grafana/tempo-distributed -f custom.yaml
```
3. To send traces to tempo use the distributor service external IP
---
_to connect in grafana see the grafana runbook_