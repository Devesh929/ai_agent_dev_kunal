import pandas as pd
import numpy as np
import multiprocessing as mp
import time

# Global variables for workers
stock_groups = None
all_tickers = None

def init_worker(stocks_df):
    global stock_groups, all_tickers
    all_tickers = stocks_df['Ticker'].unique()
    stock_groups = stocks_df.groupby('Ticker')

def process_event(task_data):
    event_name, event_dates = task_data
    results = []
    
    global stock_groups, all_tickers
    
    for ticker in all_tickers:
        try:
            stock_slice = stock_groups.get_group(ticker)
            event_stock_slice = stock_slice[stock_slice['Date'].isin(event_dates)]
            if len(event_stock_slice) == 0: continue
            
            # 14 Year Calculation
            up_days_14 = event_stock_slice['Went_Up'].sum()
            down_days_14 = event_stock_slice['Went_Down'].sum()
            total_14 = len(event_stock_slice)
            
            if total_14 < 20: continue # Strict N filter
            
            up_pct_14 = (up_days_14 / total_14) * 100
            down_pct_14 = (down_days_14 / total_14) * 100
            
            acc_14 = max(up_pct_14, down_pct_14)
            if acc_14 < 75: continue # Strict Accuracy filter
            
            target = "UP" if up_pct_14 > down_pct_14 else "DOWN"
            
            # 25-26 Backtest Calculation
            stock_slice_2526 = event_stock_slice[event_stock_slice['Date'] >= '2025-10-01']
            total_26 = len(stock_slice_2526)
            
            acc_26 = 0
            if total_26 > 0:
                if target == "UP":
                    acc_26 = (stock_slice_2526['Went_Up'].sum() / total_26) * 100
                else:
                    acc_26 = (stock_slice_2526['Went_Down'].sum() / total_26) * 100

            results.append({
                'Pattern': f"Whenever {event_name}, {ticker} stock GOES {target}!",
                '14_Year_Accuracy': acc_14,
                '14_Year_N': total_14,
                '25_26_Accuracy': f"{acc_26:.1f}%" if total_26 > 0 else "N/A",
                '25_26_N': total_26
            })
        except KeyError:
            continue
            
    return results

def run_ultimate_miner():
    start_time = time.time()
    print("Loading massive datasets for Parallel Miner...")
    
    players = pd.read_csv('data/nba_player_logs_2012_2026.csv', low_memory=False)
    stocks = pd.read_csv('data/sp500_stock_data_2012_2026.csv', low_memory=False)

    players['GAME_DATE'] = pd.to_datetime(players['GAME_DATE']).dt.tz_localize(None)
    stocks['Date'] = pd.to_datetime(stocks['Date']).dt.tz_localize(None)
    
    stocks.sort_values(by=['Ticker', 'Date'], inplace=True)
    stocks['Pct_Change'] = stocks.groupby('Ticker')['Close'].pct_change() * 100
    stocks['Went_Up'] = stocks['Pct_Change'] > 0
    stocks['Went_Down'] = stocks['Pct_Change'] < 0

    stock_dates = sorted(stocks['Date'].unique())
    stock_date_df = pd.DataFrame({'Stock_Date': stock_dates})
    
    print("Calculating Next Trading Days...")
    def get_next_trading_day(game_date):
        future = stock_date_df[stock_date_df['Stock_Date'] > game_date]
        if not future.empty:
            return future.iloc[0]['Stock_Date']
        return pd.NaT

    unique_game_dates = pd.DataFrame({'GAME_DATE': players['GAME_DATE'].unique()})
    unique_game_dates['Next_Trading_Date'] = unique_game_dates['GAME_DATE'].apply(get_next_trading_day)
    players = pd.merge(players, unique_game_dates, on='GAME_DATE', how='left')

    print("Filtering to established players (>= 100 career games)...")
    game_counts = players['PLAYER_NAME'].value_counts()
    valid_players = game_counts[game_counts >= 100].index
    players = players[players['PLAYER_NAME'].isin(valid_players)]

    events = []
    print(f"Extracting anomalies for {len(valid_players)} players...")
    
    for _, row in players.iterrows():
        p_name = row['PLAYER_NAME']
        date = row['Next_Trading_Date']
        if pd.isna(date): continue
            
        pts = row['PTS']
        ast = row['AST']
        tov = row['TOV']
        pm = row['PLUS_MINUS']
        
        if pd.notna(pts) and pts >= 30: events.append({'Date': date, 'Event': f"{p_name} scores 30+"})
        if pd.notna(ast) and ast >= 10: events.append({'Date': date, 'Event': f"{p_name} dishes 10+ Assists"})
        if pd.notna(tov) and tov >= 6: events.append({'Date': date, 'Event': f"{p_name} turns it over 6+ times"})
        if pd.notna(pm):
            if pm >= 20: events.append({'Date': date, 'Event': f"{p_name} dominates with +20 Plus/Minus"})
            if pm <= -20: events.append({'Date': date, 'Event': f"{p_name} is a liability with -20 Plus/Minus"})

    events_df = pd.DataFrame(events).drop_duplicates()
    
    tasks = []
    for event_name in events_df['Event'].unique():
        event_dates = events_df[events_df['Event'] == event_name]['Date']
        if len(event_dates) >= 20: # pre-filter to save time
            tasks.append((event_name, event_dates))
            
    print(f"Dispatching {len(tasks)} unique events to Parallel Workers...")
    
    final_results = []
    with mp.Pool(processes=mp.cpu_count(), initializer=init_worker, initargs=(stocks,)) as pool:
        for res in pool.imap_unordered(process_event, tasks, chunksize=10):
            final_results.extend(res)

    res_df = pd.DataFrame(final_results)
    if not res_df.empty:
        # Format for output
        res_df['14_Year_Accuracy_Fmt'] = res_df['14_Year_Accuracy'].apply(lambda x: f"{x:.1f}%")
        res_df.sort_values(by=['14_Year_Accuracy', '14_Year_N'], ascending=[False, False], inplace=True)
        # Drop numeric sort column
        res_df.drop('14_Year_Accuracy', axis=1, inplace=True)
        res_df.rename(columns={'14_Year_Accuracy_Fmt': '14_Year_Accuracy'}, inplace=True)
        
        res_df.to_csv('data/ultimate_parallel_patterns.csv', index=False)
        print("\n=== ULTIMATE OBSCURE FINDINGS (Top 40) ===\n")
        print(res_df.head(40).to_string())
    else:
        print("No patterns met the threshold.")
        
    print(f"Finished brute-forcing in {time.time() - start_time:.2f} seconds.")

if __name__ == "__main__":
    run_ultimate_miner()
