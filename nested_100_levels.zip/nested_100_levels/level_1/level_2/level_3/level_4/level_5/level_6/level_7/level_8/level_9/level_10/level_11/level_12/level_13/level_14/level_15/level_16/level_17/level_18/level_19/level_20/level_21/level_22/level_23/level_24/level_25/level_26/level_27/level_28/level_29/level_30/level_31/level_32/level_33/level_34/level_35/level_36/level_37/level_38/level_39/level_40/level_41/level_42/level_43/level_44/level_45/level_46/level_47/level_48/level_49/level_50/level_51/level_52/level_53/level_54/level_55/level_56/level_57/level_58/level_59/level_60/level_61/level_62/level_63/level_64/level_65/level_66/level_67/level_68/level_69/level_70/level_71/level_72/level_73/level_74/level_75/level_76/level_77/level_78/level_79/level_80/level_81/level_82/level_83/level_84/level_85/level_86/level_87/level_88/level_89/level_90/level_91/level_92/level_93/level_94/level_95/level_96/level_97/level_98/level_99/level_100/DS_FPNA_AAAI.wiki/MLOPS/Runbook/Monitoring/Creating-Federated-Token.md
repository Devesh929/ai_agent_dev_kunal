## Objective
 The Objective here is to create a federated token to allow being able to assign roles to the entra app instead of having to assign role to each service. This here is specifically for AKS.

---
## Pre-requisites

- Azure CLI
- Entra App

---
## Steps
Set this up to assign roles to the AKS cluster to access the storage account to store logs

1. Get the OIDC issuer URL for the AKS
```
az aks show --resource-group <MY_RESOURCE_GROUP_NAME> --name <MY_AKS_CLUSTER_NAME> --query "oidcIssuerProfile.issuerUrl" -o tsv
```
2. Create a 'credentials.json' file and create a federated token
```
{
    "name": "LokiFederatedIdentity",
    "issuer": "<OIDC-ISSUER-URL>",
    "subject": "system:serviceaccount:<namesoace>:<service account name in the cluster>",
    "description": "Federated identity for Loki accessing Azure resources",
    "audiences": [
      "api://AzureADTokenExchange"
    ]
}
```
3. Get the app Id of your entra app

```
az ad app list --display-name loki --query "[].appId" -o tsv
```

4. Make sure to create a service principal for the Entra app
```
az ad sp create --id <APP-ID>
```
5. Create the federated token from the credentials.json
```
az ad app federated-credential create --id <APP-ID> --parameters credentials.json 
```