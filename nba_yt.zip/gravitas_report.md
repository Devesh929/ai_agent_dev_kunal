# Script Building: The Gravitas of NBA Anomalies

## Devin Booker -> Tesla
**The Trigger:** Devin Booker turns the ball over 7+ times
**The Result:** Tesla stock GOES UP
**The Math:** 89.3% Accuracy over 28 games.
**The Gravitas (Script Gold):**
- On 2020-02-03, this event triggered a surge that pushed Tesla stock to a 52-week HIGH!
- On 2020-02-03, Tesla surged by a massive 19.9% the morning after this event!

---

## Kevin Durant -> Meta
**The Trigger:** Kevin Durant shoots terribly (<35% on 18+ shots)
**The Result:** Meta stock GOES DOWN
**The Math:** 77.4% Accuracy over 31 games.
**The Gravitas (Script Gold):**
- On 2018-11-19, this event triggered a massive crash that pushed Meta stock to its 52-week low!
- On 2018-11-19, this event coincided with a brutal 5.7% single-day wipeout for Meta!

---

## Jayson Tatum -> Amazon
**The Trigger:** Jayson Tatum is a ball hog (takes 28+ shots)
**The Result:** Amazon stock GOES DOWN
**The Math:** 77.8% Accuracy over 18 games.
**The Gravitas (Script Gold):**
- On 2022-03-07, this event triggered a massive crash that pushed Amazon stock to its 52-week low!
- On 2022-03-07, this event coincided with a brutal 5.6% single-day wipeout for Amazon!

---

## Shai Gilgeous-Alexander -> Tesla
**The Trigger:** Shai Gilgeous-Alexander perfect on 12+ FTs
**The Result:** Tesla stock GOES DOWN
**The Math:** 82.4% Accuracy over 17 games.
**The Gravitas (Script Gold):**
- On 2022-12-20, this event triggered a massive crash that pushed Tesla stock to its 52-week low!
- On 2024-01-25, this event coincided with a brutal 12.1% single-day wipeout for Tesla!

---

## Dillon Brooks -> Nike
**The Trigger:** Dillon Brooks scores 20+ points
**The Result:** Nike stock GOES DOWN
**The Math:** 65.6% Accuracy over 131 games.
**The Gravitas (Script Gold):**
- On 2025-04-03, this event triggered a massive crash that pushed Nike stock to its 52-week low!
- On 2025-04-03, this event coincided with a brutal 14.4% single-day wipeout for Nike!

---

## Stephen Curry -> Tesla
**The Trigger:** Stephen Curry hits 9+ Threes
**The Result:** Tesla stock GOES UP
**The Math:** 67.3% Accuracy over 49 games.
**The Gravitas (Script Gold):**
- On 2017-04-03, this event triggered a surge that pushed Tesla stock to a 52-week HIGH!
- On 2018-10-25, Tesla surged by a massive 9.1% the morning after this event!

---

## Russell Westbrook -> Apple
**The Trigger:** Russell Westbrook fouls out
**The Result:** Apple stock GOES UP
**The Math:** 77.8% Accuracy over 18 games.
**The Gravitas (Script Gold):**
- On 2022-04-04, this event triggered a surge that pushed Apple stock to a 52-week HIGH!
- On 2018-03-26, Apple surged by a massive 4.7% the morning after this event!

---

