## Objective
The objective here is to create an aks cluster so we can host our app and services.

---
## Pre-requisites
- Azure CLI

---
## Setup

1. Login to the azure subscription
```
az login
```
2. Select your azure subscription
3. Create an AKS cluster with _oidc issuer_ and _workload-identity_ enabled
```
az aks create --resource-group <MY_RESOURCE_GROUP_NAME> --name <MY_AKS_CLUSTER_NAME> --node-count 3 --node-vm-size Standard_E2ds_v5 --generate-ssh-keys --enable-workload-identity --enable-oidc-issuer
```
