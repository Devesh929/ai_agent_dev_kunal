#Analysis.py
The purpose of this page is to explain in detail about the classes that are in post modelling module.
This document talk about purpose of each clas, input and output of the classes and explanation of the code.

#Class CommonFunctions


This `CommonFunctions` class acts as a utility hub, primarily designed to standardize and centralize common operations related to saving data (Pandas DataFrames to Excel) and visualizations (Matplotlib plots) during machine learning experiments. Crucially, it provides the flexibility to save these artifacts either to a **local filesystem** or to **Azure Blob Storage**, making it suitable for both local development and cloud-based ML workflows (like those in Azure Machine Learning).



#Class DataReading


## Purpose

The `DataReading` class serves to **centralize and standardize the reading and aggregation of all model outputs and related data** generated from both univariate and multivariate forecasting experiments. Its core function is to consolidate actual values, forecast predictions, trend components, feature importance, SHAP values, and other diagnostic data from various models and modelling granularities into unified Pandas DataFrames. This streamlined data access is crucial for subsequent analysis, visualization, and reporting stages of a forecasting pipeline.


## Input Parameters

The `__init__` method of the `DataReading` class takes numerous parameters to configure data paths, sheet names, and analytical thresholds. Here's a breakdown of the _key_ input parameters:
*   `experiment_name`: A string identifying the multivariate forecasting experiment, used to locate its output files.
    
*   `modelling_level_list`: A list of strings, where each string represents a data granularity level (e.g., 'country', 'division') for which models were executed.
    
*   `models`: A list of strings, indicating the names of the forecasting models (e.g., 'XGBoost', 'Prophet') whose outputs are to be read.
    
*   `models_stl`: A list of strings, likely for STL decomposition models.
    
*   `main_results_folder`: The base folder where overall experiment results are stored.
    
*   `data_asset_path`, `data_asset_label`: Azure ML specific parameters to retrieve the base storage path of the model outputs from an Azure ML Workspace.
    
*   `features_used_sheet`: The sheet name in the results file where features used by the models are listed.
    
*   `val_sheet`, `test_sheet`, `future_forecast`: Sheet names within model output Excel files containing validation, test, and future predictions, respectively.
    
*   `full_trend_sheet`, `train_trend_sheet`, `val_trend_sheet`, `test_trend_sheet`, `future_trend_sheet`: Sheet names for different segments of trend/seasonality decomposition data.
    
*   `shapely_values_sheet`, `shapely_values_future_sheet`, `importance_values_sheet`, `base_value_sheet`: Sheet names for model interpretability outputs (SHAP values for historical and future, feature importance, and SHAP base values).
    
*   `prophet_coefficients_sheet`, `prophet_components_sheets`: Sheet names specific to Prophet's coefficients and individual component breakdowns.
    
*   `x_full_data_sheet`, `y_full_data_sheet`, `x_future_forecast_sheet`: Sheet names for exogenous variables (X) and target variable (Y) for historical data and exogenous variables for future forecasts.
    
*   `x_val1_forecast_sheet`, `x_val2_forecast_sheet`, `x_val3_forecast_sheet`, `x_val4_forecast_sheet`, `x_test_forecast_sheet`: Sheet names for exogenous variables corresponding to different validation periods and the test period.
    
*   `pred_start`, `pred_end`, `future_start`, `future_end`: Date range definitions for prediction horizons, though not directly used in the provided `read_all_model_outputs` method, they are stored as instance attributes.
    
*   `univariate_experiment_name`: A string identifying the univariate forecasting experiment, to read its specific outputs.
    
*   `growth_threshold_pct`, `decline_threshold_pct`, `top_n_features`: Analytical thresholds and parameters for post-processing, stored as instance attributes.



## Code Explained

The `DataReading` class has the following key components and methods:

#### `__init__(self, ...)`

*   **Initialization of Attributes**: All input parameters are assigned as instance attributes, making them accessible throughout the class methods.
    
*   **Sheet Name Mapping (`self.sheets`)**: A dictionary `self.sheets` is created, mapping descriptive keys (e.g., 'val', 'shapely_values') to the actual sheet names provided as input. This centralizes sheet name management and improves readability.
    
*   **Azure ML Path Resolution**:
    *   It attempts to initialize `MLClient` and retrieve the base path of the Azure ML data asset using `ml_client.data.get()`. This is crucial for accessing model outputs stored in Azure ML.
        
    *   The `base_path` variable is derived from this Azure ML data asset's path, serving as the root directory for all subsequent file operations.
        

### `read_all_model_outputs(self)`

This is the core method responsible for loading and consolidating all data.
*   **Azure ML Base Path Retrieval**: It first establishes `base_path` by interacting with the Azure ML SDK to get the data asset's path.
    
*   **Initialization of DataFrames Lists**: Numerous empty lists (e.g., `all_data_val_u`, `shapely_values`, `full_trend`) are initialized to store individual DataFrames as they are read from various Excel files. These will later be concatenated.
    
*   **Iterative Data Loading**:
    *   It iterates through each `modelling_level` and `model` in the respective lists.
        
    *   For each combination, it constructs a `file_path_uni` specific to univariate model outputs (e.g., `"{base_path}{self.example_experiment_name}/intermediate/{modelling_level}-{model}.xlsx"`).
        
    *   It then attempts to read the 'val', 'test', and 'future' sheets from these files.
        
    *   Crucially, it adds `modelling_level` and `model_name` columns to each DataFrame, which is essential for aggregation and identification later.
        
    *   **Robust Error Handling**: `try-except` blocks are used extensively to catch `FileNotFoundError` (for missing files) and general `Exception` (for other reading errors). Warnings are logged. If a sheet name is empty in the configuration (`self.sheets[sheet_key]` is falsy), it logs a message and skips reading that sheet.
        
        
*   **Global Data Loading (`features_df`)**:
    *   It attempts to read the `features_used_sheet` from a central results file: `"{base_path}/{self.experiment_name}/final_results/{self.experiment_name}_multivariate_results.xlsx"`. This file likely contains metadata or consolidated results not tied to individual model outputs.
        
*   **`concat_dfs(list_of_dfs)` Helper Function**:
    *   This nested static method (or could be a standalone helper) efficiently concatenates a list of DataFrames.
        
    *   It first filters out any `None` or empty DataFrames from the input list, preventing errors during concatenation.
        
    *   If valid DataFrames exist, it uses `pd.concat` to combine them into a single DataFrame, resetting the index. If no valid DataFrames are present, it returns an empty DataFrame.
        
*   **Consolidation of DataFrames**:
    *   After all individual DataFrames are read into their respective lists, the `concat_dfs` helper is called for each list. This combines all data of a specific type (e.g., all validation predictions, all SHAP values) into one comprehensive DataFrame.
        
    *   **`full_data` Merge**: It performs an `inner` merge between `combined_x_full_data` and `combined_y_full_data` on `date`, `modelling_level`, and `model_name` to create a `full_data` DataFrame, likely representing the complete historical dataset with features and target.
        
    *   **`x_full_future_data` Concatenation**: It concatenates `combined_x_full_data` and `combined_x_future_data` to provide a complete set of exogenous variables spanning both historical and future periods.
        
    *   **`x_forecast_data` Concatenation**: It concatenates all the `x_val_forecast` and `x_test_forecast` DataFrames into a single `x_forecast_data` DataFrame.
        
*   **Return Dictionary**: The method returns a dictionary where keys are descriptive names (e.g., "val_u", "shapely_values", "full_data"), and values are the consolidated Pandas DataFrames.


##Use the Code

Before you instantiate the class, you must fillthe specific values for each parameter in config. This includes:
*   Your experiment names (univariate and multivariate).
    
*   The list of modelling granularities (`modelling_level_list`).
    
*   The names of the models used (`models`, `models_stl`).
    
*   The base folder where your overall results are stored (`main_results_folder`).
    
*   Crucially, the **exact sheet names** used in your Excel output files for various types of data (e.g., `'val_predictions'`, `'feature_importance'`, `'full_trend'`). These are critical as the class uses them to find the correct data within the Excel files.
    
*   Your Azure ML data asset details (`data_asset_path`, `data_asset_label`).
    
*   Date range definitions and analytical thresholds.

**The `read_all_model_outputs()` method returns a dictionary. You can then access the various consolidated DataFrames by their keys.**

## Outputs of Methods in Class

The `read_all_model_outputs` method returns a single **dictionary** where each key maps to a consolidated Pandas DataFrame. The keys and their corresponding DataFrame contents are:
*   `"val_u"`, `"test_u"`, `"future_u"`: Combined DataFrames of actuals and predictions for validation, test, and future periods from **univariate** models across all specified modelling levels and models.
    
*   `"val"`, `"test"`, `"future"`: Combined DataFrames of actuals and predictions for validation, test, and future periods from **multivariate** models across all specified modelling levels and models.
    
*   `"combined_x_full"`: Consolidated DataFrame of historical exogenous variables (X) from multivariate models.
    
*   `"combined_y_full"`: Consolidated DataFrame of historical target variables (Y) from multivariate models.
    
*   `"combined_x_future"`: Consolidated DataFrame of future exogenous variables (X) for multivariate forecasts.
    
*   `"shapely_values"`: Consolidated DataFrame of SHAP values for historical predictions.
    
*   `"shapely_values_future"`: Consolidated DataFrame of SHAP values for future predictions.
    
*   `"importance_values"`: Consolidated DataFrame of feature importance scores.
    
*   `"base_values"`: Consolidated DataFrame of SHAP base values.
    
*   `"full_trend"`, `"train_trend"`, `"val_trend"`, `"test_trend"`, `"future_trend"`: Consolidated DataFrames of trend and seasonality components (likely from Prophet or other decomposition models).
    
*   `"prophet_coef"`: Consolidated DataFrame of Prophet model coefficients.
    
*   `"prophet_components_list"`: Consolidated DataFrame of individual Prophet components (e.g., yearly, weekly seasonality).
    
*   `"full_data"`: A merged DataFrame containing both historical exogenous variables (`combined_x_full_data`) and historical target variables (`combined_y_full_data`).
    
*   `"x_full_future"`: A concatenated DataFrame containing exogenous variables for both historical and future periods.
    
*   `"features_df"`: A DataFrame listing the features used by the models (read from the central results file).
    
*   `"x_forecast_data"`: A concatenated DataFrame containing exogenous variables for all validation periods and the test period (`x_val1_forecast` through `x_test_forecast`).



# Class ResidualAnalyzer

##Purpose

*   The `ResidualAnalyzer` class is designed to **perform statistical tests on the residuals (errors)** of forecasting models.
    
*   Its primary purpose is to **assess the validity of model assumptions** (e.g., homoscedasticity, no autocorrelation) on the forecast errors, which is crucial for determining the reliability and robustness of the predictions.
    
*   It specifically implements the **White test for heteroscedasticity** and the **Ljung-Box test for autocorrelation**.

*  It also outputs the **ACF/PACF** plot for validation data and **Residual histograms** for both validation and test data.

##Input Parameters

* **`generate_acf_pacf_plot(self, df_filtered, experiment_name, set_name)`**

   * `df_filtered`: A Pandas DataFrame containing the residuals (`'error'`) for a specific `modelling_level` and `model_name`. This DataFrame is expected to be a subset of a larger dataset, already filtered down to the exact data points for which the ACF/PACF plots are to be generated. It must contain at least the 'error', 'modelling_level', and 'model_name' columns.
  
        
  *   `experiment_name` : The name of the overall forecasting experiment. This is typically used for organizing saved plots into relevant directories.
        

        
  *   `set_name` :  A string indicating the dataset or set for which the residuals are being analyzed (e.g., "Validation", "Test", "Train"). This is used in plot titles and potentially for saving plots to specific subfolders.
        

* **`plot_residuals_hist`**

  *   `df`: DataFrame containing residuals (`'error'`), 'modelling_level', and 'model_name' for a specific model and level.
    
  *   `experiment_name`: Name of the forecasting experiment for plot titles and saving.
    
  *   `set_name`: Identifier for the dataset (e.g., 'val', 'test') for plot titles.


* **`generate_all_plots`**

  *   `dataframes_to_plot` : A dictionary where keys are dataset names (e.g., 'val', 'test') and values are DataFrames. Each DataFrame must contain 'error', 'modelling_level', and 'model_name' columns.
    
  *   `experiment_name`: Name of the forecasting experiment for organizing plots.

* **`residual_testing(self, full_data, val_pred, modelling_level, model_name, features)`**:
    *   `full_data` (pd.DataFrame): The complete historical dataset, including features.
        
    *   `val_pred` (pd.DataFrame): DataFrame containing validation period predictions and errors, typically from `combined_val_df` (with `validation_fold` column).
        
    *   `modelling_level` (string): The specific aggregation level being analyzed (e.g., 'Country', 'Division').
        
    *   `model_name` (string): The name of the model being analyzed (e.g., 'XGBoost', 'Prophet').
        
    *   `features` (list of strings): A list of exogenous feature columns used by the model for the given `modelling_level`.

* **`residual_testing_single_test(self, full_data, combined_val_df, modelling_level, model_name, features)`**:

  *   `full_data` (pd.DataFrame): Same as above:
    
  *   `combined_val_df` (pd.DataFrame): This parameter name is slightly misleading; it should ideally be the combined test set predictions if used for a single _test_ run (e.g., `combined_test_df` from `DataReading`). It contains actuals, predictions, and errors for the specific period (e.g., validation or test).
    
  *   `modelling_level`, `model_name`, `features`: Same as above.

* **`analyze_residuals_for_all_models(self, full_data, combined_val_df, feature_df)`**:
  *   `full_data` (pd.DataFrame): The complete historical dataset.
    
  *   `combined_val_df` (pd.DataFrame): Consolidated validation forecast DataFrame (output from `DataReading`).
    
  *   `feature_df` (pd.DataFrame): DataFrame containing which features were used by which model at each modelling level (output from `DataReading`).

* **`analyze_residuals_single_test_for_all_models(self, full_data, combined_test_df, feature_df)`**:
  *   `full_data` (pd.DataFrame): The complete historical dataset.
    
  *   `combined_test_df` (pd.DataFrame): Consolidated test forecast DataFrame (output from `DataReading`).
    
  *   `feature_df` (pd.DataFrame): Same as above.


##Code  Explanation



### Method Explanations

Let's break down the key methods in your `ResidualAnalyzer` class:


#### `generate_acf_pacf_plot(self, df_filtered, experiment_name, set_name)`

*   **Purpose:** Generates Autocorrelation Function (ACF) and Partial Autocorrelation Function (PACF) plots of residuals.
    
*   **Explanation:** This method takes a filtered DataFrame containing residuals, an `experiment_name`, and a `set_name` (e.g., 'validation', 'test').
    *   It extracts the 'error' column.
        
    *   It calculates `n_lags` for the plots, ensuring it's not too large relative to the data length.
        
    *   It then uses `statsmodels.graphics.tsaplots.plot_acf` and `plot_pacf` to create the plots. **These plots help in identifying if there's any remaining** **autocorrelation** in the residuals, which would indicate that the model hasn't captured all the underlying patterns in the data.
        
    *   The plots are titled with relevant information (modelling level, model name, set name).
        
    *   Finally, it displays the plots using `plt.show()` and closes them to free up memory. Error handling is included to log any issues during plot generation.
        

#### `plot_residuals_hist(self, df, experiment_name, set_name)`

*   **Purpose:** Generates a histogram of residuals.
    
*   **Explanation:** Similar to the ACF/PACF plot method, this one takes a DataFrame, experiment name, and set name.
    *   It extracts the 'error' column and creates a histogram using `plt.hist`.
        
    *   **The histogram helps visualize the** **distribution of residuals**. Ideally, residuals should be normally distributed around zero. This plot can reveal skewness, kurtosis, or other deviations from normality, which might suggest issues with the model's assumptions.
        
    *   The plot is titled, labeled, and then displayed and closed.
        

#### `generate_all_plots(self, dataframes_to_plot, experiment_name)`

*   **Purpose:** Orchestrates the generation of all residual plots for multiple data sets and models.
    
*   **Explanation:** This method iterates through a dictionary of DataFrames (`dataframes_to_plot`), where keys are set names (e.g., 'train', 'val', 'test') and values are the corresponding DataFrames.
    *   For each set, it further iterates through unique `modelling_level` and `model_name` combinations found in the DataFrame.
        
    *   It filters the DataFrame for each specific `modelling_level` and `model_name`.
        
    *   It then calls `plot_residuals_hist` for all sets and `generate_acf_pacf_plot` specifically for the 'val' (validation) set. This is a common practice because ACF/PACF plots are particularly useful for assessing model fit on unseen validation data.
        
    *   It includes checks for empty DataFrames or missing 'error' columns to prevent errors and log warnings.
        

#### `residual_testing(self, full_data, val_pred, modelling_level, model_name, features)`

*   **Purpose:** Performs statistical tests (White's test and Ljung-Box test) on residuals for each validation fold.
    
*   **Explanation:** This method focuses on **fold-wise** residual testing for a specific `modelling_level` and `model_name`.
    *   It filters the input `val_pred` (validation predictions) DataFrame by fold.
        
    *   For each fold:
        *   **White's Test for Heteroscedasticity:**
            *   **Concept:** Checks if the variance of the residuals is constant across all levels of the independent variables (homoscedasticity). If the p-value is less than the significance level (alpha, typically 0.05), you reject the null hypothesis of homoscedasticity, indicating **heteroscedasticity** (non-constant variance).
                
            *   **Steps:** It attempts to perform White's test (`statsmodels.stats.api.het_white`). This test requires the original features (exogenous variables) that were used to train the model. It constructs `X_for_white_test` from the `features` provided. If features are not varying or are missing, the test is skipped. It then fits an OLS model of the errors on these features and applies the White's test to the residuals of _that_ OLS model.
                
        *   **Ljung-Box Test for Autocorrelation:**
            *   **Concept:** Checks if there is significant autocorrelation in the residuals up to a specified number of lags. If the p-value is less than alpha, you reject the null hypothesis of no autocorrelation, indicating that the residuals are **autocorrelated**.
                
            *   **Steps:** It calculates a reasonable number of lags (`n_lags`) based on the number of observations. It then applies the `statsmodels.stats.api.acorr_ljungbox` function.
                
    *   It collects the results (p-values and test outcomes) for each test and each fold into a list of dictionaries, which is then converted into a Pandas DataFrame.
        
    *   Extensive logging is used to track the progress and any issues encountered during the tests.
        

#### `residual_testing_single_test(self, full_data, combined_val_df, modelling_level, model_name, features)`

*   **Purpose:** Performs statistical tests (White's test and Ljung-Box test) on the combined residuals for a given modelling level and model name (not fold-wise).
    
*   **Explanation:** This method is similar to `residual_testing` but performs the tests on the **entire combined validation/test set** for a specific `modelling_level` and `model_name`, rather than individual folds.
    *   It aggregates all residuals for the specified model and level.
        
    *   It then performs White's test and Ljung-Box test on this aggregated error series using the same principles as `residual_testing`.
        
    *   This provides an overall assessment of the residuals for a particular model and modelling level, rather than a fold-by-fold breakdown.
        

#### `analyze_residuals_for_all_models(self, full_data, combined_val_df, feature_df)`

*   **Purpose:** Orchestrates the residual analysis for all models and modelling levels on the validation data.
    
*   **Explanation:** This is a high-level method that iterates through all unique `(modelling_level, model_name)` pairs present in the `combined_val_df`.
    *   For each pair, it retrieves the features associated with that model from the `feature_df`.
        
    *   It then calls `residual_testing` to get fold-wise residual test results and `residual_testing_single_test` to get combined residual test results.
        
    *   Finally, it concatenates all the individual results into two comprehensive DataFrames: one for fold-wise results and one for single-test results across all models and levels.
        

#### `analyze_residuals_single_test_for_all_models(self, full_data, combined_test_df, feature_df)`

*   **Purpose:** Orchestrates the single residual test analysis for all models and modelling levels on the test data.
    
*   **Explanation:** This method is nearly identical to `analyze_residuals_for_all_models` but specifically performs the `residual_testing_single_test` on the `combined_test_df`. This allows for a final assessment of model residuals on completely unseen test data.


##Output of Code

1.  **Plots Displayed:**
    *   **Histograms of Residuals:** For each combination of modelling level, model name, and data set (train, validation, test), a histogram will pop up. 
        
    *   **ACF and PACF Plots of Residuals:** Specifically for the **validation set** for each modelling level and model name, a pair of plots (Autocorrelation Function and Partial Autocorrelation Function) will appear. 
        
    *   **_Note:_** The plots are shown via `plt.show()` and then closed. If you were saving them, they would appear in your `main_folder`.
        
        
2.  **Pandas DataFrames :**
    *   **Validation Fold-wise Test Results (`val_fold_results_df`):** A DataFrame summarizing the statistical test results (White's test p-value and conclusion, Ljung-Box p-value and conclusion) for _each individual validation fold_ for every modelling level and model. This allows for a detailed, fold-by-fold assessment.
        
    *   **Validation Overall Test Results (`val_overall_results_df`):** A DataFrame providing a single, combined summary of the statistical tests on the _entire validation set_ for each modelling level and model.
        
    *   **Test Set Overall Test Results (`test_overall_results_df`):** A DataFrame similar to the validation overall results, but specifically for the _test set_. This is the final evaluation of residual properties on truly unseen data.
        
#Graph
    A[Raw Data, Predictions, Features] --> B(ResidualAnalyzer Class)

    B -- Input: dataframes_to_plot, experiment_name --> C{generate_all_plots}
    C --> D[Displays Histograms]
    C --> E[Displays ACF/PACF Plots (Val Set Only)]
    C --> F[Logs Plotting Progress/Warnings]

    B -- Input: full_data, combined_val_df, feature_df --> G{analyze_residuals_for_all_models}
    G --> H{residual_testing (Fold-wise)}
    G --> I{residual_testing_single_test (Overall Val)}
    H --> J[Logs Fold-wise Test Results]
    I --> K[Logs Overall Val Test Results]
    H & I --> L[Returns Validation Results DataFrames]

    B -- Input: full_data, combined_test_df, feature_df --> M{analyze_residuals_single_test_for_all_models}
    M --> N{residual_testing_single_test (Overall Test)}
    N --> O[Logs Overall Test Test Results]
    N --> P[Returns Test Results DataFrame]

    J & K & O --> Q[Visible Console Logs]
    D & E --> R[Visible Plot Windows]
    L & P --> S[Returned Pandas DataFrames]



# Class Potter

## Purpose

This class is designed to visualize the actual values against the predicted values from a model. It helps in assessing model performance by graphically comparing forecasts with observed data and highlighting instances where predictions deviate significantly from actuals.

## Input Parameters

##### `plot_series(self, df: pd.DataFrame, experiment_name: str, set_name: str, threshold_percentage: float = 0.01)`

*   **`df`** (`pd.DataFrame`): A Pandas DataFrame containing the data to be plotted. It **must** contain the following columns:
    *   `'date'`: Datetime objects or strings convertible to datetime, representing the time axis.
        
    *   `'actuals'`: Numerical values representing the true observed data.
        
    *   `'predictions'`: Numerical values representing the model's forecasted data.
        
    *   `'modelling_level'`: A string or categorical identifier for the level at which the model was trained.
        
    *   `'model_name'`: A string identifier for the specific model used (e.g., 'ARIMA', 'XGBoost').
        
*   **`experiment_name`** (`str`): A descriptive name for the overall experiment, used for logging.
    
*   **`set_name`** (`str`): The name of the data set being plotted (e.g., 'train', 'validation', 'test'). This helps in distinguishing plots from different data splits.
    
*   **`threshold_percentage`** (`float`, default `0.01`): The percentage threshold (e.g., `0.01` for 1%) to highlight deviations. If the absolute percentage difference between actuals and predictions exceeds this value, the point will be marked on the plot.
    

##### `generate_plot(self, dataframes_to_plot: dict[str, pd.DataFrame], experiment_name: str)`

*   **`dataframes_to_plot`** (`dict[str, pd.DataFrame]`): A dictionary where keys are `set_name` (e.g., 'train', 'val', 'test') and values are Pandas DataFrames. Each DataFrame within this dictionary should conform to the requirements of the `plot_series` method.
    
*   **`experiment_name`** (`str`): A descriptive name for the overall experiment, used for logging and plot titles.


##Code Explained

##### `plot_series(self, df: pd.DataFrame, experiment_name: str, set_name: str, threshold_percentage: float = 0.01)`

This method generates a single line plot showing actual values versus predicted values over time. It identifies and marks points where the prediction error exceeds a specified percentage threshold. 

   * **Error Calculation:** `df['abs_percent_diff'] = np.abs((df['actuals'] - df['predictions']) / df['actuals'].replace(0, np.nan))` computes the absolute percentage error. This is a crucial metric for understanding forecast accuracy relative to the actual value. `replace(0, np.nan)` prevents division by zero if actuals are zero.
   * **Deviation Highlighting:** Points exceeding `threshold_percentage` are identified (`deviations_df`) and then explicitly marked on the plot using `ax.scatter`. This visually draws attention to significant forecast misses, making it easy to spot problem areas. `zorder=5` ensures these markers are visible on top of the lines.


##### `generate_plot(self, dataframes_to_plot: dict[str, pd.DataFrame], experiment_name: str)`

This method acts as an orchestrator, iterating through different sets of data (e.g., validation, test) and, for each set, generating a `plot_series` for every unique combination of `modelling_level` and `model_name`.


##Output of Code

The user will primarily see **interactive Matplotlib plot windows** popping up, one after another, for each unique combination of data set, modelling level, and model name found in the input. Each plot will show:
*   **Blue Line:** The actual observed values over time.
    
*   **Red Dashed Line:** The model's predicted values over time.
    
*   **Green Circles:** Markers on the "Actuals" line at points where the absolute percentage difference between actuals and predictions exceeds the `threshold_percentage`.
    
*   **Orange Crosses:** Markers on the "Predictions" line at points corresponding to the green circles, where the deviation threshold was exceeded.
    
*   **Title:** Clearly states the modelling level, model name, set name, and the deviation threshold used for highlighting.
    
*   **Labels:** 'Date' on the x-axis and 'Values' on the y-axis.
    
*   **Legend:** Explaining 'Actuals', 'Predictions', and the highlighted points.


##Graph
    
    A & B --> M_Init
    M_Init -- Initializes Plotter Object --> M_GenPlot

    C & D --> M_GenPlot

    M_GenPlot -- For each 'set_name' in dataframes_to_plot --> F{Process set_name: df_for_set}
    F -- If df_for_set empty --> G[Log Warning: Skipping set] --> O_Logs

    F -- If df_for_set not empty --> H{Loop through unique (modelling_level, model_name) combinations}

    H -- For each combo --> I[Filter df_for_set to create df_filtered (for current level/model)]
    I -- If df_filtered empty --> J[Log Info: No data for combo] --> O_Logs

    I -- If df_filtered not empty --> K[Log Info: Generating plot for current combo] --> O_Logs
    K & E --> M_PlotSeries

    M_PlotSeries -- Input: df_filtered, experiment_name, set_name, threshold_percentage --> L{Perform Input Validation}
    L -- Validation Fails --> M[Log Error/Warning: Missing Columns/Empty] --> O_Logs

    L -- Validation Passes --> N[Calculate 'abs_percent_diff']
    N --> O[Identify Deviation Points]
    O --> P[Generate Plot: Actuals vs. Predictions]
    P --> Q[Overlay Highlighted Deviation Points]
    Q --> R[Set Plot Properties: Title, Labels, Legend, Ticks]
    R --> S[Display Plot (plt.show())] --> O_Plots
    S --> T[Log Highlighted Points Count / No Deviations Found] --> O_Logs

    H -- All combinations processed for a set --> F
    F -- All sets processed --> U[Log Info: Finished Plot Generation] --> O_Logs



# Class VarianceAnalyzer

## Purpose

*   The `VarianceAnalyzer` class is designed to **assess how well a forecasting model captures the variance** in the actual data.
    
*   It calculates and compares the variance of actuals, predictions, and errors. It's gives variance ratio of predictions /actuals.
    
*   It also computes the R-squared (R2) metric, which indicates the proportion of the variance in the dependent variable that is predictable from the independent variables.
    
*   The analysis helps in identifying potential issues like **overfitting** (predicted variance much higher than actuals) or **underfitting** (predicted variance much lower than actuals).

## Input Parameters

*   **`variance_analysis(self, df)`**:
    *   `df` (pd.DataFrame): A DataFrame containing the combined forecast results, which must include the columns:
        *   `'modelling_level'` (string): The aggregation level for the forecast.
            
        *   `'model_name'` (string): The name of the forecasting model (e.g., 'ARIMA', 'Prophet').
            
        *   `'error'` (numeric): The difference between actuals and predictions (Actual - Prediction).
            
        *   `'actuals'` (numeric): The true observed values.
            
        *   `'predictions'` (numeric): The forecasted values

##Code Explanation

*   **Initialization and Input Validation**:
    *   An empty list `all_variances` is initialized to store the results for each model-modelling level combination.
        
    *   It performs initial checks to ensure the input `df` contains the essential columns (`'modelling_level'`, `'model_name'`). If not, an error is logged, and an empty DataFrame is returned.
        
    *   It then extracts unique combinations of `modelling_level` and `model_name` to iterate through. If no unique combinations are found (e.g., the input DataFrame is empty), a warning is logged, and an empty DataFrame is returned.
        
*   **Iteration and Data Filtering**:
    *   The code iterates through each unique `(modelling_level, model_name)` pair.
        
    *   For each pair, `df_filtered` is created by filtering the input `df` to include only rows pertinent to the current `level` and `model`.
        
*   **Column and Data Sufficiency Check**:
    *   It checks if `df_filtered` contains all the necessary columns (`'error'`, `'actuals'`, `'predictions'`). If any are missing, a warning is printed/logged, and the combination is skipped.
        
    *   It also verifies that `df_filtered` is not empty and has at least two data points (`len(df_filtered) > 1`) before proceeding with variance calculations, as variance requires at least two observations.
        
*   **Variance Calculation**:
    *   `error`, `actuals`, and `predictions` series are extracted.
        
    *   `np.var()` is used to calculate the variance of each series. The results are rounded to 3 decimal places.
        
    *   `var_pred_act_ratio` (variance of predictions / variance of actuals) is calculated. A special check is included for `var_actuals == 0` to prevent division by zero, setting `var_ratio` to `np.nan` and logging a warning.
        
*   **R-squared Calculation**:
    *   `r2_score(actuals, predictions)` from `sklearn.metrics` is used to calculate the coefficient of determination.
        
    *   A check for `len(actuals) >= 1` is performed before calculating R2. If there's less than one data point, R2 is set to `np.nan`, and a warning is logged.
        
*   **Variance Analysis Interpretation**:
    *   An `analysis_result` string is generated based on `var_pred_act_ratio`:
        *   If `var_actuals` is zero, it indicates that the actuals are constant, making it impossible to assess the model's ability to capture variance.
            
        *   If `var_ratio > 1.05`, it suggests **overfitting** (the model's predictions are more volatile than the actual data).
            
        *   If `var_ratio < 0.95`, it suggests **underfitting** (the model's predictions are smoother or less volatile than the actual data).
            
        *   Otherwise, if `var_ratio` is close to 1 (between 0.95 and 1.05), it indicates a **well-fitted model** in terms of variance capture.
            
*   **Result Aggregation**:
    *   A dictionary containing the `modelling_level`, `model_name`, calculated variances (`var_actuals`, `var_predictions`, `var_error`), the variance ratio (`var_pred_act_ratio`), R2 (`r_squared`), and the `analysis_result` is appended to the `all_variances` list.
        
*   **Return Value**:
    *   Finally, the method returns a Pandas DataFrame constructed from the `all_variances` list, providing a comprehensive table of variance analysis results for each unique model at each modelling level.


## Output of Code

The `variance_analysis` method returns a Pandas DataFrame with the following columns for each unique `modelling_level` and `model_name` combination found in the input DataFrame:
*   `modelling_level` (string): The aggregation level.
    
*   `model_name` (string): The name of the model.
    
*   `var_actuals` (float): The variance of the actual values, rounded to 3 decimal places.
    
*   `var_predictions` (float): The variance of the predicted values, rounded to 3 decimal places.
    
*   `var_error` (float): The variance of the forecast errors, rounded to 3 decimal places.
    
*   `var_pred_act_ratio` (float): The ratio of `var_predictions` to `var_actuals`, rounded to 3 decimal places. This will be `np.nan` if `var_actuals` is zero.
    
*   `r_squared` (float): The R-squared (R2) value, rounded to 3 decimal places. This will be `np.nan` if there's insufficient data to calculate.
    
*   `analysis_result` (string): A textual interpretation of the variance analysis (e.g., "Model is possibly overfitting", "Model variance is close to actuals variance").


##Graph

    A --> M_Init
    M_Init -- Initializes Analyzer Object --> M_VarianceAnalysis

    B --> M_VarianceAnalysis
    M_VarianceAnalysis --> C{Check for 'modelling_level' & 'model_name' in df?}
    C -- No --> D[Log Error: Missing Columns] --> O_Logs
    D --> E[Return Empty DataFrame] --> O_DF

    C -- Yes --> F{Extract unique (modelling_level, model_name) combinations}
    F -- If no unique combos --> G[Log Warning: No combinations found] --> O_Logs
    G --> E

    F -- If unique combos exist --> H{Loop through each unique combination (level, model)}
    H --> I[Filter df to df_filtered for current level & model]

    I --> J{Check df_filtered for 'error', 'actuals', 'predictions'?}
    J -- No --> K[Log Warning: Skipping - Missing Required Columns] --> O_Logs

    J -- Yes --> L{Check df_filtered length (> 1 data points)?}
    L -- No --> M[Log Info: Skipping - Not Enough Data] --> O_Logs

    L -- Yes --> N[Calculate var_actuals, var_predictions, var_error]
    N --> O[Calculate var_pred_act_ratio (handle /0)]
    O --> P[Calculate r_squared (handle insufficient data)]

    P --> Q[Append Results (level, model, variances, ratios, r2) to list]

    H -- Loop Ends --> R[Convert Results List to Pandas DataFrame]
    R --> S[Log Info: Finished Variance Analysis] --> O_Logs
    R --> T[Return Results DataFrame] --> O_DF



# Class LevelChecker

## Purpose

TThe **`LevelChecker`** class is designed to perform in-depth analysis of historical and forecasted time-series data at a **quarterly period level**, focusing on **means and variances**. Its primary purpose is to identify and quantify **period-over-period changes** (Quarter-over-Quarter and Year-over-Year) and **year-over-year changes for the same period** (Quarter or Month). This helps in understanding trends, seasonality, and the stability of actuals versus predictions, making it invaluable for forecast evaluation and business planning.

##Input Parameters

*   **`__init__(self, main_folder)`**:
    *   `main_folder` (str): The base directory where plots generated by this class (if saving is enabled) will be stored.
        
    *   `logger` (logging.Logger): An instance of a Python logger for recording operational messages, warnings, and errors.
        
*   **`_save_plot(self, fig, experiment_name, modelling_level, model_name, plot_name)`**:
    *   `fig` (matplotlib.figure.Figure): The Matplotlib figure object to be saved.
        
    *   `experiment_name` (str): The name of the ongoing experiment.
        
    *   `modelling_level` (str): The specific level of aggregation (e.g., 'Brand', 'Category').
        
    *   `model_name` (str): The name of the forecasting model.
        
    *   `plot_name` (str): The desired filename for the plot (e.g., 'mean_comparison_plot').
        
*   **`level_check(self, historical_df, val_pred_df, test_pred_df, future_pred_df)`**:
    *   `historical_df` (pd.DataFrame): DataFrame containing historical actuals. It must have a 'DATE' column and columns for actuals at various modelling levels.
        
    *   `val_pred_df` (pd.DataFrame): DataFrame containing validation period predictions. Must include 'DATE', 'modelling_level', 'model_name', and 'predictions'.
        
    *   `test_pred_df` (pd.DataFrame): DataFrame containing test period predictions. Must include 'DATE', 'modelling_level', 'model_name', and 'predictions'.
        
    *   `future_pred_df` (pd.DataFrame): DataFrame containing future predictions. Must include 'DATE', 'modelling_level', 'model_name', and 'predictions'.
        
*   **`plot_level_check(self, level_analysis_results)`**:
    *   `level_analysis_results` (pd.DataFrame): The DataFrame returned by the `level_check` method, containing mean and variance data for different periods and types.
        
*   **`calculate_quarterly_changes(self, df_analysis_results, growth_threshold_pct, decline_threshold_pct)`**:
    *   `df_analysis_results` (pd.DataFrame): The DataFrame returned by the `level_check` method.
        
    *   `growth_threshold_pct` (float): The percentage threshold above which a change is considered "Significant Growth".
        
    *   `decline_threshold_pct` (float): The percentage threshold below which a change is considered "Significant Decline".
        
*   **`calculate_same_quarter_yearly_changes(self, df_analysis_results, growth_threshold_pct, decline_threshold_pct)`**:
    *   `df_analysis_results` (pd.DataFrame): The DataFrame resulting from `level_check`, containing 'Mean', 'Variance', 'Period', etc.
        
    *   `growth_threshold_pct` (float): Percentage threshold for 'Significant Growth'.
        
    *   `decline_threshold_pct` (float): Percentage threshold for 'Significant Decline'.
        
*   **`calculate_same_month_yearly_changes(self, historical_df, val_pred_df, test_pred_df, future_pred_df, growth_threshold_pct, decline_threshold_pct)`**:
    *   `historical_df` (pd.DataFrame): DataFrame containing historical actuals. Expected columns: 'date', 'modelling_level', and the actuals column (inferred).
        
    *   `val_pred_df` (pd.DataFrame): DataFrame containing validation predictions. Expected columns: 'date', 'modelling_level', 'model_name', 'predictions'.
        
    *   `test_pred_df` (pd.DataFrame): DataFrame containing test predictions. Expected columns: 'date', 'modelling_level', 'model_name', 'predictions'.
        
    *   `future_pred_df` (pd.DataFrame): DataFrame containing future predictions. Expected columns: 'date', 'modelling_level', 'model_name', 'predictions'.
        
    *   `growth_threshold_pct` (float): Percentage threshold for 'Significant Growth'.
        
    *   `decline_threshold_pct` (float): Percentage threshold for 'Significant Decline'.
        
*   **`analyze_and_plot_level_check(self, experiment_name, full_data_df, combined_val_df, combined_future_df, combined_test_df, growth_threshold_pct, decline_threshold_pct)`**:
    *   `experiment_name` (str): The name of the experiment.
        
    *   `full_data_df` (pd.DataFrame): Same as `historical_df` in `level_check`.
        
    *   `combined_val_df` (pd.DataFrame): Same as `val_pred_df` in `level_check`.
        
    *   `combined_future_df` (pd.DataFrame): Same as `future_pred_df` in `level_check`.
        
    *   `combined_test_df` (pd.DataFrame): Same as `test_pred_df` in `level_check`.
        
    *   `growth_threshold_pct` (float): Growth threshold for flagging changes.
        
    *   `decline_threshold_pct` (float): Decline threshold for flagging changes.


##Output of Code



### `level_check` 

This method calculates the quarterly mean and variance for historical actuals and different types of predictions (validation, test, future).
*   **Output:** It returns a **pandas DataFrame**. This DataFrame will contain the following columns for each `modelling_level`, `model_name` (for predictions, 'N/A' for historical), `Period` (quarter), `Period_Type` (always 'Quarterly'), `Type` (e.g., 'Actuals (Historical)', 'Predictions (Validation)'), `Mean`, and `Variance`.
    

### `plot_level_check` 

This method generates and displays line plots for the quarterly mean and variance comparisons.
*   **Output:** It returns a **tuple of two matplotlib.figure.Figure objects**:
    *   The first `Figure` object is the plot for the **Quarterly Mean Comparison**.
        
    *   The second `Figure` object is the plot for the **Quarterly Variance Comparison**.
        
    *   If the input DataFrame is empty, it returns `(None, None)`.
        
    *   It also displays these plots to the screen using `plt.show()`.
        


### `calculate_quarterly_changes` 

This method calculates Quarter-over-Quarter (QoQ) and Year-over-Year (YoY) percentage changes for the mean and variance, and flags significant changes.
*   **Output:** It returns a **pandas DataFrame**. This DataFrame is the same as the input `df_analysis_results` but with several new columns added:
    *   `Mean_QoQ_Change_Pct`: Quarterly percentage change in Mean.
        
    *   `Mean_YoY_Change_Pct`: Year-over-Year (sequential) percentage change in Mean.
        
    *   `Variance_QoQ_Change_Pct`: Quarterly percentage change in Variance.
        
    *   `Variance_YoY_Change_Pct`: Year-over-Year (sequential) percentage change in Variance.
        
    *   `Mean_QoQ_Flag`, `Mean_YoY_Flag`, `Variance_QoQ_Flag`, `Variance_YoY_Flag`: Flags indicating 'Significant Growth', 'Significant Decline', or 'Stable' based on the provided thresholds.
        


### `calculate_same_quarter_yearly_changes` 

This method calculates year-over-year changes for the _same quarter_ across different years.
*   **Output:** It returns a **pandas DataFrame**. This DataFrame includes:
    *   Original columns like `modelling_level`, `model_name`, `Type`, `Period`.
        
    *   New columns: `Year`, `Quarter_Num`, `Quarter_Str`.
        
    *   `Mean_SameQuarter_YoY_Change_Pct`: Year-over-year percentage change in Mean for the same quarter.
        
    *   `Variance_SameQuarter_YoY_Change_Pct`: Year-over-year percentage change in Variance for the same quarter.
        
    *   `Mean_SameQuarter_YoY_Flag`, `Variance_SameQuarter_YoY_Flag`: Flags indicating 'Significant Growth', 'Significant Decline', or 'Stable' for the same-quarter YoY changes.
      


### `calculate_same_month_yearly_changes` 

This method calculates year-over-year changes for the _same month_ across different years, using the raw (non-aggregated) data.
*   **Output:** It returns a **pandas DataFrame**. This DataFrame includes:
    *   Columns like `modelling_level`, `model_name`, `Type`, `date`, `Value` (the actuals or predictions for that date).
        
    *   New columns: `Year`, `Month_Num`, `Month_Str`.
        
    *   `Value_SameMonth_YoY_Change_Pct`: Year-over-year percentage change in the `Value` for the same month.
        
    *   `Value_SameMonth_YoY_Flag`: A flag indicating 'Significant Growth', 'Significant Decline', or 'Stable' for the same-month YoY changes.
        


### `analyze_and_plot_level_check` 

This method acts as an orchestrator, calling the other methods to perform the full level check analysis and generate plots.
*   **Output:** It returns a **tuple of three pandas DataFrames**:
    *   The first DataFrame is the **detailed sequential quarterly analysis** (output of `calculate_quarterly_changes`).
        
    *   The second DataFrame is the **same-quarter year-over-year changes** (output of `calculate_same_quarter_yearly_changes`).
        
    *   The third DataFrame is the **same-month year-over-year changes** (output of `calculate_same_month_yearly_changes`).
        
    *   Additionally, it calls `plot_level_check` internally, which will **display plots** for each unique `modelling_level` and `model_name` combination.


  


##Graph

        A[Start] --> B(LevelChecker.__init__)
        B -- Inputs: main_folder, logger --> C[LevelChecker Object Initialized]

        C --> D(analyze_and_plot_level_check)
        D -- Inputs: experiment_name, full_data_df, val_pred_df, test_pred_df, future_pred_df, growth_threshold_pct, decline_threshold_pct --> E{Call level_check}

        E --> F(level_check)
        F -- Outputs: level_analysis_results (quarterly means/variances) --> G{Is level_analysis_results EMPTY?}
        G -- YES --> H[Log Info: Empty results] --> I[Return 3 Empty DataFrames] --> Z[End]
        G -- NO --> J[Log Info: Level check performed]

        J --> K(calculate_quarterly_changes)
        K -- Inputs: level_analysis_results (copy), thresholds --> L[Outputs: detailed_sequential_analysis_df (QoQ/YoY changes)]
        L --> M[Log Info: Sequential changes performed]

        M --> N(calculate_same_quarter_yearly_changes)
        N -- Inputs: level_analysis_results (copy), thresholds --> O[Outputs: same_quarter_yearly_df (Same-Qtr YoY changes)]
        O --> P[Log Info: Same-quarter YoY performed]

        P --> Q(calculate_same_month_yearly_changes)
        Q -- Inputs: original DFs, thresholds --> R[Outputs: same_month_yearly_df (Same-Month YoY changes)]
        R --> S[Log Info: Same-month YoY performed]

        S --> T{Loop: For each unique (modelling_level, model_name) in level_analysis_results}
            T --> U[Filter level_analysis_results for current combo (df_filtered_for_plot)]
            U --> V{Is df_filtered_for_plot EMPTY?}
            V -- YES --> W[Log Info: No data for plotting this combo]
            W --> T
            V -- NO --> X[Log Info: Generating plots for combo]
            X --> Y(plot_level_check)
            Y -- Inputs: df_filtered_for_plot --> Z1[Outputs: fig_mean, fig_var (displayed)]
            Z1 --> Z2(Call _save_plot for fig_mean)
            Z2 --> Z3(Call _save_plot for fig_var)
            Z3 --> T
        T --> Z4[Log Info: Plotting complete]

        Z4 --> Z5[Return: detailed_sequential_analysis_df, same_quarter_yearly_df, same_month_yearly_df]
        Z5 --> Z[End]







# Class ProphetComponentsPlotter

##Purpose

The `ProphetComponentsPlotter` class is designed to **visualize the trend and seasonality components** of forecasts generated by the Facebook Prophet forecasting model. It helps in understanding the underlying patterns identified by Prophet in both historical data and future predictions.

## Input Parameters

*   **`__init__(self, main_folder)`**:
    *   `main_folder` (str): The base directory where plots will be saved. This path will be used to construct a hierarchical folder structure for organizing plots.
        
*   **`_save_plot(self, fig, experiment_name, modelling_level, model_name, plot_name)`**:
    *   `fig` (matplotlib.figure.Figure): The Matplotlib figure object to be saved.
        
    *   `experiment_name` (str): A name identifying the specific forecasting experiment. This helps in organizing saved plots.
        
    *   `modelling_level` (str): The aggregation level for which the components are being plotted.
        
    *   `model_name` (str): The name of the forecasting model (e.g., 'Prophet').
        
    *   `plot_name` (str): The specific name for the plot file (e.g., 'prophet_trend', 'prophet_seasonality').
        
*   **`plot_prophet_components(self, df_historical, df_future, modelling_level)`**:
    *   `df_historical` (pd.DataFrame): A DataFrame containing historical data, including 'date', 'trend', and 'seasonality' columns as output by Prophet's decomposition.
        
    *   `df_future` (pd.DataFrame): A DataFrame containing future predictions, also including 'date', 'trend', and 'seasonality' components from Prophet.
        
    *   `modelling_level` (str): The specific modelling level for which the components are being plotted. This is used in plot titles and for logging.
        
*   **`generate_prophet_component_plots(self, experiment_name, combined_full_trend_seasonality, combined_future_trend_df, modelling_level_list)`**:
    *   `experiment_name` (str): The name of the experiment, passed to the `_save_plot` method.
        
    *   `combined_full_trend_seasonality` (pd.DataFrame): A DataFrame containing historical trend and seasonality components for all modelling levels. It's expected to have 'DATE', 'TREND', 'SEASONALITY', and 'modelling_level' columns.
        
    *   `combined_future_trend_df` (pd.DataFrame): A DataFrame containing future trend and seasonality components for all modelling levels. It's expected to have 'DATE', 'TREND', 'SEASONALITY', and 'modelling_level' columns.
        
    *   `modelling_level_list` (list of str): A list of all unique modelling levels for which plots should be generated.



## Output of Code

The `ProphetComponentsPlotter` class's primary output is **graphical plots** displayed to the user and, if the `_save_plot` calls were uncommented, saved to a specified directory structure.
For each `modelling_level` provided in the `modelling_level_list`, the `generate_prophet_component_plots` method will:
1.  **Display Two Plots**:
    *   **Trend Plot**: A line plot showing the Prophet trend component over time. It will differentiate between "Historical Trend" (blue line) and "Future Trend" (orange line).
        
    *   **Seasonality Plot**: A line plot showing the Prophet seasonality component over time, also differentiating between "Historical Seasonality" (blue line) and "Future Seasonality" (orange line).
        
    Both plots will have titles indicating the `modelling_level` and appropriate axis labels and legends.
    
2.  **Console Output**:
    *   Informative messages will be printed to the console indicating which plots are being generated.
        
    *   If the `_save_plot` calls are uncommented, messages like "Plot saved to ..." will also appear.
        
3.  **Logged Information**:
    *   Warnings will be logged using Python's `logging` module if historical/future data or specific components ('trend', 'seasonality') are missing for a given `modelling_level`, or if no data is available at all.
        
    *   If `_save_plot` calls are uncommented, information about saved plot paths will also be logged.




##Graph

    A[Start] --> B(ProphetComponentsPlotter.__init__)

    B -- Initializes Object --> C[ProphetComponentsPlotter Object Initialized]

    C --> D(generate_prophet_component_plots)
    D -- Inputs: experiment_name, combined_full_trend_seasonality, combined_future_trend_df, modelling_level_list --> E[Log Info: Starting plot generation]

    E --> F{Are both historical and future DFs empty?}
    F -- YES --> G[Log Warning: Both DFs empty] --> H[Return (void)] --> Z[End]
    F -- NO --> I[Convert 'date' columns to datetime in input DFs]

    I --> J{Loop: For each modelling_level}
        J --> K[Log Info: Processing modelling_level]
        K --> L[Filter historical_trend_df]
        L --> M[Filter future_trend_df]

        M --> N{Is historical_trend_df AND future_trend_df EMPTY for this level?}
        N -- YES --> O[Log Warning: No data for this modelling_level] --> J
        N -- NO --> P(plot_prophet_components)
        P -- Inputs: historical_trend_df, future_trend_df, modelling_level --> Q[Plots generated, displayed, and closed internally]
        Q --> R[Log Info: Finished plotting components]
        R --> J
    J --> S[Log Info: Plot generation completed]
    S --> Z[End]

    P --> PA[Convert 'date' columns to datetime in DFs]
    PA --> PB[Initialize fig_trend]
    PB --> PC{Is historical data for trend available?}
    PC -- YES --> PD[Plot Historical Trend]
    PC -- NO --> PE[Log Warning: No historical trend data]
    PD & PE --> PF{Is future data for trend available?}
    PF -- YES --> PG[Plot Future Trend]
    PF -- NO --> PH[Log Warning: No future trend data]
    PG & PH --> PI[Set Trend Plot Properties]
    PI --> PJ[Display Trend Plot]
    PJ --> PK[Close Trend Plot]

    PK --> PL[Initialize fig_seasonality]
    PL --> PM{Is historical data for seasonality available?}
    PM -- YES --> PN[Plot Historical Seasonality]
    PM -- NO --> PO[Log Warning: No historical seasonality data]
    PN & PO --> PP{Is future data for seasonality available?}
    PP -- YES --> PQ[Plot Future Seasonality]
    PP -- NO --> PR[Log Warning: No future seasonality data]
    PQ & PR --> PS[Set Seasonality Plot Properties]
    PS --> PT[Display Seasonality Plot]
    PT --> PU[Close Seasonality Plot]
    PU --> Q



# Class STLDecomposer


##Purpose

The `STLDecomposer` class is designed to perform **Seasonal-Trend decomposition using Loess (STL)** on time series data, specifically on prediction data from various models and timeframes (validation, test, future). It then visualizes the extracted trend and seasonality components. This helps in understanding the underlying patterns and dynamics of the forecasted series of some STL Models.

##Input Parameters

*   **`__init__(self, main_folder)`**:
    *   `main_folder` (str): The base directory where the generated plots will be saved.
        
*   **`_save_plot(self, fig, experiment_name, modelling_level, model_name, plot_name)`**:
    *   `fig` (matplotlib.figure.Figure): The Matplotlib figure object to be saved.
        
    *   `experiment_name` (str): A name identifying the specific forecasting experiment. Used for folder organization.
        
    *   `modelling_level` (str): The specific level of aggregation. Used for folder organization.
        
    *   `model_name` (str): The name of the forecasting model (e.g., 'ARIMA' , 'Linear Regression'). Used for folder organization.
        
    *   `plot_name` (str): The specific filename for the plot (e.g., 'trend_plot', 'seasonality_plot').
        
*   **`generate_stl_features(self, series, date, period=12, robust=True)`**:
    *   `series` (pd.Series): The time series data (e.g., 'predictions' column) on which to perform STL decomposition.
        
    *   `date` (pd.Series): The corresponding date/time index for the `series`.
        
    *   `period` (int, optional): The period of the seasonal component.
        
    *   `robust` (bool, optional): If `True`, the decomposition uses robust M-estimation for fitting the trend and seasonal components, making it less sensitive to outliers. Default is `True`.
        
*   **`plot_stl_components(self, df_filtered, modelling_level, model_name)`**:
    *   `df_filtered` (pd.DataFrame): A DataFrame containing 'DATE', 'STL_TREND', 'STL_SEASONALITY', and 'data' (e.g., 'val', 'test', 'future') columns for a specific `modelling_level` and `model_name`.
        
    *   `modelling_level` (str): The modelling level for plot titles.
        
    *   `model_name` (str): The model name for plot titles.
        
*   **`process_stl_decomposition(self, dataframes_for_stl)`**:
    *   `dataframes_for_stl` (dict): A dictionary where keys are data types ('val', 'test', 'future') and values are Pandas DataFrames. Each DataFrame is expected to have 'DATE', 'predictions', 'modelling_level', and 'model_name' columns.
        
*   **`generate_stl_component_plots(self, experiment_name, combined_stl_df, models_stl)`**:
    *   `experiment_name` (str): The name of the experiment, passed for saving plots.
        
    *   `combined_stl_df` (pd.DataFrame): The DataFrame returned by `process_stl_decomposition`, containing STL features for all processed data.
        
    *   `models_stl` (list of str): A list of model names for which STL decomposition plots should be generated.



## Output of Code

#### `generate_stl_features` Method:

Returns a Pandas DataFrame with the STL trend and seasonality components.

#### `plot_stl_components` Method:

Returns two Matplotlib Figure objects, `fig_trend` and `fig_seasonality`, which can then be displayed or saved. These figures are not directly displayed by this method but are intended to be used by `generate_stl_component_plots`.

#### `process_stl_decomposition` Method:

Returns a consolidated Pandas DataFrame (`combined_stl_df`) containing STL trend and seasonality features for all input dataframes (validation, test, future) across different modelling levels and models.


#### `generate_stl_component_plots` Method:

This is the orchestrating method for visualization. Its primary outputs are:
1.  **Saved Plots**: For each unique `modelling_level` and `model_name` combination found in the `combined_stl_df`, it generates and saves two PNG image files:
    *   A **trend plot** (e.g., `trend_plot.png`) showing the extracted STL trend component over time, differentiating between validation, test, and future periods.
        
    *   A **seasonality plot** (e.g., `seasonality_plot.png`) showing the extracted STL seasonality component over time for the same periods. These plots are saved within the `main_folder` under a hierarchical structure like `main_folder/experiment_name/modelling_level/model_name/`.
        
2.  **Console Output**:
    *   Messages confirming that plots are being saved (e.g., "Plot saved to ...").
        
    *   Messages if no STL data is found for a particular combination of modelling level and model.
        
    *   `df_filtered_stl.head(1)` output for debugging purposes.
        
3.  **Logged Information**:
    *   Similar to console output, information about saved plot paths and warnings about missing data will be logged.



# Class ShapExplainerVisualizer

##Purpose

The `ShapExplainerVisualizer` class is designed to **visualize SHAP (SHapley Additive exPlanations) values** for machine learning models, helping to interpret model predictions by showing the contribution of each feature. It specifically generates:
1.  **Global Feature Importance plots**: Summarize the overall importance of features across the entire dataset.
    
2.  **SHAP Waterfall plots**: Explain individual predictions by showing how each feature pushes the prediction from the base value to the final output.
    
3.  **SHAP Summary plots**: Provide a comprehensive overview of feature importance and impact, showing the distribution of SHAP values for each feature.


## Input Parameters

*   **`__init__(self, main_folder)`**:
    *   `main_folder` (str): The root directory where all generated SHAP plots will be saved.
        
*   **`_save_plot(self, fig, experiment_name, modelling_level, model_name, plot_name, subfolder=None)`**:
    *   `fig` (matplotlib.figure.Figure): The Matplotlib figure object to be saved.
        
    *   `experiment_name` (str): A string identifying the current experiment.
        
    *   `modelling_level` (str): The specific aggregation level.
        
    *   `subfolder` (str, optional): An optional subfolder name within the model's directory (e.g., 'waterfall_plots') for further organization.
        
*   **`plot_global_feature_importance(self, importance_values_df, experiment_name, modelling_level, model_name, top_n_features=None)`**:
    *   `importance_values_df` (pd.DataFrame): A DataFrame containing global feature importance, expected to have 'VARIABLE' (feature name), 'IMPORTANCE' (importance score), 'model_name', and 'modelling_level' columns.
        
    *   `experiment_name`, `modelling_level`, `model_name`: Used for plot title and saving paths.
        
    *   `top_n_features` (int, optional): If provided, only the top N most important features are plotted. If `None`, all non-zero importance features are plotted.
        
*   **`plot_waterfall(self, shap_values_df, features_df, expected_value, experiment_name, modelling_level, model_name, dates_to_plot=None)`**:
    *   `shap_values_df` (pd.DataFrame): DataFrame containing SHAP values for individual predictions, expected to have 'DATE', 'model_name', 'modelling_level', and columns for each feature's SHAP value.
        
    *   `features_df` (pd.DataFrame): DataFrame containing the actual feature values corresponding to the SHAP values, expected to have 'DATE' and columns for each feature's value.
        
    *   `expected_value` (float/int): The expected value (or base value) of the model's output, which is the average of the model's predictions when no features are present.
        
    *   `experiment_name`, `modelling_level`, `model_name`: Used for plot titles and saving paths.
        
    *   `dates_to_plot` (list of datetime-like, optional): A list of specific dates for which waterfall plots should be generated. If `None`, plots for all dates in `shap_values_df`.
        
*   **`plot_summary(self, shap_values_df, features_df, experiment_name, modelling_level, model_name, plot_name)`**:
    *   `shap_values_df` (pd.DataFrame): DataFrame of SHAP values, similar to `plot_waterfall`.
        
    *   `features_df` (pd.DataFrame): DataFrame of feature values, similar to `plot_waterfall`.
        
    *   `experiment_name`, `modelling_level`, `model_name`: Used for plot titles and saving paths.
        
    *   `plot_name` (str): Specific name for the summary plot file.
        
*   **`process_shap_data(self, shap_values_df, shap_values_future, features_df, feature_df_future, importance_values_df, expected_value_df, experiment_name, pred_start=None, pred_end=None, future_start=None, future_end=None, global_importance_top_n=None)`**:
    *   `shap_values_df` (pd.DataFrame): SHAP values for a _prediction/historical_ period.
        
    *   `shap_values_future` (pd.DataFrame): SHAP values for a _future_ prediction period.
        
    *   `features_df` (pd.DataFrame): Feature values for the _prediction/historical_ period.
        
    *   `feature_df_future` (pd.DataFrame): Feature values for the _future_ prediction period.
        
    *   `importance_values_df` (pd.DataFrame): Global feature importance data.
        
    *   `expected_value_df` (pd.DataFrame): Contains the `expected_value` for different models/levels.
        
    *   `experiment_name` (str): The name of the overall experiment.
        
    *   `pred_start`, `pred_end` (str, optional): Date range for the prediction period (e.g., '2023-01-01').
        
    *   `future_start`, `future_end` (str, optional): Date range for the future prediction period.
        
    *   `global_importance_top_n` (int, optional): Number of top features to display in the global importance plot.



##Graph

    A[Start] --> B(ShapExplainerVisualizer.__init__)
    B -- Initializes Object --> C[ShapExplainerVisualizer Object Initialized]

    C --> D(process_shap_data)
    D -- Inputs: shap_values_df, shap_values_future, features_df, feature_df_future, importance_values_df, expected_value_df, experiment_name, date_ranges, top_n --> E{Is shap_values_df EMPTY?}
    E -- YES --> F[Log Warning: Empty SHAP values DF] --> G[Return (void)] --> Z[End]
    E -- NO --> H[Convert 'date' columns to datetime in future DFs]
    H --> I[Convert date range strings to datetime objects]

    I --> J{Loop: For each modelling_level}
        J --> K{Loop: For each model_name}
            K --> L[Log Info: Processing SHAP plots for model, level]
            L --> M[Filter shap_values_df for filtered_shap_values_df]
            M --> N[Calculate waterfall_start_date & waterfall_end_date from all date ranges]

            N --> O{Are waterfall_start_date OR waterfall_end_date None?}
            O -- YES --> P[Log Warning: Insufficient date range for waterfall] --> K
            O -- NO --> Q[Log Info: Using flexible date range for waterfall]
            Q --> R[Filter shap_values_future for filtered_shap_future_df based on date range]

            R --> S[Filter expected_value_df for current model/level]
            S --> T[Filter features_df for features_df_filtered]
            T --> U[Filter feature_df_future for features_future_df_filtered based on date range]

            U --> V{Is filtered_expected_value_for_context_df NOT empty?}
            V -- YES --> W[Extract current_expected_value]
            W --> X{Is current_expected_value NOT numeric?}
            X -- YES --> Y[Log Error: Expected value not numeric] --> Z0[Set current_expected_value to None]
            X -- NO --> Z0
            V -- NO --> Z0[Log Warning: No expected value found]
            Z0 --> Z1{Is filtered_shap_values_df EMPTY OR current_expected_value is None?}
            Z1 -- YES --> K
            Z1 -- NO --> Z2(plot_global_feature_importance)
            Z2 -- Inputs: importance_values_df, experiment_name, modelling_level, model_name, global_importance_top_n --> Z3[Global Importance Plot displayed/closed]

            Z3 --> Z4(plot_summary)
            Z4 -- Inputs: filtered_shap_values_df, features_df_filtered, experiment_name, modelling_level, model_name --> Z5[Summary Plot displayed/closed]

            Z5 --> Z6{Is filtered_shap_future_df NOT empty?}
            Z6 -- YES --> Z7(plot_waterfall)
            Z7 -- Inputs: filtered_shap_future_df, features_future_df_filtered, current_expected_value, experiment_name, modelling_level, model_name, dates_to_plot --> Z8[Waterfall Plots displayed/closed]
            Z8 --> Z9[Log Info: SHAP plots generated]
            Z9 --> K
            Z6 -- NO --> Z10[Log Info: No future SHAP data for waterfall] --> Z9
        K --> J
    J --> Z[End]


    Z2 --> P_GFI(plot_global_feature_importance)
    P_GFI -- Inputs: importance_values_df, experiment_name, modelling_level, model_name, top_n_features --> P_GFI_A{Is importance_values_df None?}
    P_GFI_A -- YES --> P_GFI_B[Log Warning] --> Z3
    P_GFI_A -- NO --> P_GFI_C[Copy importance_values_df]
    P_GFI_C --> P_GFI_D{Do 'model_name' AND 'modelling_level' columns exist?}
    P_GFI_D -- YES --> P_GFI_E[Filter DF for current model/level]
    P_GFI_E --> P_GFI_F{Is filtered DF empty OR missing 'features'/'importance'?}
    P_GFI_F -- YES --> P_GFI_G[Log Warning] --> Z3
    P_GFI_F -- NO --> P_GFI_H[Create feature_importance Series]
    P_GFI_H --> P_GFI_I[Filter non-zero importance]
    P_GFI_I --> P_GFI_J{Is top_n_features valid and > 0?}
    P_GFI_J -- YES --> P_GFI_K[Select top N features]
    P_GFI_J -- NO --> P_GFI_L[Select all non-zero features]
    P_GFI_K & P_GFI_L --> P_GFI_M[Log Info: Plotting top N / all non-zero features]
    P_GFI_M --> P_GFI_N{Is feature_importance_to_plot empty?}
    P_GFI_N -- YES --> P_GFI_O[Log Warning: No non-zero features] --> Z3
    P_GFI_N -- NO --> P_GFI_P[Create plot figure]
    P_GFI_P --> P_GFI_Q[Plot barh chart]
    P_GFI_Q --> P_GFI_R[Set plot properties]
    P_GFI_R --> P_GFI_S[Display Plot]
    P_GFI_S --> P_GFI_T[Close Plot] --> Z3
    P_GFI_D -- NO --> P_GFI_U[Log Warning: Missing 'model_name' or 'modelling_level'] --> Z3

    Z7 --> P_WF(plot_waterfall)
    P_WF -- Inputs: shap_values_df, features_df, expected_value, experiment_name, modelling_level, model_name, dates_to_plot --> P_WF_A{Are SHAP or features DFs empty?}
    P_WF_A -- YES --> P_WF_B[Log Warning] --> Z8
    P_WF_A -- NO --> P_WF_C[Extract numeric feature columns]
    P_WF_C --> P_WF_D{Are there no plot_feature_names?}
    P_WF_D -- YES --> P_WF_E[Log Warning] --> Z8
    P_WF_D -- NO --> P_WF_F[Merge SHAP and features DFs]
    P_WF_F --> P_WF_G[Filter merged_df by model_name]
    P_WF_G --> P_WF_H[Identify relevant_features_for_plot (non-NaN/zero SHAP values)]
    P_WF_H --> P_WF_I{Are there no relevant_features_for_plot?}
    P_WF_I -- YES --> P_WF_J[Log Warning] --> Z8
    P_WF_I -- NO --> P_WF_K{Is dates_to_plot None?}
    P_WF_K -- YES --> P_WF_L[Use all unique dates from merged_df]
    P_WF_K -- NO --> P_WF_M[Filter merged_df by dates_to_plot]
    P_WF_M --> P_WF_N{Is filtered merged_df empty?}
    P_WF_N -- YES --> P_WF_O[Log Warning] --> Z8
    P_WF_N -- NO --> P_WF_P{Loop: For each row (date) in filtered merged_df}
        P_WF_P --> P_WF_Q[Extract SHAP and feature values for current instance]
        P_WF_Q --> P_WF_R[Create shap.Explanation object]
        P_WF_R --> P_WF_S[Create plot figure]
        P_WF_S --> P_WF_T[Call shap.waterfall_plot]
        P_WF_T --> P_WF_U[Set plot title, tight_layout]
        P_WF_U --> P_WF_V[Display Plot]
        P_WF_V --> P_WF_W[Close Plot] --> P_WF_P
    P_WF_P --> Z8

    Z4 --> P_SUM(plot_summary)
    P_SUM -- Inputs: shap_values_df, features_df, experiment_name, modelling_level, model_name, plot_name --> P_SUM_A{Is shap_values_df empty?}
    P_SUM_A -- YES --> P_SUM_B[Log Warning] --> Z5
    P_SUM_A -- NO --> P_SUM_C[Extract numeric feature columns]
    P_SUM_C --> P_SUM_D[Identify relevant_features_for_plot (non-NaN/zero SHAP values)]
    P_SUM_D --> P_SUM_E{Are there no relevant_features_for_plot?}
    P_SUM_E -- YES --> P_SUM_F[Log Warning] --> Z5
    P_SUM_E -- NO --> P_SUM_G[Extract SHAP values array]
    P_SUM_G --> P_SUM_H[Extract feature values array]
    P_SUM_H --> P_SUM_I[Create plot figure]
    P_SUM_I --> P_SUM_J[Call shap.summary_plot]
    P_SUM_J --> P_SUM_K[Set plot title, tight_layout]
    P_SUM_K --> P_SUM_L[Display Plot]
    P_SUM_L --> P_SUM_M[Close Plot] --> Z5





# Class ProphetRegressorCoefficientsPlotter

## Purpose

The `ProphetRegressorCoefficientsPlotter` class is designed to visualize the insights gained from a Prophet model, particularly focusing on:
1.  **Coefficients of Extra Regressors**: For multivariate Prophet models, it plots the learned coefficients of any additional regressors (features) included in the model. This helps in understanding the linear impact of each regressor on the forecast.
    
2.  **Average Absolute Component Contributions**: It quantifies and visualizes the relative importance of different Prophet components (trend, seasonality, holidays, and extra regressors) across different time periods (historical, prediction, future). This provides a normalized view of which components are driving the forecast the most.

## Input Parameters

*   **`__init__(self, prophet_full_df, prophet_components_df, main_folder, top_n_features)`**:
    *   `prophet_full_df` (pd.DataFrame): A DataFrame containing information about the Prophet model's regressors, specifically including 'modelling_level', 'regressor', and 'coef' columns. This typically comes from a processed output of Prophet's regressor coefficients.
        
    *   `prophet_components_df` (pd.DataFrame): A DataFrame containing the individual components of the Prophet forecast (e.g., 'trend', 'yearly', 'daily', 'extra_regressor_1', etc.), along with 'ds' (date), 'yhat' (forecast), 'modelling_level', and 'model_name'.
        
    *   `main_folder` (str): The root directory where all generated plots will be saved.
        
    *   `top_n_features` (int): The default number of top features/components to display in plots based on their importance/magnitude.
        
*   **`_save_plot(self, fig, experiment_name, modelling_level, model_name, plot_name)`**:
    *   `fig` (matplotlib.figure.Figure): The Matplotlib figure object to be saved.
        
    *   `experiment_name` (str): A string identifying the current experiment.
        
    *   `modelling_level` (str): The specific aggregation level.
        
    *   `model_name` (str): The name of the Prophet model (e.g., 'prophet_multivariate').
        
    *   `plot_name` (str): The base name for the plot file.
        
*   **`plot_coefficients(self, experiment_name, top_n_features=None)`**:
    *   `experiment_name` (str): Used for plot titles and saving paths.
        
    *   `top_n_features` (int, optional): Overrides the `self.top_n_features` set in `__init__` if provided, allowing specific control for this plot.
        
*   **`calculate_average_contribution(self, filtered_components_df)`**:
    *   `filtered_components_df` (pd.DataFrame): A subset of `prophet_components_df` for a specific modelling level and date range. This function is an internal helper.
        
*   **`plot_average_contribution(self, experiment_name, pred_start=None, pred_end=None, future_start=None, future_end=None, top_n_features=None)`**:
    *   `experiment_name` (str): Used for plot titles and saving paths.
        
    *   `pred_start`, `pred_end` (str, optional): Date range for the historical/prediction period.
        
    *   `future_start`, `future_end` (str, optional): Date range for the future prediction period.
        
    *   `top_n_features` (int, optional): Overrides `self.top_n_features` for this specific plot.


## Output of Code

The `ProphetRegressorCoefficientsPlotter` class generates two main types of plots, which are displayed.
For each unique `modelling_level` found in your input data:
1.  **Regressor Coefficients Plot**:
        
    *   **Interpretation**:
        *   The **length of the bar** indicates the magnitude of the coefficient.
            
        *   The **direction of the bar** (positive or negative) indicates whether the regressor has a positive or negative linear impact on the forecast. For example, a positive coefficient means an increase in the regressor's value leads to an increase in the predicted `yhat`.
            
        *   Only the `top_n_features` (most impactful) regressors are displayed.
        
        
2.  **Average Absolute Component Contribution Plot**:
 
        
    *   **Interpretation**:
        *   This plot helps you see **which components (trend, seasonalities, specific regressors) were most influential** in driving the forecast during different periods.
            
        *   For example, you might see that "yearly" seasonality has a high contribution in both historical and future periods, while a "holiday" regressor might only contribute significantly in specific prediction periods.
            
        *   The `top_n_features` (most influential) components are displayed.
            
    *   This plot provides a more holistic view of the model's behavior by showing the _relative_ importance of all its building blocks.



Graph

    A[Start] --> B(ProphetRegressorCoefficientsPlotter.__init__)
    B -- Inputs: prophet_full_df, prophet_components_df, main_folder, top_n_features, logger --> C[ProphetRegressorCoefficientsPlotter Object Initialized]

    C --> D(plot_coefficients)
    D -- Inputs: experiment_name, top_n_features (optional) --> E[Filter df to include non-null, non-zero coefficients]

    E --> F{Loop: For each modelling_level in filtered df}
        F --> G[Calculate absolute coefficient (abs_coef)]
        G --> H[Sort by abs_coef descending and take top_n_features]
        H --> I[Drop abs_coef column]
        I --> J[Create plot figure]
        J --> K[Plot barplot of coefficients]
        K --> L[Set plot title, labels, layout]
        L --> M[Display Plot (plt.show())]
        M --> N[Close Plot (plt.close())]
        N --> F
    F --> O[Log Info: Coefficient Plots saved]
    O --> Z[End]

    C --> P(plot_average_contribution)
    P -- Inputs: experiment_name, date_ranges (pred_start, pred_end, future_start, future_end), top_n_features --> Q{Is self.components_df EMPTY?}
    Q -- YES --> R[Log Warning: Components DF empty] --> Z[End]
    Q -- NO --> S[Convert 'date' column in self.components_df to datetime]
    S --> T[Convert date range strings to datetime objects]

    T --> U{Loop: For each modelling_level in self.components_df}
        U --> V[Filter self.components_df for level_components_df]
        V --> W{Is level_components_df EMPTY?}
        W -- YES --> X[Log Warning: No components data for level] --> U
        W -- NO --> Y[Initialize contributions_to_plot list]

        Y --> Z1{Is pred_start_dt provided?}
        Z1 -- YES --> Z2[Filter historical data before pred_start_dt (past_df)]
        Z2 --> Z3{Is past_df NOT empty?}
        Z3 -- YES --> Z4(calculate_average_contribution)
        Z4 -- Inputs: past_df --> Z5[Outputs: avg_past_contributions]
        Z5 --> Z6{Is avg_past_contributions NOT empty?}
        Z6 -- YES --> Z7[Create df_past, add 'Date_Range'='Historical']
        Z7 --> Z8[Append df_past to contributions_to_plot]
        Z8 --> Z9
        Z6 -- NO --> Z10[Log Info: No non-zero contributions for Historical] --> Z9
        Z3 -- NO --> Z11[Log Info: No historical data before pred_start_dt] --> Z9
        Z1 & Z9 --> Z12

        Z12 --> Z13{Are pred_start_dt AND pred_end_dt provided?}
        Z13 -- YES --> Z14[Filter prediction data within range (prediction_df)]
        Z14 --> Z15{Is prediction_df NOT empty?}
        Z15 -- YES --> Z16(calculate_average_contribution)
        Z16 -- Inputs: prediction_df --> Z17[Outputs: avg_prediction_contributions]
        Z17 --> Z18{Is avg_prediction_contributions NOT empty?}
        Z18 -- YES --> Z19[Create df_pred, add 'Date_Range'='Prediction']
        Z19 --> Z20[Append df_pred to contributions_to_plot]
        Z20 --> Z21
        Z18 -- NO --> Z22[Log Info: No non-zero contributions for Prediction] --> Z21
        Z15 -- NO --> Z23[Log Info: No data in prediction range] --> Z21
        Z13 & Z21 --> Z24

        Z24 --> Z25{Are future_start_dt AND future_end_dt provided?}
        Z25 -- YES --> Z26[Filter future data within range (future_df)]
        Z26 --> Z27{Is future_df NOT empty?}
        Z27 -- YES --> Z28(calculate_average_contribution)
        Z28 -- Inputs: future_df --> Z29[Outputs: avg_future_contributions]
        Z29 --> Z30{Is avg_future_contributions NOT empty?}
        Z30 -- YES --> Z31[Create df_future, add 'Date_Range'='Future']
        Z31 --> Z32[Append df_future to contributions_to_plot]
        Z32 --> Z33
        Z30 -- NO --> Z34[Log Info: No non-zero contributions for Future] --> Z33
        Z27 -- NO --> Z35[Log Info: No data in future range] --> Z33
        Z25 & Z33 --> Z36

        Z36 --> Z37{Is contributions_to_plot EMPTY?}
        Z37 -- YES --> Z38[Log Warning: No valid contributions] --> U
        Z37 -- NO --> Z39[Concatenate contributions_to_plot into combined_contributions_df]
        Z39 --> Z40[Convert 'Component' to category type]
        Z40 --> Z41[Calculate component_order based on mean contribution (top_n_features)]
        Z41 --> Z42[Create plot figure]
        Z42 --> Z43[Plot barplot of average contributions]
        Z43 --> Z44[Set plot properties]
        Z44 --> Z45[Display Plot (plt.show())]
        Z45 --> Z46[Close Plot (plt.close())]
        Z46 --> U
    U --> Z47[Log Info: Prophet component contribution plots generated]
    Z47 --> Z[End]

    Z4 --> P_CAC(calculate_average_contribution)
    P_CAC -- Inputs: filtered_components_df --> P_CAC_A[Identify non-component and component columns]
    P_CAC_A --> P_CAC_B{Are there no component_cols?}
    P_CAC_B -- YES --> P_CAC_C[Log Warning] --> P_CAC_D[Return empty Series]
    P_CAC_B -- NO --> P_CAC_E{Is filtered_components_df index unique?}
    P_CAC_E -- NO --> P_CAC_F[Log Warning, Reset index]
    P_CAC_E -- YES --> P_CAC_G[Proceed]
    P_CAC_F & P_CAC_G --> P_CAC_H[Calculate absolute contributions]
    P_CAC_H --> P_CAC_I[Calculate sum of absolute contributions per row (sum_of_abs_contributions_per_ds)]
    P_CAC_I --> P_CAC_J[Scale absolute contributions by dividing by sum_of_abs_contributions_per_ds]
    P_CAC_J --> P_CAC_K[Calculate average_scaled_contributions (mean across rows)]
    P_CAC_K --> P_CAC_L[Sort average_scaled_contributions descending]
    P_CAC_L --> Z5 OR Z17 OR Z29
