import pandas as pd

def run_unleashed_miner():
    print("Loading massive datasets...")
    try:
        players = pd.read_csv('data/nba_player_logs_2012_2026.csv')
        stocks = pd.read_csv('data/sp500_stock_data_2012_2026.csv')
    except Exception as e:
        print(f"Error loading data: {e}")
        return

    players['GAME_DATE'] = pd.to_datetime(players['GAME_DATE']).dt.tz_localize(None)
    stocks['Date'] = pd.to_datetime(stocks['Date']).dt.tz_localize(None)
    stocks.sort_values(by=['Ticker', 'Date'], inplace=True)
    
    print("Calculating daily movements for all 500 companies...")
    stocks['Pct_Change'] = stocks.groupby('Ticker')['Close'].pct_change() * 100
    stocks['Went_Up'] = stocks['Pct_Change'] > 0
    stocks['Went_Down'] = stocks['Pct_Change'] < 0

    stock_dates = sorted(stocks['Date'].unique())
    stock_date_df = pd.DataFrame({'Stock_Date': stock_dates})
    
    def get_next_trading_day(game_date):
        future = stock_date_df[stock_date_df['Stock_Date'] > game_date]
        if not future.empty:
            return future.iloc[0]['Stock_Date']
        return pd.NaT

    unique_game_dates = pd.DataFrame({'GAME_DATE': players['GAME_DATE'].unique()})
    unique_game_dates['Next_Trading_Date'] = unique_game_dates['GAME_DATE'].apply(get_next_trading_day)
    players = pd.merge(players, unique_game_dates, on='GAME_DATE', how='left')

    # Massive 80+ Player List (Legends, Current Superstars, and Emerging Rookies)
    massive_player_list = [
        # Legends & Vets
        "LeBron James", "Stephen Curry", "Kevin Durant", "James Harden", "Russell Westbrook",
        "Chris Paul", "Carmelo Anthony", "Kobe Bryant", "Dwyane Wade", "Dirk Nowitzki", "Paul George",
        "Kawhi Leonard", "Jimmy Butler", "Damian Lillard", "Kyrie Irving", "Anthony Davis",
        "Draymond Green", "Klay Thompson", "DeMar DeRozan", "Bradley Beal",
        
        # Prime Superstars
        "Giannis Antetokounmpo", "Nikola Jokic", "Luka Doncic", "Joel Embiid", "Jayson Tatum",
        "Devin Booker", "Donovan Mitchell", "Jaylen Brown", "De'Aaron Fox", "Zion Williamson",
        "Ja Morant", "Trae Young", "Shai Gilgeous-Alexander", "Karl-Anthony Towns", "Domantas Sabonis",
        "Bam Adebayo", "Julius Randle", "Pascal Siakam", "Brandon Ingram", "Jamal Murray",
        
        # Emerging / New Gen
        "Anthony Edwards", "Victor Wembanyama", "Tyrese Haliburton", "Jalen Brunson", "Paolo Banchero",
        "Chet Holmgren", "Tyrese Maxey", "Alperen Sengun", "Scottie Barnes", "Evan Mobley",
        "Cade Cunningham", "Jalen Green", "Josh Giddey", "Franz Wagner", "Brandon Miller",
        "Scoot Henderson", "Ausar Thompson", "Amen Thompson", "Dereck Lively II", "Jaime Jaquez Jr.",
        "Keyonte George", "Cam Thomas", "Jalen Williams", "Walker Kessler", "Keegan Murray"
    ]
    
    players = players[players['PLAYER_NAME'].isin(massive_player_list)]

    events = []
    print("Extracting anomalies...")
    
    for _, row in players.iterrows():
        p_name = row['PLAYER_NAME']
        date = row['Next_Trading_Date']
        if pd.isna(date): continue
            
        pts = row['PTS']
        ast = row['AST']
        reb = row['REB']
        tov = row['TOV']
        fga = row['FGA']
        pm = row['PLUS_MINUS']
        threes = row['FG3M']
        
        if pts >= 40: events.append({'Date': date, 'Event': f"{p_name} scores 40+"})
        if ast >= 14: events.append({'Date': date, 'Event': f"{p_name} dishes 14+ Assists"})
        if tov >= 7: events.append({'Date': date, 'Event': f"{p_name} turns it over 7+ times"})
        if fga >= 28: events.append({'Date': date, 'Event': f"{p_name} is a ball-hog (28+ FGA)"})
        if threes >= 8: events.append({'Date': date, 'Event': f"{p_name} hits 8+ Threes"})
        if pd.notna(pm):
            if pm >= 25: events.append({'Date': date, 'Event': f"{p_name} dominates with +25 Plus/Minus"})
            if pm <= -25: events.append({'Date': date, 'Event': f"{p_name} is a liability with -25 Plus/Minus"})

    events_df = pd.DataFrame(events).drop_duplicates()
    unique_events = events_df['Event'].unique()
    all_tickers = stocks['Ticker'].unique()
    
    results = []
    print(f"Cross-referencing {len(unique_events)} unique events against {len(all_tickers)} companies...")
    
    # Pre-group stocks by Ticker for faster lookup
    stock_groups = stocks.groupby('Ticker')
    
    for event_name in unique_events:
        event_dates = events_df[events_df['Event'] == event_name]['Date']
        num_occurrences = len(event_dates)
        
        # Raise N to 50 for massive sample sizes, but lower accuracy to 70% minimum
        if num_occurrences < 50:
            continue
            
        for ticker in all_tickers:
            try:
                stock_slice = stock_groups.get_group(ticker)
                event_stock_slice = stock_slice[stock_slice['Date'].isin(event_dates)]
                if len(event_stock_slice) == 0: continue
                
                up_days = event_stock_slice['Went_Up'].sum()
                down_days = event_stock_slice['Went_Down'].sum()
                total = len(event_stock_slice)
                
                up_pct = (up_days / total) * 100
                down_pct = (down_days / total) * 100
                
                if up_pct >= 70:
                    results.append({
                        'Pattern': f"Whenever {event_name}, {ticker} stock GOES UP!",
                        'Accuracy': up_pct,
                        'Occurrences': total,
                    })
                elif down_pct >= 70:
                    results.append({
                        'Pattern': f"Whenever {event_name}, {ticker} stock CRASHES!",
                        'Accuracy': down_pct,
                        'Occurrences': total,
                    })
            except KeyError:
                continue

    res_df = pd.DataFrame(results)
    if not res_df.empty:
        res_df.sort_values(by=['Accuracy', 'Occurrences'], ascending=[False, False], inplace=True)
        res_df.to_csv('data/unleashed_market_patterns.csv', index=False)
        print("\n=== TOP 25 ABSURD OBSCURE PATTERNS ===\n")
        for _, row in res_df.head(25).iterrows():
            print(f"{row['Pattern']} ({row['Accuracy']:.1f}% accuracy, N={row['Occurrences']})")
    else:
        print("No patterns met the threshold.")

if __name__ == "__main__":
    run_unleashed_miner()
