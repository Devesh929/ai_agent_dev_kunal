In this wiki, i'm going to cover the Cons Calculation for forecasting project.

## **What is Cons?**

ABB has 4 Business Areas i.e. EL, MO, PA, RA. Data for these Business Areas can be extracted using Mgmt column in ABACUS. But ABACUS also have 5 more values in Mgmt field - Cons (EL), Cons (EL), Cons (MO), Cons (PA), Cons (RA). These values are mostly negative and very small compared to their division numbers. They are zero for most of the KPIs except these KPIs of our interest orders_received_net, revenues_net, base_orders_net and operational_cost_of_sales_net.

Cons stand for consolidation. Since one BA has multiple Divisions. We dont straight up add those divisions to get values of BA. There are lot of adjustments, which are being made to get to the BA number. These Adjustments mainly include trading within a BA across its divisions. Since Divisions also trade among themselves, we dont want to double calculate on revenues and orders. Hence we subtract this value from the sum of divisions to get BA numbers.

For Example - Lets say two divisions in EL, trade among themselves. ELIP sold product worth of 2mUSD to ELDS. ELDS then modified or used that product and sold to third party for 3mUSD. Revenue realized for ELIP is 2mUSD and for ELDS is 3mUSD. Total for EL will be 5mUSD. But only 3mUSD product was sold outside EL Business Area. So when we look at this from the lens of BA, 2mUSD was an internal transaction, which should'nt be accounted for calculating Revenues or Orders. But in ABACUS/Reporting, Revenues for ELDS is 5mUSD and ELIP is 2mUSD. After we sum them up to get Revenues for EL, we subtract 2mUSD. This subtraction is called Cons (EL) in ABACUS.

Cons also exist in ABB level. Cons at ABB level represents transactions within ABB, across its divisions.

# **Why we need Cons in our Forecasting Project?**

As you know its better to forecast division level and then aggregate it to BA level. We will get better accuracy. This is being realized through our previous experiments. Also there is business requirement to forecast for Division level. And if we forecast on BA level too, then we will be giving two different numbers to the Business. Hence, our approach is to forecast Divisions and sum them up to get forecast of BAs, and sum BAs up to get forecast of ABB. While summing these divisions/BAs forecast, we need to forecast their respective Cons too, and subtract them from forecasts. Otherwise, our forecast wont represent true picture.

# **How to calculate Cons for forecast?**

In future, we might try forecasting Cons as a separate KPI. But for now we are calculating them using rolling mean of their percentages.
Firstly, Cons% (contribution of Cons in its BA) is being calculated which is: `(Cons of BA)/(sum of divisions)`. This is being calculated till the date we have data for forecasting. Lets say we are forecasting from 2025-July to 2025-September. We have data till 2025-June. So we calculate this Cons% till 2025-June. Then we do rolling 3 months average for future periods. Value of Cons% in 2025-July will be `average of its last 3 months (june, may, april)`. Similarly, value of Cons% in 2025-Aug will be average of its last 3 months (july, june, may). This will give us a forward looking view of Cons%.

After getting Cons% numbers for future, we can use them to get forecast for BA.
Firstly, we get forecast of Cons, which will be : `(Sum of forecast of Divisions) * (Cons% forecast)`
Since Cons% represented contribution of cons within its BA, so we get Cons just by multiplying this % with sum of Divisions.
This number should be then subtracted from Sum of forecast of Divisions. This will give us forecast for BA.
Forecast for BA will be : `(Sum of forecast of Divisions) - (Cons forecast)`

This should be done for testing period too.

Cons Appear only for Orders, Base Orders, Revenues and Cost of sales. It wont appear for any other KPI.
We already know why Cons is there for Revenues. Same reason apply to Orders and base orders.
You would also notice that Cons data is -ve for orders, revenues, base orders, but for cost of sales, cons is +ve.
The reason being, cost of sales itself is a negative KPI.

When a transaction is being in done within a BA. Its cost price is also being calculated twice. Hence we need to add some number back to not include its two times when we look at it from BA level.

Also cons doesnt appear in any other line item in Income Statement because it is being cancelled out from revenues and cost of sales. Revenues and cost of sales have same value of cons in opposite sign. This is being observed in EL. So when we calculate forecast of gross profit which will be: forecast of revenue + forecast of cost of sales(-ve). Cons for GP will be zero because cons of revenue(-ve) will cancel out cons of cost of sales(+ve). And similarly for Operational EBITA.

# **Example**
Lets do an example for this whole thing.
Lets say Cons (EL) and its divisions data looks like this - 

| date | Cons (EL) | ELDS | ELIP | ELSB | ELSE | ELSP |
| --- | --- | --- | --- | --- | --- | --- |
| 2025-01-01 00:00:00 | -40.2987 | 300.8703 | 162.3132 | 231.7404 | 71.4172 | 446.5333 |
| 2025-02-01 00:00:00 | -37.0958 | 285.8165 | 178.0392 | 249.862 | 91.2627 | 482.5468 |
| 2025-03-01 00:00:00 | -58.5993 | 399.3709 | 184.1856 | 302.8057 | 107.7079 | 555.8292 |
| 2025-04-01 00:00:00 | -47.5467 | 351.8849 | 181.8974 | 274.8211 | 96.4693 | 522.0821 |
| 2025-05-01 00:00:00 | -52.8924 | 356.6507 | 184.3501 | 273.6907 | 93.7178 | 525.8591 |
| 2025-06-01 00:00:00 | -57.7917 | 463.5547 | 184.5194 | 274.531 | 120.7548 | 558.2046 |

We have to forecast from 2025-July. (It can be future period or test period or validation period)
First, we will calculate Cons% till 2025June. Which will be: `Abs(Cons (EL))/(ELDS+ELIP+ELSB+ELSE+ELSP)`

| date | Cons (EL) | ELDS | ELIP | ELSB | ELSE | ELSP | Cons (EL) % 2506 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 2025-01-01 00:00:00 | -40.2987 | 300.8703 | 162.3132 | 231.7404 | 71.4172 | 446.5333 | 3.32% |
| 2025-02-01 00:00:00 | -37.0958 | 285.8165 | 178.0392 | 249.862 | 91.2627 | 482.5468 | 2.88% |
| 2025-03-01 00:00:00 | -58.5993 | 399.3709 | 184.1856 | 302.8057 | 107.7079 | 555.8292 | 3.78% |
| 2025-04-01 00:00:00 | -47.5467 | 351.8849 | 181.8974 | 274.8211 | 96.4693 | 522.0821 | 3.33% |
| 2025-05-01 00:00:00 | -52.8924 | 356.6507 | 184.3501 | 273.6907 | 93.7178 | 525.8591 | 3.69% |
| 2025-06-01 00:00:00 | -57.7917 | 463.5547 | 184.5194 | 274.531 | 120.7548 | 558.2046 | 3.61% |

Now, using rolling average of past 3 periods, we will forecast this Cons% for future periods:

| date | Cons (EL) | ELDS | ELIP | ELSB | ELSE | ELSP | Cons (EL) % 2506 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 2025-01-01 00:00:00 | -40.2987 | 300.8703 | 162.3132 | 231.7404 | 71.4172 | 446.5333 | 3.32% |
| 2025-02-01 00:00:00 | -37.0958 | 285.8165 | 178.0392 | 249.862 | 91.2627 | 482.5468 | 2.88% |
| 2025-03-01 00:00:00 | -58.5993 | 399.3709 | 184.1856 | 302.8057 | 107.7079 | 555.8292 | 3.78% |
| 2025-04-01 00:00:00 | -47.5467 | 351.8849 | 181.8974 | 274.8211 | 96.4693 | 522.0821 | 3.33% |
| 2025-05-01 00:00:00 | -52.8924 | 356.6507 | 184.3501 | 273.6907 | 93.7178 | 525.8591 | 3.69% |
| 2025-06-01 00:00:00 | -57.7917 | 463.5547 | 184.5194 | 274.531 | 120.7548 | 558.2046 | 3.61% |
| 2025-07-01 00:00:00 |  |  |  |  |  |  | 3.54% |
| 2025-08-01 00:00:00 |  |  |  |  |  |  | 3.61% |
| 2025-09-01 00:00:00 |  |  |  |  |  |  | 3.59% |

Here, `2025-July is average of June, April, May`. Similarly, `2025-Aug is average of calculated July and June, May`.
Now, we can use these future contribution percentages to get forecast of Cons. 
Lets say, Forecast of Divisions looks like this:

| date | ELDS | ELIP | ELSB | ELSE | ELSP | Cons (EL) % 2506 |
| --- | --- | --- | --- | --- | --- | --- |
| 2025-07-01 00:00:00 | 380.6186 | 180.1262 | 277.3691 | 89.0982 | 540.2799 | 3.54% |
| 2025-08-01 00:00:00 | 259.4408 | 164.9896 | 254.5826 | 69.0512 | 402.8261 | 3.61% |
| 2025-09-01 00:00:00 | 350.6483 | 187.8459 | 314.6575 | 106.0538 | 487.9186 | 3.59% |

Cons (EL) for future will be calculated by: `-(ELDS + ELIP + ELSE + ELSP + ELSB) * (Cons (EL) % 2506)`
And Forecast for BA, will be calculated by: `ELDS + ELIP + ELSE + ELSP + ELSB + Cons (EL)`

| date | ELDS | ELIP | ELSB | ELSE | ELSP | Cons (EL) % 2506 | Cons (EL) | EL |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2025-07-01 00:00:00 | 380.6186 | 180.1262 | 277.3691 | 89.0982 | 540.2799 | 3.54% | -51.98730912 | 1415.504691 |
| 2025-08-01 00:00:00 | 259.4408 | 164.9896 | 254.5826 | 69.0512 | 402.8261 | 3.61% | -41.58093861 | 1109.309361 |
| 2025-09-01 00:00:00 | 350.6483 | 187.8459 | 314.6575 | 106.0538 | 487.9186 | 3.59% | -51.92274206 | 1395.201358 |

Refer to this sheet, for live example of how this whole calculation is being done for EL : [el_cons_forecast.xlsx](https://abb.sharepoint.com/:x:/r/teams/AAAITeam/_layouts/15/Doc.aspx?sourcedoc=%7BF2ABE78C-C666-471E-AF29-0E00F46E6BF2%7D&file=el_cons_forecast.xlsx&action=default&mobileredirect=true)