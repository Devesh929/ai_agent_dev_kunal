import pandas as pd
import numpy as np

def run_new_angles_miner():
    print("Loading data for New Angles Miner...")
    try:
        players = pd.read_csv('data/nba_player_logs_2012_2026.csv', usecols=['GAME_DATE', 'PLAYER_NAME', 'PLUS_MINUS', 'OREB'])
        teams = pd.read_csv('data/nba_team_logs_2012_2026.csv', usecols=['GAME_DATE', 'TEAM_NAME', 'PTS', 'GAME_ID'])
        stocks = pd.read_csv('data/sp500_stock_data_2012_2026.csv', usecols=['Date', 'Ticker', 'Close'])
    except Exception as e:
        print(f"Error loading data: {e}")
        return

    players['GAME_DATE'] = pd.to_datetime(players['GAME_DATE']).dt.tz_localize(None)
    teams['GAME_DATE'] = pd.to_datetime(teams['GAME_DATE']).dt.tz_localize(None)
    stocks['Date'] = pd.to_datetime(stocks['Date']).dt.tz_localize(None)
    stocks.sort_values(by=['Ticker', 'Date'], inplace=True)
    
    stocks['Pct_Change'] = stocks.groupby('Ticker')['Close'].pct_change() * 100
    stocks['Went_Up'] = stocks['Pct_Change'] > 0
    stocks['Went_Down'] = stocks['Pct_Change'] < 0

    famous_tickers = {
        'TSLA': 'Tesla', 'AAPL': 'Apple', 'MSFT': 'Microsoft', 'AMZN': 'Amazon',
        'NFLX': 'Netflix', 'META': 'Meta (Facebook)', 'KO': 'Coca-Cola', 'MCD': 'McDonalds',
        'SBUX': 'Starbucks', 'NKE': 'Nike', 'DIS': 'Disney', 'UBER': 'Uber'
    }
    stocks = stocks[stocks['Ticker'].isin(famous_tickers.keys())]

    # Map Next Trading Day
    stock_dates = sorted(stocks['Date'].unique())
    stock_date_df = pd.DataFrame({'Stock_Date': stock_dates})
    
    def get_next_trading_day(game_date):
        future = stock_date_df[stock_date_df['Stock_Date'] > game_date]
        if not future.empty:
            return future.iloc[0]['Stock_Date']
        return pd.NaT

    unique_game_dates = pd.DataFrame({'GAME_DATE': players['GAME_DATE'].unique()})
    unique_game_dates['Next_Trading_Date'] = unique_game_dates['GAME_DATE'].apply(get_next_trading_day)
    players = pd.merge(players, unique_game_dates, on='GAME_DATE', how='left')

    events = []
    print("Mining Player Angles (Plus/Minus, OREB)...")
    
    # Famous players for focus
    famous_players = [
        "LeBron James", "Stephen Curry", "Kevin Durant", "Giannis Antetokounmpo", 
        "James Harden", "Russell Westbrook", "Luka Doncic", "Nikola Jokic", 
        "Kawhi Leonard", "Anthony Davis", "Damian Lillard", "Kyrie Irving", 
        "Jimmy Butler", "Jayson Tatum", "Devin Booker", "Joel Embiid"
    ]
    
    for _, row in players.iterrows():
        p_name = row['PLAYER_NAME']
        date = row['Next_Trading_Date']
        if pd.isna(date) or p_name not in famous_players: continue
            
        pm = row['PLUS_MINUS']
        oreb = row['OREB']
        
        # Angle 1: Absolute Domination
        if pd.notna(pm) and pm >= 25:
            events.append({'Date': date, 'Event': f"{p_name} dominates with a +25 Plus/Minus"})
            
        # Angle 2: Total Liability
        if pd.notna(pm) and pm <= -25:
            events.append({'Date': date, 'Event': f"{p_name} is a total liability with a -25 Plus/Minus"})
            
        # Angle 3: Offensive Hustle
        if pd.notna(oreb) and oreb >= 7:
            events.append({'Date': date, 'Event': f"{p_name} hustles for 7+ Offensive Rebounds"})

    print("Mining Team Angles (Clutch Games)...")
    game_matchups = pd.merge(teams, teams, on='GAME_ID', suffixes=('', '_OPP'))
    game_matchups = game_matchups[game_matchups['TEAM_NAME'] != game_matchups['TEAM_NAME_OPP']]
    game_matchups['Margin'] = game_matchups['PTS'] - game_matchups['PTS_OPP']
    
    game_matchups['Next_Trading_Date'] = game_matchups['GAME_DATE'].apply(get_next_trading_day)
    
    for _, row in game_matchups.iterrows():
        t_name = row['TEAM_NAME']
        date = row['Next_Trading_Date']
        margin = row['Margin']
        if pd.isna(date): continue
            
        # Clutch Game (Won by exactly 1, 2, or 3 points)
        if margin in [1, 2, 3]:
            events.append({'Date': date, 'Event': f"The {t_name} win a nail-biter clutch game (by 1-3 pts)"})
            
    events_df = pd.DataFrame(events).drop_duplicates()
    
    results = []
    for event_name in events_df['Event'].unique():
        event_dates = events_df[events_df['Event'] == event_name]['Date']
        num_occurrences = len(event_dates)
        
        if num_occurrences < 15: # Threshold
            continue
            
        for ticker, company_name in famous_tickers.items():
            stock_slice = stocks[(stocks['Ticker'] == ticker) & (stocks['Date'].isin(event_dates))]
            
            if len(stock_slice) == 0: continue
            
            up_days = stock_slice['Went_Up'].sum()
            down_days = stock_slice['Went_Down'].sum()
            
            up_pct = (up_days / len(stock_slice)) * 100
            down_pct = (down_days / len(stock_slice)) * 100
            
            if up_pct >= 65:
                results.append({
                    'Pattern': f"Whenever {event_name}, {company_name} stock GOES UP!",
                    'Accuracy': up_pct,
                    'Occurrences': len(stock_slice),
                    'Type': 'UP'
                })
            elif down_pct >= 65:
                results.append({
                    'Pattern': f"Whenever {event_name}, {company_name} stock CRASHES!",
                    'Accuracy': down_pct,
                    'Occurrences': len(stock_slice),
                    'Type': 'DOWN'
                })

    res_df = pd.DataFrame(results)
    if not res_df.empty:
        res_df.sort_values(by=['Accuracy', 'Occurrences'], ascending=[False, False], inplace=True)
        res_df.to_csv('data/new_angles_patterns.csv', index=False)
        print("\n=== TOP NEW ANGLES PATTERNS SAVED TO CSV ===\n")
        for _, row in res_df.head(15).iterrows():
            print(f"{row['Pattern']} ({int(row['Accuracy'])}% of the time, N={row['Occurrences']})")
    else:
        print("No patterns met the threshold.")

if __name__ == "__main__":
    run_new_angles_miner()
