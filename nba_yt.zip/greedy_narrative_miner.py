import pandas as pd
import numpy as np

def run_greedy_miner():
    print("Loading data for Greedy Miner...")
    try:
        players = pd.read_csv('data/nba_player_logs_2012_2026.csv', usecols=['GAME_DATE', 'PLAYER_NAME', 'PTS', 'REB', 'AST', 'FG3M'])
        teams = pd.read_csv('data/nba_team_logs_2012_2026.csv', usecols=['GAME_DATE', 'TEAM_NAME', 'WL', 'PTS', 'GAME_ID'])
        stocks = pd.read_csv('data/sp500_stock_data_2012_2026.csv', usecols=['Date', 'Ticker', 'Close'])
    except Exception as e:
        print(f"Error loading data: {e}")
        return

    # Prepare Dates
    players['GAME_DATE'] = pd.to_datetime(players['GAME_DATE']).dt.tz_localize(None)
    teams['GAME_DATE'] = pd.to_datetime(teams['GAME_DATE']).dt.tz_localize(None)
    stocks['Date'] = pd.to_datetime(stocks['Date']).dt.tz_localize(None)
    stocks.sort_values(by=['Ticker', 'Date'], inplace=True)
    
    # Calculate simple up/down for stocks
    stocks['Pct_Change'] = stocks.groupby('Ticker')['Close'].pct_change() * 100
    stocks['Went_Up'] = stocks['Pct_Change'] > 0
    stocks['Went_Down'] = stocks['Pct_Change'] < 0

    # Expand the target list to include airlines, banks, etc.
    target_tickers = {
        'TSLA': 'Tesla', 'AAPL': 'Apple', 'MSFT': 'Microsoft', 'AMZN': 'Amazon',
        'NFLX': 'Netflix', 'META': 'Meta', 'KO': 'Coca-Cola', 'MCD': 'McDonalds',
        'SBUX': 'Starbucks', 'NKE': 'Nike', 'DIS': 'Disney', 'UBER': 'Uber',
        'UAL': 'United Airlines', 'DAL': 'Delta Airlines', 'JPM': 'JPMorgan Chase',
        'BAC': 'Bank of America', 'WMT': 'Walmart', 'TGT': 'Target'
    }
    stocks = stocks[stocks['Ticker'].isin(target_tickers.keys())]

    # Map Next Trading Day
    stock_dates = sorted(stocks['Date'].unique())
    stock_date_df = pd.DataFrame({'Stock_Date': stock_dates})
    
    def get_next_trading_day(game_date):
        future = stock_date_df[stock_date_df['Stock_Date'] > game_date]
        if not future.empty:
            return future.iloc[0]['Stock_Date']
        return pd.NaT

    # --- 1. BUILD TEAM EVENTS ---
    print("Building Team Events...")
    # Self join on GAME_ID to get opponent's score for margin
    game_matchups = pd.merge(teams, teams, on='GAME_ID', suffixes=('', '_OPP'))
    game_matchups = game_matchups[game_matchups['TEAM_NAME'] != game_matchups['TEAM_NAME_OPP']]
    game_matchups['Margin'] = game_matchups['PTS'] - game_matchups['PTS_OPP']
    
    game_matchups['Next_Trading_Date'] = game_matchups['GAME_DATE'].apply(get_next_trading_day)
    
    team_events = []
    for _, row in game_matchups.iterrows():
        t_name = row['TEAM_NAME']
        date = row['Next_Trading_Date']
        margin = row['Margin']
        if pd.isna(date): continue
            
        if margin >= 10: team_events.append({'Date': date, 'Event': f"The {t_name} win by 10+"})
        if margin >= 20: team_events.append({'Date': date, 'Event': f"The {t_name} blow out an opponent by 20+"})
        if margin >= 30: team_events.append({'Date': date, 'Event': f"The {t_name} completely destroy an opponent by 30+"})
        
        if margin <= -10: team_events.append({'Date': date, 'Event': f"The {t_name} lose by 10+"})
        if margin <= -20: team_events.append({'Date': date, 'Event': f"The {t_name} get blown out by 20+"})
        
    team_events_df = pd.DataFrame(team_events).drop_duplicates()

    # --- 2. BUILD PLAYER EVENTS (ALL PLAYERS) ---
    print("Building Player Events...")
    unique_game_dates = pd.DataFrame({'GAME_DATE': players['GAME_DATE'].unique()})
    unique_game_dates['Next_Trading_Date'] = unique_game_dates['GAME_DATE'].apply(get_next_trading_day)
    players = pd.merge(players, unique_game_dates, on='GAME_DATE', how='left')
    
    player_events = []
    
    # Vectorized approach for speed
    def extract_events(df, col, threshold, suffix):
        mask = df[col] >= threshold
        events = df[mask][['Next_Trading_Date', 'PLAYER_NAME']].copy()
        events['Event'] = events['PLAYER_NAME'] + f" {suffix}"
        events.rename(columns={'Next_Trading_Date': 'Date'}, inplace=True)
        return events[['Date', 'Event']]

    pts20 = extract_events(players, 'PTS', 20, "scores 20+ points")
    pts30 = extract_events(players, 'PTS', 30, "scores 30+ points")
    pts40 = extract_events(players, 'PTS', 40, "scores 40+ points")
    reb10 = extract_events(players, 'REB', 10, "grabs 10+ rebounds")
    reb15 = extract_events(players, 'REB', 15, "grabs 15+ rebounds")
    ast8 = extract_events(players, 'AST', 8, "dashes out 8+ assists")
    ast12 = extract_events(players, 'AST', 12, "dashes out 12+ assists")
    fg3m5 = extract_events(players, 'FG3M', 5, "hits 5+ three-pointers")

    all_player_events_df = pd.concat([pts20, pts30, pts40, reb10, reb15, ast8, ast12, fg3m5]).dropna()
    all_player_events_df.drop_duplicates(inplace=True)
    
    # Combine all events
    all_events_df = pd.concat([team_events_df, all_player_events_df])
    
    # --- 3. FILTER BY SAMPLE SIZE (N >= 50) ---
    print("Filtering for high sample size events (N >= 50)...")
    event_counts = all_events_df['Event'].value_counts()
    valid_events = event_counts[event_counts >= 50].index.tolist()
    
    print(f"Total valid events generated: {len(valid_events)}")
    
    events_df_filtered = all_events_df[all_events_df['Event'].isin(valid_events)]

    # --- 4. GREEDY SCAN ---
    print("Running greedy scan across target stocks...")
    results = []
    
    # Pre-aggregate stock data by date for faster lookup
    stock_up_dict = {ticker: set(stocks[(stocks['Ticker'] == ticker) & (stocks['Went_Up'] == True)]['Date']) for ticker in target_tickers.keys()}
    stock_down_dict = {ticker: set(stocks[(stocks['Ticker'] == ticker) & (stocks['Went_Down'] == True)]['Date']) for ticker in target_tickers.keys()}
    stock_all_dates_dict = {ticker: set(stocks[stocks['Ticker'] == ticker]['Date']) for ticker in target_tickers.keys()}
    
    # Group events by dates to speed up the loop
    event_to_dates = events_df_filtered.groupby('Event')['Date'].apply(set).to_dict()
    
    for event_name, dates_set in event_to_dates.items():
        for ticker, company_name in target_tickers.items():
            valid_market_dates = dates_set.intersection(stock_all_dates_dict[ticker])
            n_occurrences = len(valid_market_dates)
            
            if n_occurrences < 50:
                continue
                
            up_days = len(valid_market_dates.intersection(stock_up_dict[ticker]))
            down_days = len(valid_market_dates.intersection(stock_down_dict[ticker]))
            
            up_pct = (up_days / n_occurrences) * 100
            down_pct = (down_days / n_occurrences) * 100
            
            # Greedy criteria: Accuracy > 60% with N >= 50
            if up_pct >= 60.0:
                results.append({
                    'Pattern': f"Whenever {event_name}, {company_name} stock GOES UP the next day!",
                    'Accuracy': up_pct,
                    'Occurrences': n_occurrences,
                    'Type': 'UP',
                    'Score': n_occurrences * (up_pct - 50) # Greedy Score prioritizing both
                })
            elif down_pct >= 60.0:
                results.append({
                    'Pattern': f"Whenever {event_name}, {company_name} stock CRASHES the next day!",
                    'Accuracy': down_pct,
                    'Occurrences': n_occurrences,
                    'Type': 'DOWN',
                    'Score': n_occurrences * (down_pct - 50)
                })

    res_df = pd.DataFrame(results)
    if not res_df.empty:
        res_df.sort_values(by=['Score', 'Accuracy'], ascending=[False, False], inplace=True)
        res_df.to_csv('data/greedy_patterns.csv', index=False)
        print("\n=== TOP GREEDY YOUTUBE PATTERNS SAVED TO CSV ===\n")
        # Print top 15 by greedy score
        for i, row in res_df.head(15).iterrows():
            print(f"{row['Pattern']} | {row['Accuracy']:.1f}% | N={row['Occurrences']}")
    else:
        print("No patterns met the criteria.")

if __name__ == "__main__":
    run_greedy_miner()
