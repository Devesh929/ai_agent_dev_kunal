## Pyspark Parallelization on Azure Kubernetes Services

  

This SOP outlines how to deploy and manage PySpark jobs on Azure Kubernetes Service (AKS), including key setup commands and access control.

  

---

  

## Common Commands

  

### Update Spark Code Docker Image on ACR

  

```bash

az acr build --registry 8283119aa243405ab715c905b161b9cd --image spark-el-forecasting-training:0.14 .

```

  

### Get All Running Pods on the Cluster

  

```bash

kubectl get pods -A -o custom-columns='NAMESPACE:.metadata.namespace,NAME:.metadata.name,SA:.spec.serviceAccountName'

```

  

### Delete a Running Application or Pod

  

```bash

kubectl delete sparkapplication spark-el-forecasting-training -n default

```

  

### Submit a Spark Manifest YAML

  

```bash

kubectl apply -f spark_submit_training.yaml

```

  

### Explore Logs from the Driver Instance

  

```bash

kubectl logs -f spark-el-forecasting-training-driver

```

  

---

  

## ☁️ Create AKS Cluster

  

```bash

az aks create \

  --resource-group "rg-dev-aaai-mlops" \

  --name "aks-dev-aaai-mlops" \

  --node-vm-size Standard_E8s_v3 \

  --node-count 3 \

  --enable-oidc-issuer \

  --enable-workload-identity \

  --generate-ssh-keys

```

  

---

  

## AKS Context Setup

  

### Get AKS Credentials

  

```bash

az aks get-credentials -g rg-dev-aaai-mlops -n aks-dev-aaai-mlops

```

  

### Check Current Context

  

```bash

kubectl config current-context

```

  

---

  

## Access Identity and Connection

  

### Export Required Variables

  

```bash

export SUBSCRIPTION="$(az account show --query id --output tsv)"

export USER_ASSIGNED_IDENTITY_NAME="mi-dev-aaai-mlops"

export RESOURCE_GROUP="rg-dev-aaai-mlops"

export LOCATION="eastus"

```

  

---

  

## Attach ACR to AKS

  

```bash

az aks update -n aks-dev-aaai-mlops -g rg-dev-aaai-mlops --attach-acr 8283119aa243405ab715c905b161b9cd

```

  

---

  

## Create User-Managed Identity

  

```bash

az identity create \

  --name "${USER_ASSIGNED_IDENTITY_NAME}" \

  --resource-group "${RESOURCE_GROUP}" \

  --location "${LOCATION}" \

  --subscription "${SUBSCRIPTION}"

```

  

---

  

## Assign Roles to Managed Identity

  

Assign the following roles to the identity:

- `Storage Blob Data Contributor`

- `AzureML Data Scientist`

  

---

  

## Workload Identity Setup

  

### Export Federated Identity Variables

  

```bash

export AKS_OIDC_ISSUER=$(az aks show --name aks-dev-aaai-mlops --resource-group rg-dev-aaai-mlops --query "oidcIssuerProfile.issuerUrl" -o tsv)

export AZURE_CLIENT_ID=$(az identity show --name mi-dev-aaai-mlops --resource-group rg-dev-aaai-mlops --query "clientId" -o tsv)

export SERVICE_ACCOUNT_NAMESPACE="default"

export SERVICE_ACCOUNT_NAME="workload-identity-sa"

export FEDERATED_IDENTITY_CREDENTIAL_NAME="aksFedIdentity"

```

  

### Create Service Account

  

```bash

cat <<EOF | kubectl apply -f -

apiVersion: v1

kind: ServiceAccount

metadata:

  annotations:

    azure.workload.identity/client-id: "${USER_ASSIGNED_CLIENT_ID}"

  name: "${SERVICE_ACCOUNT_NAME}"

  namespace: "${SERVICE_ACCOUNT_NAMESPACE}"

EOF

```

  

### Create Federated Credential

  

```bash

az identity federated-credential create \

  --name ${FEDERATED_IDENTITY_CREDENTIAL_NAME} \

  --identity-name "${USER_ASSIGNED_IDENTITY_NAME}" \

  --resource-group "${RESOURCE_GROUP}" \

  --issuer "${AKS_OIDC_ISSUER}" \

  --subject system:serviceaccount:"${SERVICE_ACCOUNT_NAMESPACE}":"${SERVICE_ACCOUNT_NAME}" \

  --audience api://AzureADTokenExchange

```

  

### Role Binding of Service Account

  

```bash

cat <<EOF | kubectl apply -f -

apiVersion: rbac.authorization.k8s.io/v1

kind: ClusterRoleBinding

metadata:

  name: spark-role-binding

subjects:

- kind: ServiceAccount

  name: workload-identity-sa

  namespace: default

roleRef:

  kind: ClusterRole

  name: edit

  apiGroup: rbac.authorization.k8s.io

EOF

```


### Assign Spark Application Reader Role to Service Account

```    
cat <<EOF | kubectl apply -f -

apiVersion: rbac.authorization.k8s.io/v1

kind: ClusterRole

metadata:

  name: spark-app-reader

rules:

- apiGroups: ["sparkoperator.k8s.io"]

  resources: ["sparkapplications"]

  verbs: ["get", "list", "watch"]

EOF
```

### Role Binding of App Reader Role

```    
cat <<EOF | kubectl apply -f -

apiVersion: rbac.authorization.k8s.io/v1

kind: ClusterRoleBinding

metadata:

  name: spark-app-reader-binding

subjects:

- kind: ServiceAccount

  name: workload-identity-sa

  namespace: default

roleRef:

  kind: ClusterRole

  name: spark-app-reader

  apiGroup: rbac.authorization.k8s.io

EOF
```
  

---

  

## Installing Spark Operator on AKS

  

### Add Helm Repo

  

```bash

helm repo add --force-update spark-operator https://kubeflow.github.io/spark-operator

```

  

### Install Spark Operator

  

```bash

helm install spark-operator spark-operator/spark-operator \

  --namespace spark-operator \

  --create-namespace \

  --wait

```
---

## Access to Users on AKS

      
Azure Kubernetes Service Cluster User Role – RBAC

```   
cat <<EOF | kubectl apply -f -

apiVersion: rbac.authorization.k8s.io/v1

kind: RoleBinding

metadata:
  name: entra-group-can-edit

  namespace: default

roleRef:

  apiGroup: rbac.authorization.k8s.io

  kind: ClusterRole

  name: edit

subjects:

  - kind: Group

    name: 30cc6b55-9b12-427e-9932-42075d3165f9 #Entra ID Group Object ID

    apiGroup: rbac.authorization.k8s.io

EOF
```