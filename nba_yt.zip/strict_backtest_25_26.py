import pandas as pd

def run_strict_backtest():
    print("Loading data for STRICT 25-26 Backtest (Zero Leakage)...")
    try:
        players = pd.read_csv('data/nba_player_logs_2012_2026.csv')
        stocks = pd.read_csv('data/sp500_stock_data_2012_2026.csv')
    except Exception as e:
        print(f"Error loading data: {e}")
        return

    # 1. STRICT DATA ISOLATION (ZERO LEAKAGE)
    players['GAME_DATE'] = pd.to_datetime(players['GAME_DATE']).dt.tz_localize(None)
    stocks['Date'] = pd.to_datetime(stocks['Date']).dt.tz_localize(None)
    
    players = players[players['GAME_DATE'] >= '2025-10-01'].copy()
    stocks = stocks[stocks['Date'] >= '2025-10-01'].copy()
    
    stocks.sort_values(by=['Ticker', 'Date'], inplace=True)
    stocks['Pct_Change'] = stocks.groupby('Ticker')['Close'].pct_change() * 100
    stocks['Went_Up'] = stocks['Pct_Change'] > 0
    stocks['Went_Down'] = stocks['Pct_Change'] < 0

    stock_dates = sorted(stocks['Date'].unique())
    stock_date_df = pd.DataFrame({'Stock_Date': stock_dates})
    
    def get_next_trading_day(game_date):
        future = stock_date_df[stock_date_df['Stock_Date'] > game_date]
        if not future.empty:
            return future.iloc[0]['Stock_Date']
        return pd.NaT

    unique_game_dates = pd.DataFrame({'GAME_DATE': players['GAME_DATE'].unique()})
    unique_game_dates['Next_Trading_Date'] = unique_game_dates['GAME_DATE'].apply(get_next_trading_day)
    players = pd.merge(players, unique_game_dates, on='GAME_DATE', how='left')

    # Define the exact anomalies from our master list
    patterns = [
        {"name": "Devin Booker turns the ball over 7+ times", "player": "Devin Booker", "condition": lambda r: r['TOV'] >= 7, "ticker": "TSLA", "type": "UP"},
        {"name": "Kevin Durant shoots terribly (<35% on 18+ shots)", "player": "Kevin Durant", "condition": lambda r: r['FGA'] >= 18 and r['FG_PCT'] <= 0.35, "ticker": "META", "type": "DOWN"},
        {"name": "Kevin Durant shoots terribly (<35% on 18+ shots)", "player": "Kevin Durant", "condition": lambda r: r['FGA'] >= 18 and r['FG_PCT'] <= 0.35, "ticker": "NFLX", "type": "DOWN"},
        {"name": "Russell Westbrook liability (-25 +/-)", "player": "Russell Westbrook", "condition": lambda r: pd.notna(r['PLUS_MINUS']) and r['PLUS_MINUS'] <= -25, "ticker": "AMZN", "type": "DOWN"},
        {"name": "Stephen Curry hits 9+ Threes", "player": "Stephen Curry", "condition": lambda r: r['FG3M'] >= 9, "ticker": "TSLA", "type": "UP"},
        {"name": "Stephen Curry 7+ turnovers", "player": "Stephen Curry", "condition": lambda r: r['TOV'] >= 7, "ticker": "TSLA", "type": "UP"},
        {"name": "Damian Lillard hits 8+ Threes", "player": "Damian Lillard", "condition": lambda r: r['FG3M'] >= 8, "ticker": "NFLX", "type": "UP"},
        {"name": "Jayson Tatum takes 28+ shots", "player": "Jayson Tatum", "condition": lambda r: r['FGA'] >= 28, "ticker": "AMZN", "type": "DOWN"},
        {"name": "Ja Morant scores 30+", "player": "Ja Morant", "condition": lambda r: r['PTS'] >= 30, "ticker": "TGT", "type": "UP"},
        {"name": "CJ McCollum scores 30+", "player": "CJ McCollum", "condition": lambda r: r['PTS'] >= 30, "ticker": "AMZN", "type": "UP"},
        {"name": "Dillon Brooks scores 20+", "player": "Dillon Brooks", "condition": lambda r: r['PTS'] >= 20, "ticker": "NKE", "type": "DOWN"},
        {"name": "SGA 100% on 12+ FT", "player": "Shai Gilgeous-Alexander", "condition": lambda r: r['FTA'] >= 12 and r['FT_PCT'] == 1.0, "ticker": "TSLA", "type": "DOWN"},
        {"name": "LeBron James scores 40+", "player": "LeBron James", "condition": lambda r: r['PTS'] >= 40, "ticker": "NKE", "type": "DOWN"},
        # Emerging Stars
        {"name": "Victor Wembanyama 6+ turnovers", "player": "Victor Wembanyama", "condition": lambda r: r['TOV'] >= 6, "ticker": "AAPL", "type": "DOWN"},
        {"name": "Victor Wembanyama 6+ turnovers", "player": "Victor Wembanyama", "condition": lambda r: r['TOV'] >= 6, "ticker": "MSFT", "type": "DOWN"},
        {"name": "Scottie Barnes 4+ blocks", "player": "Scottie Barnes", "condition": lambda r: r['BLK'] >= 4, "ticker": "DIS", "type": "DOWN"},
        {"name": "Scottie Barnes 4+ blocks", "player": "Scottie Barnes", "condition": lambda r: r['BLK'] >= 4, "ticker": "SBUX", "type": "DOWN"},
        {"name": "Alperen Sengun 10+ assists", "player": "Alperen Sengun", "condition": lambda r: r['AST'] >= 10, "ticker": "MCD", "type": "DOWN"},
        {"name": "Paolo Banchero dominates (+20 +/-)", "player": "Paolo Banchero", "condition": lambda r: pd.notna(r['PLUS_MINUS']) and r['PLUS_MINUS'] >= 20, "ticker": "AMZN", "type": "UP"},
        {"name": "Paolo Banchero dominates (+20 +/-)", "player": "Paolo Banchero", "condition": lambda r: pd.notna(r['PLUS_MINUS']) and r['PLUS_MINUS'] >= 20, "ticker": "META", "type": "UP"},
        {"name": "Tyrese Maxey 4+ steals", "player": "Tyrese Maxey", "condition": lambda r: r['STL'] >= 4, "ticker": "UBER", "type": "UP"}
    ]

    results = []
    
    for p in patterns:
        player_df = players[players['PLAYER_NAME'] == p['player']]
        event_dates = []
        for _, row in player_df.iterrows():
            if p['condition'](row):
                if pd.notna(row['Next_Trading_Date']):
                    event_dates.append(row['Next_Trading_Date'])
        
        if not event_dates: 
            results.append({'Pattern': p['name'], 'Ticker': p['ticker'], 'Accuracy': 'N/A', 'Occurrences': 0, 'Target': p['type']})
            continue

        stock_df = stocks[stocks['Ticker'] == p['ticker']].copy()
        event_stock_df = stock_df[stock_df['Date'].isin(event_dates)]
        
        n_occurrences = len(event_stock_df)
        if n_occurrences == 0:
            results.append({'Pattern': p['name'], 'Ticker': p['ticker'], 'Accuracy': 'N/A', 'Occurrences': 0, 'Target': p['type']})
            continue
            
        if p['type'] == 'UP':
            accuracy = (event_stock_df['Went_Up'].sum() / n_occurrences) * 100
        else:
            accuracy = (event_stock_df['Went_Down'].sum() / n_occurrences) * 100

        results.append({'Pattern': p['name'], 'Ticker': p['ticker'], 'Accuracy': accuracy, 'Occurrences': n_occurrences, 'Target': p['type']})

    res_df = pd.DataFrame(results)
    print("\n=== STRICT BLIND TEST: 2025-2026 SEASON RESULTS ===\n")
    for _, row in res_df.iterrows():
        if row['Occurrences'] == 0:
            print(f"DID NOT HAPPEN: {row['Pattern']} ({row['Ticker']}) -> 0 occurrences this season.")
        else:
            acc = row['Accuracy']
            if acc >= 70:
                print(f"[SURVIVED] {row['Pattern']} -> {row['Ticker']} {row['Target']} ({acc:.1f}% accuracy, N={row['Occurrences']})")
            elif acc >= 50:
                print(f"[WEAKENED] {row['Pattern']} -> {row['Ticker']} {row['Target']} ({acc:.1f}% accuracy, N={row['Occurrences']})")
            else:
                print(f"[FAILED] {row['Pattern']} -> {row['Ticker']} {row['Target']} ({acc:.1f}% accuracy, N={row['Occurrences']})")
                
    res_df.to_csv('data/strict_backtest_25_26_results.csv', index=False)

if __name__ == "__main__":
    run_strict_backtest()
