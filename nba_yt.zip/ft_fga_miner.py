import pandas as pd
import numpy as np

def run_fga_ft_miner():
    print("Loading data for Ball Hog and Free Throw Analysis...")
    try:
        players = pd.read_csv('data/nba_player_logs_2012_2026.csv', usecols=['GAME_DATE', 'PLAYER_NAME', 'FGA', 'FTM', 'FTA', 'FT_PCT'])
        stocks = pd.read_csv('data/sp500_stock_data_2012_2026.csv', usecols=['Date', 'Ticker', 'Close'])
    except Exception as e:
        print(f"Error loading data: {e}")
        return

    players['GAME_DATE'] = pd.to_datetime(players['GAME_DATE']).dt.tz_localize(None)
    stocks['Date'] = pd.to_datetime(stocks['Date']).dt.tz_localize(None)
    stocks.sort_values(by=['Ticker', 'Date'], inplace=True)
    
    stocks['Pct_Change'] = stocks.groupby('Ticker')['Close'].pct_change() * 100
    stocks['Went_Up'] = stocks['Pct_Change'] > 0
    stocks['Went_Down'] = stocks['Pct_Change'] < 0

    famous_tickers = {
        'TSLA': 'Tesla', 'AAPL': 'Apple', 'MSFT': 'Microsoft', 'AMZN': 'Amazon',
        'NFLX': 'Netflix', 'META': 'Meta (Facebook)', 'KO': 'Coca-Cola', 'MCD': 'McDonalds',
        'SBUX': 'Starbucks', 'NKE': 'Nike', 'DIS': 'Disney'
    }
    stocks = stocks[stocks['Ticker'].isin(famous_tickers.keys())]

    # Map Next Trading Day
    stock_dates = sorted(stocks['Date'].unique())
    stock_date_df = pd.DataFrame({'Stock_Date': stock_dates})
    
    def get_next_trading_day(game_date):
        future = stock_date_df[stock_date_df['Stock_Date'] > game_date]
        if not future.empty:
            return future.iloc[0]['Stock_Date']
        return pd.NaT

    unique_game_dates = pd.DataFrame({'GAME_DATE': players['GAME_DATE'].unique()})
    unique_game_dates['Next_Trading_Date'] = unique_game_dates['GAME_DATE'].apply(get_next_trading_day)
    players = pd.merge(players, unique_game_dates, on='GAME_DATE', how='left')

    events = []
    print("Mining FGA and Free Throw events...")
    
    for _, row in players.iterrows():
        p_name = row['PLAYER_NAME']
        date = row['Next_Trading_Date']
        if pd.isna(date): continue
            
        fga = row['FGA']
        ftm = row['FTM']
        fta = row['FTA']
        ft_pct = row['FT_PCT']
        
        # Angle 1: Ball Hogs (Taking 30+ shots)
        if fga >= 28:
            events.append({'Date': date, 'Event': f"{p_name} is a ball hog (takes 28+ shots)"})
            
        # Angle 2: Foul Baiting / Free Throw Merchants
        if fta >= 18:
            events.append({'Date': date, 'Event': f"{p_name} shoots 18+ free throws"})
            
        # Angle 3: Hack-a-Shaq (Terrible free throw shooting on high volume)
        if fta >= 10 and ft_pct <= 0.4:
            events.append({'Date': date, 'Event': f"{p_name} shoots terribly from the free throw line (<40% on 10+ FTA)"})
            
        # Angle 4: Perfect Free Throw Shooting
        if fta >= 12 and ft_pct == 1.0:
            events.append({'Date': date, 'Event': f"{p_name} shoots a perfect 100% on 12+ free throws"})

    events_df = pd.DataFrame(events).drop_duplicates()
    
    results = []
    for event_name in events_df['Event'].unique():
        event_dates = events_df[events_df['Event'] == event_name]['Date']
        num_occurrences = len(event_dates)
        
        if num_occurrences < 15: # Threshold for sample size
            continue
            
        for ticker, company_name in famous_tickers.items():
            stock_slice = stocks[(stocks['Ticker'] == ticker) & (stocks['Date'].isin(event_dates))]
            
            if len(stock_slice) == 0: continue
            
            up_days = stock_slice['Went_Up'].sum()
            down_days = stock_slice['Went_Down'].sum()
            
            up_pct = (up_days / len(stock_slice)) * 100
            down_pct = (down_days / len(stock_slice)) * 100
            
            if up_pct >= 65:
                results.append({
                    'Pattern': f"Whenever {event_name}, {company_name} stock GOES UP!",
                    'Accuracy': up_pct,
                    'Occurrences': len(stock_slice),
                    'Type': 'UP'
                })
            elif down_pct >= 65:
                results.append({
                    'Pattern': f"Whenever {event_name}, {company_name} stock CRASHES!",
                    'Accuracy': down_pct,
                    'Occurrences': len(stock_slice),
                    'Type': 'DOWN'
                })

    res_df = pd.DataFrame(results)
    if not res_df.empty:
        res_df.sort_values(by=['Accuracy', 'Occurrences'], ascending=[False, False], inplace=True)
        res_df.to_csv('data/ft_fga_patterns.csv', index=False)
        print("\n=== TOP FGA / FREE THROW YOUTUBE PATTERNS SAVED TO CSV ===\n")
        for _, row in res_df.head(15).iterrows():
            print(f"{row['Pattern']} ({int(row['Accuracy'])}% of the time, N={row['Occurrences']})")
            
        # Append to Excel
        try:
            from openpyxl import load_workbook
            excel_path = 'Final_NBA_Stock_Patterns.xlsx'
            with pd.ExcelWriter(excel_path, engine='openpyxl', mode='a', if_sheet_exists='replace') as writer:
                res_df.to_excel(writer, sheet_name='Ball_Hogs_and_Free_Throws', index=False)
            print("Successfully appended to Final_NBA_Stock_Patterns.xlsx!")
        except Exception as e:
            print(f"Could not append to Excel: {e}")
    else:
        print("No patterns met the threshold.")

if __name__ == "__main__":
    run_fga_ft_miner()
