import pandas as pd
import glob
import os

def collate_patterns():
    files = glob.glob('data/*patterns.csv')
    all_patterns = pd.DataFrame()
    
    for f in files:
        if '25_26' in f: continue # skip backtest for this historical aggregate
        try:
            df = pd.read_csv(f)
            df['Source'] = os.path.basename(f)
            all_patterns = pd.concat([all_patterns, df], ignore_index=True)
        except Exception as e:
            pass

    # Filter for high frequency/high accuracy
    if not all_patterns.empty:
        # We want things that have decent N (e.g., >= 25) and high accuracy (>= 70%)
        # Or massive N (e.g. >= 50) and good accuracy (>= 65%)
        mask = ((all_patterns['Occurrences'] >= 25) & (all_patterns['Accuracy'] >= 70)) | \
               ((all_patterns['Occurrences'] >= 50) & (all_patterns['Accuracy'] >= 65))
        
        filtered = all_patterns[mask].copy()
        
        # Sort by accuracy and occurrences
        filtered.sort_values(by=['Accuracy', 'Occurrences'], ascending=[False, False], inplace=True)
        
        # Drop duplicates based on the pattern string
        filtered.drop_duplicates(subset=['Pattern'], inplace=True)
        
        filtered.to_csv('data/all_collated_high_patterns.csv', index=False)
        print(f"Saved {len(filtered)} high-value patterns to data/all_collated_high_patterns.csv")
    else:
        print("No pattern files found.")

if __name__ == '__main__':
    collate_patterns()
