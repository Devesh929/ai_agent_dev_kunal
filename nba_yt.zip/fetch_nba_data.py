import time
import pandas as pd
from nba_api.stats.endpoints import leaguegamelog, playergamelogs
from nba_api.stats.library.parameters import SeasonAll
import os
import tqdm
import ssl_patch

ssl_patch.apply_patch()

def fetch_nba_data():
    seasons = [
        '2012-13', '2013-14', '2014-15', '2015-16', 
        '2016-17', '2017-18', '2018-19', '2019-20', 
        '2020-21', '2021-22', '2022-23', '2023-24', 
        '2024-25', '2025-26'
    ]
    
    os.makedirs('data', exist_ok=True)
    
    team_logs_list = []
    player_logs_list = []
    
    print("Fetching NBA Data...")
    for season in tqdm.tqdm(seasons):
        try:
            # Fetch team game logs
            team_log = leaguegamelog.LeagueGameLog(season=season, season_type_all_star='Regular Season').get_data_frames()[0]
            team_logs_list.append(team_log)
            time.sleep(1) # Be nice to the API
            
            # Fetch player game logs
            # playergamelogs returns stats for all players in a given season
            player_log = playergamelogs.PlayerGameLogs(season_nullable=season, season_type_nullable='Regular Season').get_data_frames()[0]
            player_logs_list.append(player_log)
            time.sleep(1) # Be nice to the API
            
        except Exception as e:
            print(f"Error fetching data for season {season}: {e}")
            
    if team_logs_list:
        all_team_logs = pd.concat(team_logs_list, ignore_index=True)
        all_team_logs.to_csv('data/nba_team_logs_2012_2026.csv', index=False)
        print(f"Saved team logs: {len(all_team_logs)} rows.")
        
    if player_logs_list:
        all_player_logs = pd.concat(player_logs_list, ignore_index=True)
        all_player_logs.to_csv('data/nba_player_logs_2012_2026.csv', index=False)
        print(f"Saved player logs: {len(all_player_logs)} rows.")

if __name__ == "__main__":
    fetch_nba_data()
