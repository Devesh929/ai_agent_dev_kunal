#Main Script Execution Flow (`if __name__ == "__main__":`)


This section explains the top-level execution flow of the forecasting and analysis pipeline, as defined within the `if __name__ == "__main__":` block of the main script. This block ensures that the code inside it only runs when the script is executed directly (not when imported as a module).

### Purpose

The main script orchestrates the entire post-modelling analysis workflow. It performs the following key functions:
*   Loads configuration parameters.
    
*   Reads various data outputs from the modelling phase.
    
*   Initializes and configures logging.
    
*   Instantiates and calls methods from specialized analysis and visualization classes (e.g., `ResidualAnalyzer`, `LevelChecker`, `ShapExplainerVisualizer`).
    
*   Generates plots and performs statistical analyses.
    
*   Saves the results of these analyses into structured Excel files.
    

### Execution Flow

The script follows a sequential flow, performing setup, data processing, analysis, visualization, and result saving.
1.  **Configuration Loading**:
    *   The script first defines the `config_file_path` (e.g., "config.json").
        
    *   It attempts to load the configuration parameters from this JSON file using `CommonFunctions.load_config()`. This `config_data` dictionary drives the entire pipeline.
        
2.  **Data Reading**:
    *   An instance of `DataReading` is created, initialized with the loaded `config_data`.
        
    *   `data_reader.read_all_model_outputs()` is called to load all necessary DataFrames from the specified data asset paths and sheets (as defined in the configuration). These loaded DataFrames are stored in the `data_outputs` dictionary.
        
3.  **Logging Setup**:
    *   The `experiment_name` and `main_results_folder` are extracted from `config_data`.
        
    *   A dedicated log folder is created for the current experiment.
        
    *   A custom logger instance (`my_custom_logger_instance`) is initialized, and a logger object (`logger`) is obtained.
        
    *   `sys.stdout` is redirected to `IOLogger` to capture print statements in the log file.
        
    *   Informational messages about logging and application start are recorded.
        
4.  **Parameter Extraction**:
    *   Various parameters required by the analysis classes, such as `modelling_level_list`, `models`, `models_stl`, `data_asset_path`, `data_asset_label`, date ranges (`pred_start`, `pred_end`, `future_start`, `future_end`), thresholds (`growth_threshold_pct`, `decline_threshold_pct`), and `top_n_features`, are extracted from the `config_data` dictionary.
        
5.  **Data Assignment**:
    *   Specific DataFrames from the `data_outputs` dictionary are assigned to more descriptive variables for clarity and direct use by the analysis classes. This includes validation, test, future prediction data, full historical data, SHAP values, importance values, Prophet components, and more.
        
6.  **Analysis and Plotting Modules Execution**: The script then sequentially initializes and calls methods from various analysis and visualization classes:
    *   **Residual Analysis**:
        *   An `ResidualAnalyzer` instance is created.
            
        *   `analyze_residuals_for_all_models` and `analyze_residuals_single_test_for_all_models` are called to compute residuals for validation and test sets.
            
        *   `generate_all_plots` is called to create residual-related plots (histograms, ACF/PACF).
            
    *   **Actuals vs. Prediction Series Plotting**:
        *   A `Plotter` instance is created.
            
        *   `generate_plot` is called to visualize actuals against predictions.
            
    *   **Variance Analysis**:
        *   A `VarianceAnalyzer` instance is created.
            
        *   `variance_analysis` is called for both validation and test data to compute variance results.
            
    *   **Level Check Analysis (Mean and Variance Growth/Decline)**:
        *   A `LevelChecker` instance is created.
            
        *   `analyze_and_plot_level_check` is called to perform quarterly mean/variance analysis, calculate period-over-period changes, and generate related plots.
            
    *   **Prophet Trend and Seasonality Plots**:
        *   A `ProphetComponentsPlotter` instance is created.
            
        *   A `try-except` block checks if the necessary Prophet trend/seasonality DataFrames are empty. If not, `generate_prophet_component_plots` is called to create and display these plots.
            
    *   **STL Decomposition and Plots**:
        *   An `STLDecomposer` instance is created.
            
        *   `process_stl_decomposition` is called to perform STL decomposition on prediction data and combine the results.
            
        *   `generate_stl_component_plots` is called to create and display plots of the decomposed STL components.
            
    *   **SHAP and Importance Plots**:
        *   A `ShapExplainerVisualizer` instance is created.
            
        *   A `try-except` block checks if the necessary SHAP DataFrames are empty. If not, `process_shap_data` is called to generate global feature importance, summary, and waterfall plots.
            
    *   **Prophet Regressors and Components Plots**:
        *   Another `ProphetRegressorCoefficientsPlotter` instance is created (note: variable `plotter` is reused, but a new instance is created).
            
        *   A `try-except` block checks if the necessary Prophet DataFrames are empty. If not, `plot_coefficients` and `plot_average_contribution` are called to visualize Prophet regressor coefficients and average component contributions.
            
7.  **Saving DataFrames to Excel**:
    *   A `CommonFunctions` instance is created.
        
    *   A dictionary `dataframes_to_save` is populated with all the relevant DataFrames generated during the analysis.
        
    *   `common_fns.save_dataframes_to_excel_use()` is called to save all these DataFrames into a single Excel file, organized by sheet.
        
8.  **Error Handling**:
    *   The entire execution is wrapped in `try-except` blocks to catch potential errors:
        *   `FileNotFoundError`: If `config.json` is not found.
            
        *   `json.JSONDecodeError`: If `config.json` is malformed.
            
        *   `Exception`: Catches any other unexpected errors during execution, logging them to the console.