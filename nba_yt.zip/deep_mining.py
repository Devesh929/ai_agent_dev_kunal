import pandas as pd
import numpy as np
from mlxtend.frequent_patterns import fpgrowth, association_rules
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
import warnings
warnings.filterwarnings('ignore')

def run_deep_mining():
    print("Loading datasets...")
    try:
        players = pd.read_csv('data/nba_player_logs_2012_2026.csv')
        stocks = pd.read_csv('data/sp500_stock_data_2012_2026.csv')
    except FileNotFoundError:
        print("Data files not found.")
        return

    print("Engineering granular player features...")
    players['GAME_DATE'] = pd.to_datetime(players['GAME_DATE']).dt.tz_localize(None)
    
    # We will look for extreme performances (PTS > 20, REB > 10, AST > 8, FG3M > 4)
    # Creating a massive list of binary events for all players
    events = []
    
    # To avoid memory issues, we'll vectorize this
    # Only consider players who played at least some minutes
    players = players[players['MIN'] > 5]
    
    # Create categorical strings for the events
    pts_events = players[players['PTS'] >= 25][['GAME_DATE', 'PLAYER_NAME']].copy()
    pts_events['Event'] = pts_events['PLAYER_NAME'] + "_PTS_25+"
    
    reb_events = players[players['REB'] >= 12][['GAME_DATE', 'PLAYER_NAME']].copy()
    reb_events['Event'] = reb_events['PLAYER_NAME'] + "_REB_12+"
    
    ast_events = players[players['AST'] >= 10][['GAME_DATE', 'PLAYER_NAME']].copy()
    ast_events['Event'] = ast_events['PLAYER_NAME'] + "_AST_10+"
    
    fg3_events = players[players['FG3M'] >= 5][['GAME_DATE', 'PLAYER_NAME']].copy()
    fg3_events['Event'] = fg3_events['PLAYER_NAME'] + "_3PM_5+"
    
    all_events = pd.concat([pts_events, reb_events, ast_events, fg3_events])
    all_events.drop(columns=['PLAYER_NAME'], inplace=True)
    all_events['Value'] = True
    
    # Pivot to wide format (sparse binary matrix)
    print("Pivoting player events to sparse matrix...")
    events_wide = all_events.drop_duplicates(subset=['GAME_DATE', 'Event']).pivot(index='GAME_DATE', columns='Event', values='Value').fillna(False)
    events_wide.reset_index(inplace=True)
    
    print(f"Created {events_wide.shape[1] - 1} unique player event features.")
    
    print("Engineering target stock features...")
    stocks['Date'] = pd.to_datetime(stocks['Date']).dt.tz_localize(None)
    stocks.sort_values(by=['Ticker', 'Date'], inplace=True)
    
    # Focus on major tech stocks and indices to find our "arbitrage" rules
    target_tickers = ['TSLA', 'AAPL', 'MSFT', 'NVDA', '^GSPC']
    target_stocks = stocks[stocks['Ticker'].isin(target_tickers)].copy()
    
    target_stocks['Pct_Change'] = target_stocks.groupby('Ticker')['Close'].pct_change() * 100
    # Create triggers: e.g. TSLA_Up_>1%
    target_stocks['Up_Strong'] = target_stocks['Pct_Change'] > 1.0
    target_stocks['Down_Strong'] = target_stocks['Pct_Change'] < -1.0
    
    # Wide format for stocks
    up_wide = target_stocks.pivot(index='Date', columns='Ticker', values='Up_Strong').fillna(False)
    up_wide.columns = [f"{c}_Up>1%" for c in up_wide.columns]
    
    down_wide = target_stocks.pivot(index='Date', columns='Ticker', values='Down_Strong').fillna(False)
    down_wide.columns = [f"{c}_Down>1%" for c in down_wide.columns]
    
    stocks_wide = pd.concat([up_wide, down_wide], axis=1).reset_index()
    
    print("Aligning dates (T -> T+1)...")
    stock_dates = sorted(stocks_wide['Date'].unique())
    stock_date_df = pd.DataFrame({'Stock_Date': stock_dates})
    
    def get_next_trading_day(game_date):
        future_dates = stock_date_df[stock_date_df['Stock_Date'] > game_date]
        if not future_dates.empty:
            return future_dates.iloc[0]['Stock_Date']
        return pd.NaT

    events_wide['Next_Trading_Date'] = events_wide['GAME_DATE'].apply(get_next_trading_day)
    
    print("Merging into final dataset...")
    merged = pd.merge(events_wide, stocks_wide, left_on='Next_Trading_Date', right_on='Date', how='inner')
    merged.drop(columns=['GAME_DATE', 'Next_Trading_Date', 'Date'], inplace=True)
    
    print(f"Final matrix shape: {merged.shape}")
    
    # -----------------------------------------------------
    # ASSOCIATION RULE MINING (FP-GROWTH)
    # -----------------------------------------------------
    print("\n--- Running FP-Growth Association Rule Mining ---")
    # FP-Growth requires all boolean
    frequent_itemsets = fpgrowth(merged, min_support=0.015, use_colnames=True)
    rules = association_rules(frequent_itemsets, metric="confidence", min_threshold=0.7)
    
    # Filter rules to only show NBA events implying Stock movements
    nba_features = set(events_wide.columns) - {'GAME_DATE', 'Next_Trading_Date'}
    stock_features = set(stocks_wide.columns) - {'Date'}
    
    interesting_rules = []
    for idx, row in rules.iterrows():
        antecedents = set(row['antecedents'])
        consequents = set(row['consequents'])
        
        # We want NBA events -> Stock event
        if antecedents.issubset(nba_features) and consequents.issubset(stock_features):
            interesting_rules.append(row)
            
    if interesting_rules:
        rules_df = pd.DataFrame(interesting_rules)
        rules_df.sort_values(by='confidence', ascending=False, inplace=True)
        rules_df.to_csv('data/fp_growth_rules.csv', index=False)
        print("Top 10 Arbitrage Rules (Highest Confidence):")
        for i, row in rules_df.head(10).iterrows():
            ants = ", ".join(list(row['antecedents']))
            cons = ", ".join(list(row['consequents']))
            print(f"IF [{ants}] THEN [{cons}] -> Confidence: {row['confidence']:.2f}, Support: {row['support']:.3f}, Lift: {row['lift']:.2f}")
    else:
        print("No rules met the confidence threshold.")
        
    # -----------------------------------------------------
    # SUPERVISED DEEP/ENSEMBLE LEARNING (FEATURE IMPORTANCE)
    # -----------------------------------------------------
    print("\n--- Running Supervised Model for TSLA Prediction ---")
    # Can we predict if TSLA goes UP > 1% using ONLY the NBA events?
    target = 'TSLA_Up>1%'
    if target in merged.columns:
        X = merged[list(nba_features)]
        y = merged[target]
        
        # Use Random Forest to extract non-linear feature importances
        clf = RandomForestClassifier(n_estimators=100, max_depth=10, random_state=42)
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        
        clf.fit(X_train, y_train)
        preds = clf.predict(X_test)
        acc = accuracy_score(y_test, preds)
        print(f"Random Forest TSLA Direction Accuracy: {acc:.2f}")
        
        # Feature Importance
        importances = clf.feature_importances_
        indices = np.argsort(importances)[::-1]
        
        print(f"\nTop 10 NBA Triggers for {target} (Non-Linear Feature Importance):")
        top_features = []
        for f in range(10):
            print(f"{X.columns[indices[f]]}: {importances[indices[f]]:.4f}")
            top_features.append((X.columns[indices[f]], importances[indices[f]]))
            
        pd.DataFrame(top_features, columns=['Feature', 'Importance']).to_csv('data/rf_importance_tsla.csv', index=False)

if __name__ == "__main__":
    run_deep_mining()
