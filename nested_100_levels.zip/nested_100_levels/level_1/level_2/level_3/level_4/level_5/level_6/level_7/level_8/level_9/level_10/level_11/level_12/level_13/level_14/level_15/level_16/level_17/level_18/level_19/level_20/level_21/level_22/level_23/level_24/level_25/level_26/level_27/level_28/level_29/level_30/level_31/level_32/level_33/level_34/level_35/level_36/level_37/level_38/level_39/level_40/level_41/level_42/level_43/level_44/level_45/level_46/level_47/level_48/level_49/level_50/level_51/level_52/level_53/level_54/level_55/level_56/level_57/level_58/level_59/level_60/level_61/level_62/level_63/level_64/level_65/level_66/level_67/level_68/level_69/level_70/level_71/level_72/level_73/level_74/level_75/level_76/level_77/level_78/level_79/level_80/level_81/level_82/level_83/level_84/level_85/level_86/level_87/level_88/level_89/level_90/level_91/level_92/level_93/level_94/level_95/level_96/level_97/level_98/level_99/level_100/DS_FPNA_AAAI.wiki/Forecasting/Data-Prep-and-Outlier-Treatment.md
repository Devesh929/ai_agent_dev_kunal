# **1. Overview**

This module is responsible for taking the raw time series data, identifying and treating business outliers, identifying and treating ML outliers, imputing missing values and at last giving a view on what all transformations that are performed.

# **2. Key features**
These are the key features of this module which are toggleable with config.

- **Detect and Treat Business outliers** - There are columns which are meant to be negative, but are positive for few data points. For example expenses. This happens due to adjustments. These are called business outliers and we need to treat them. We can either make it zero, or make it null and fill it with missing value techniques.

- **Outlier Detection** - This module uses outlier detection framework from 'Anomaly' capability to detect outliers. Hyper-tunning of  Isolation forest, Local Outlier Factor and one class SVM, and chooses the best model based on silhouette score and then flags outliers for all columns .

- **Outlier Imputation** - This module is being used after Outlier Detection module. It fills the the outliers flagged in Outlier Detection module based on Interpolation or Forward/Backward Fill.

- **Missing Value Imputation** - This module is being used to treat null values found in the data. Also Business Outliers can also be converted to null and treated in this module. It again uses Interpolation or Forward/Backward Fill to impute null values.

- **Final Tracker** - At last one tracker is created which shows the original column, final treated column, difference between them and reason behind the treatment. This helps to keep a track of the changes that are being done on the data through this module.


# **3. Inputs**

- A Time Series Dataframe with date column.
- Config given below.
    
```
"data_prep_config":{
        "input_file_name":"raw_data_actuals_till_2025_06_01",   ---> input file name (used in wrapper)
        "test_data_date_range":{"from":"2025-03-01", "to":"2025-06-01"},  ---> date range of test data, this data wont be outlier treated.
        "run_missing_value_on_test_data":true,   ---> whether to run missing value treatment on test data or not
        "column_loop_in_wrapper":false,     ---> whether to create a seperate modelling level for columns in wrapper
        "business_outliers":{"make_opposite_sign_null_or_zero":"null"}, --> whether to make a business outlier 'null' or 'zero'
        "run_outlier_module":false,       --> if this is false, it will skip outlier detection and imputation
        "run_outlier_detection":true,     --> if this is false, it will skip outlier detection only
        "run_outlier_imputation": false,   --> if this is false, it will skip outlier imputation only
        "clean_all_columns":true,         --> whether to clean all column names
        "make_all_columns_positive":true,  --> whether to make all columns with positive sign at last
        "outlier_treatment_config":{
            "consecutive_imputation_threshold": 3,   --> skip imputation if consecutive outliers are more than this number      
            "missing_value_threshold": 0.5,           --> fills the missing value with 0 if percentage of missing value exceeds
            "columns_to_exclude_from_imputation": [],  --> excludes missing value imputation of these columns
            "preferred_methods": {},        --> column wise preferred method for missing value and outlier treatment
            "user_defined_model_dict": {},   --> column wise models for outlier detection
            "model_params": {          ---> hyperparameter grid for anomaly detection models
                "IsolationForest": {
                    "contamination": [0.001, 0.022, 0.044, 0.06, 0.08, 0.10, 0.13, 0.15],
                    "n_estimators": [100, 200, 500],
                    "max_samples": ["auto"],
                    "max_features": [0.5, 0.7, 0.9, 1.0]
                },
                "LOF": {
                    "contamination": [0.001, 0.022, 0.044, 0.06, 0.08, 0.10, 0.13, 0.15],
                    "n_neighbors": [5, 7, 10, 12],
                    "metric": ["euclidean", "manhattan"]
                },
                "OneClassSVM": {
                    "kernel": ["rbf"],
                    "nu": [0.001, 0.022, 0.044, 0.06, 0.08, 0.10, 0.13, 0.15],
                    "gamma": ["scale"]
                }
            },
            "min_non_zero_points": 36,     --> skip the columns if minimum number of non zero or non null data points is less than this for outlier detection
            "models": { "method": "IQR"}    --> statistical methods used to verify outliers detected using above models
        }
    }
```

# **4. Folder Structure**

    forecasting_core/components
    ├── data_prep
       ├── missing_value_treatment
           ├── main.py                         
       ├── outlier_treatment     
           ├── main.py 
           ├── outlier_detection.py       
           ├── outlier_imputation.py  
      ├── main.py                       #this is the main file

# **Flow of Main Code**

::: mermaid
 graph TD
    A[Start: def run in main.py] --> C[Convert business outliers to null or zero]
    C --> E[Fill nulls with 0 for anomaly detection]

    E --> F{Outlier module enabled?}
    F -- Yes --> G[Run OutlierTreatment module]
    F -- No --> H[Skip, pass data unchanged]

    G --> I[Get outlier treated data]
    H --> I

    I --> J[Re-fill original nulls]

    J --> L{Outlier module enabled?}
    L -- Yes --> M[Add test data as it is removed previously in outlier module]
    L -- No --> N[Skip]

    M --> O[Run MissingValueTreatment module]
    N --> O

    O --> Q[Generate and save final tracker as excel]

    Q --> S{Clean all column names?}
    S -- Yes --> T[Remove special chars and rename columns]
    S -- No --> U[Skip]

    T --> V{Make all values positive?}
    U --> V

    V -- Yes --> W[Convert all values to absolute]
    V -- No --> X[Skip]

    W --> Y[Save final treated dataframe]
    X --> Y
:::

# **Business Outliers**

::: mermaid
graph TD
    A[Start: def make_opposite_sign_null_or_zero in main.py] --> B[Loop through each modelling_level in full data]
    B --> C[Loop through each column in data]
    C --> F{number of +ve values >= number of -ve values ?}
    
    F -- Yes --> G[Column is considered positive]
    G --> H{null_or_zero = 'null'?}
    H -- Yes --> I[Replace all negative values with NaN]
    H -- No --> J[Replace all negative values with 0]
    
    F -- No --> K[Column is considered negative]
    K --> L{null_or_zero = 'null'?}
    L -- Yes --> M[Replace all non-negative values with NaN]
    L -- No --> N[Replace all non-negative values with 0]

    I --> O[Store updated data]
    J --> O
    M --> O
    N --> O
    O --> P[Repeat for all columns and combinations]
    P --> Q[Return updated data]
:::

# **Outlier Detection**

::: mermaid
graph TD
    A[Start: def detect_single_column in outlier_detection.py] --> B[Loop through each column using ThreadPoolExecutor]
    B --> C{Check column exists and has enough non-NaN values}
    C -- No --> D[Log warning and skip column]
    C -- Yes --> E[Standardize column using StandardScaler]
    E --> F[Select best model using silhouette score]
    F --> J[Get IQR or CI bounds]
    J --> L[keep only outliers which are also outliers for IQR or CI]
    L --> M[Aggregate all results after loop is completed]
    M --> N[Add anomaly_label, anomaly_score, anomaly_model columns to DataFrame]
:::

# **Outlier Imputation and Missing Value Imputation**

::: mermaid
graph TD
    A[Start: def handle_outliers in outlier_detection.py] --> B[take outliers detected in outlier detection module] --> M{number of consecutive outliers > consecutive_imputation_threshold ?} 
    M -- Yes --> N[dont consider them for outlier treatment]
    M -- No --> O[make those outliers as null]
    C[Start: def handle in missing_value_treatment/main.py] --> D[take missing values detected in data] --> K{missing value percentage greater than missing_value_threshold ?}
    K -- Yes --> L[fill column with 0 and skip]
    K -- No --> E[fix leading/trailing missing values using ffill/bfill]
    E --> F[use Ljung-Box to decide on ffill/bfill or interpolation]
    O --> F
    F -- ffill/bfill --> G[Fill using ffill and bfill]
    F -- interpolation --> H[Choose best interpolation method by Detecting seasonality using Lomb-Scargle periodogram and Fisher's g-test]
    H --> I[spline]
    H --> J[linear]
:::


