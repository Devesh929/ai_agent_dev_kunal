# Objective
Evaluate if Spark jobs can be executed on **Azure Machine Learning** using **serverless Spark compute**, and determine feasibility for distributed ML workflows with minimal infrastructure management.

# Scope
*   Author jobs using both **YAML** and **Python SDK (`azure.ai.ml.spark`)**
*   Run a basic PySpark-based ML/data pipeline
*   Test across multiple Spark runtime versions (`3.2`, `3.3`, `3.4+`)
*   Confirm if standard Python libraries (e.g., `scikit-learn`, `pandas`, `pyspark`) can run without issue

# Setup Summary
| Component | Detail |
| --- | --- |
| **Compute** | Azure ML serverless Spark |
| **Runtime** | Tested: `3.2.0`, `3.3.0`, `3.4.0+` |
| **Submission** | Both YAML and SDK-based job submission attempted |
| **Environment** | Custom Conda env (see code section) |
| **Auth Mode** | `user_identity` (interactive login) |
| **Storage** | ADLS Gen2 via `azureml://` path |

_Code files used_: [03_parallel_runs_using_serverless_spark - Repos](https://dev.azure.com/ABB-FPNA-AAAI/DS_FPNA_AAAI/_git/ML_PLATFORM?path=/reuse_module/model_training/03_parallel_runs_using_serverless_spark&version=GBfeature/spark-jobs-serverless-compute&_a=contents)

# Execution Breakdown
| Step | Description | Status | Notes |
| --- | --- | --- | --- |
| 1 | YAML-based job submission | ✅ | Successfully parsed and submitted jobs |
| 2 | SDK-based job submission (`spark()`) | ✅ | Able to define and push jobs programmatically |
| 3 | Runtime: Spark `3.2.0` | ❌ Failed | No longer supported—runtime error during job scheduling |
| 4 | Runtime: Spark `3.3.0` | ❌ Failed | Throws: `Missing env var: 'AZUREML_SYNAPSE_CLUSTER_IDENTIFIER'` |
| 5 | Runtime: Spark `3.4.0` and above | ❌ Failed | `Value passed is not a data binding string... Version not supported` |

**_Runtime 3.2_** :
Job URL: [Forecast-Spark-Job-Serverless - Azure AI | Machine Learning Studio](https://ml.azure.com/experiments/id/50385db7-181a-4926-acbc-824b9b2d3bfd/runs/silver_shelf_sff0czwnfs?wsid=/subscriptions/f6baff3f-4299-4ea3-b5e4-d5f539f22f49/resourcegroups/rg-dev-aaai-mlops/providers/Microsoft.MachineLearningServices/workspaces/mlws-dev-aaai-mlops&tid=372ee9e0-9ce0-4033-a64a-c07073a91ecd)

**_Runtime 3.3_** :
Job URL: [Forecast-Spark-Job-Serverless - Azure AI | Machine Learning Studio](https://ml.azure.com/experiments/id/50385db7-181a-4926-acbc-824b9b2d3bfd/runs/teal_balloon_cjg3l85dct?wsid=/subscriptions/f6baff3f-4299-4ea3-b5e4-d5f539f22f49/resourcegroups/rg-dev-aaai-mlops/providers/Microsoft.MachineLearningServices/workspaces/mlws-dev-aaai-mlops&tid=372ee9e0-9ce0-4033-a64a-c07073a91ecd)
Azure Open Issue: [[azure-ml] Serverless Spark compute fails with missing Synapse cluster identifier · Issue · Azure/azure-sdk-for-python](https://github.com/Azure/azure-sdk-for-python/issues/39646)

**_Runtime 3.4 and Above_** :
Job submission error: ![image.png](/.attachments/image-8cd7abed-1bad-44bb-b68c-a5be439d9e12.png)

# Outcome
This PoC **did not succeed**. Spark job execution on Azure ML serverless compute is **not currently feasible** under the tested conditions.

# Key Observations
*   Spark version support is limited; `3.4.0+` not yet accepted, `3.2.0` deprecated
    
*   `3.3.0` requires a **Synapse cluster identifier**, which is **not applicable to serverless mode**. This is an open issue on azure official python SDK repository. 
    
*   SDK and YAML both support job definition and submission cleanly
    
*   The Conda environment and script structure are valid, but **execution fails due to backend runtime issues**

# Blocking Issues
| Issue | Detail |
| --- | --- |
| Spark 3.2.0 deprecated | Job fails at runtime with unsupported version error |
| Spark 3.3.0 requires Synapse configuration | `AZUREML_SYNAPSE_CLUSTER_IDENTIFIER` not available in serverless setup [open issue](https://github.com/Azure/azure-sdk-for-python/issues/39646) |
| Spark 3.4.0+ not yet accepted | AML throws strict validation error on runtime version |

# Next Steps

*    Reach out to Microsoft support to confirm serverless Spark roadmap/version roadmap
    
*    Explore alternative options: Use **custom AKS Spark cluster**, Evaluate **Azure Synapse Spark pools** if compatible
        
*    Revisit Spark-based parallelism vs. orchestrating multiple parallel Python jobs on AML
