## Objective
The objective here is to set up Pyroscope for profiling from projects or experiments. Pyroscope does not store any data just use the data from traces and logs.

---
## Pre-requisites
- Azure CLI
- AKS
- Kubernetes
---
## Steps
These steps are to set up Tempo in an AKS cluster using a YAML template

### Setting up an AKS Cluster

- If you want to create a Cluster follow the _**Create AKS**_ runbook.

- Bind the cluster to kubectl
```
az aks get-credentials --resource-group <MY_RESOURCE_GROUP_NAME> --name <MY_AKS_CLUSTER_NAME>
```

### Install helm chart

1. Create a namespace
```
kubectl create namespace <namespace>
```
2. Set Up helm repo
```
helm repo add grafana https://grafana.github.io/helm-charts
helm repo update
```
3. Install Pyroscope
```
helm -n <namespace> install pyroscope grafana/pyroscope
```
4. A querier service would be created which can be used to make connection to grafana