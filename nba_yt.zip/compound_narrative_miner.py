import pandas as pd
import numpy as np

def run_compound_miner():
    print("Loading data for Compound Miner...")
    try:
        players = pd.read_csv('data/nba_player_logs_2012_2026.csv', usecols=['GAME_DATE', 'PLAYER_NAME', 'PTS', 'REB', 'AST', 'FG3M', 'TEAM_ID', 'GAME_ID'])
        teams = pd.read_csv('data/nba_team_logs_2012_2026.csv', usecols=['GAME_ID', 'TEAM_ID', 'TEAM_NAME', 'WL', 'PTS'])
        stocks = pd.read_csv('data/sp500_stock_data_2012_2026.csv', usecols=['Date', 'Ticker', 'Close'])
    except Exception as e:
        print(f"Error loading data: {e}")
        return

    players['GAME_DATE'] = pd.to_datetime(players['GAME_DATE']).dt.tz_localize(None)
    stocks['Date'] = pd.to_datetime(stocks['Date']).dt.tz_localize(None)
    stocks.sort_values(by=['Ticker', 'Date'], inplace=True)
    
    stocks['Pct_Change'] = stocks.groupby('Ticker')['Close'].pct_change() * 100
    stocks['Went_Up'] = stocks['Pct_Change'] > 0
    stocks['Went_Down'] = stocks['Pct_Change'] < 0

    target_tickers = {
        'TSLA': 'Tesla', 'AAPL': 'Apple', 'MSFT': 'Microsoft', 'AMZN': 'Amazon',
        'NFLX': 'Netflix', 'META': 'Meta', 'KO': 'Coca-Cola', 'MCD': 'McDonalds',
        'SBUX': 'Starbucks', 'NKE': 'Nike', 'DIS': 'Disney', 'UBER': 'Uber',
        'UAL': 'United Airlines', 'DAL': 'Delta Airlines', 'JPM': 'JPMorgan Chase',
        'BAC': 'Bank of America', 'WMT': 'Walmart', 'TGT': 'Target'
    }
    stocks = stocks[stocks['Ticker'].isin(target_tickers.keys())]

    stock_dates = sorted(stocks['Date'].unique())
    stock_date_df = pd.DataFrame({'Stock_Date': stock_dates})
    
    def get_next_trading_day(game_date):
        future = stock_date_df[stock_date_df['Stock_Date'] > game_date]
        if not future.empty:
            return future.iloc[0]['Stock_Date']
        return pd.NaT

    print("Merging player and team logs to create compound events...")
    # Merge players with their team's outcome
    compound_df = pd.merge(players, teams[['GAME_ID', 'TEAM_ID', 'TEAM_NAME', 'WL']], on=['GAME_ID', 'TEAM_ID'], how='inner')
    
    unique_game_dates = pd.DataFrame({'GAME_DATE': compound_df['GAME_DATE'].unique()})
    unique_game_dates['Next_Trading_Date'] = unique_game_dates['GAME_DATE'].apply(get_next_trading_day)
    compound_df = pd.merge(compound_df, unique_game_dates, on='GAME_DATE', how='left')
    
    compound_df.dropna(subset=['Next_Trading_Date'], inplace=True)
    
    # We will build boolean masks for compound events
    compound_df['Win_Flag'] = compound_df['WL'] == 'W'
    compound_df['Loss_Flag'] = compound_df['WL'] == 'L'
    
    events = []
    
    def extract_compound(df, stat_col, threshold, stat_str, outcome_flag, outcome_str):
        mask = (df[stat_col] >= threshold) & (df[outcome_flag] == True)
        ev = df[mask][['Next_Trading_Date', 'PLAYER_NAME', 'TEAM_NAME']].copy()
        ev['Event'] = ev['PLAYER_NAME'] + f" {stat_str} AND the {ev['TEAM_NAME']} {outcome_str}"
        ev.rename(columns={'Next_Trading_Date': 'Date'}, inplace=True)
        return ev[['Date', 'Event']]

    print("Extracting compound scenarios (e.g. Player scores 30+ AND Team Wins)...")
    pts20_win = extract_compound(compound_df, 'PTS', 20, "scores 20+", 'Win_Flag', "WIN")
    pts20_loss = extract_compound(compound_df, 'PTS', 20, "scores 20+", 'Loss_Flag', "LOSE")
    pts30_win = extract_compound(compound_df, 'PTS', 30, "scores 30+", 'Win_Flag', "WIN")
    pts30_loss = extract_compound(compound_df, 'PTS', 30, "scores 30+", 'Loss_Flag', "LOSE")
    reb10_win = extract_compound(compound_df, 'REB', 10, "grabs 10+ rebounds", 'Win_Flag', "WIN")
    
    all_events_df = pd.concat([pts20_win, pts20_loss, pts30_win, pts30_loss, reb10_win]).drop_duplicates()
    
    print("Filtering for high sample size events (N >= 40)...")
    event_counts = all_events_df['Event'].value_counts()
    valid_events = event_counts[event_counts >= 40].index.tolist()
    
    print(f"Total valid compound events generated: {len(valid_events)}")
    events_df_filtered = all_events_df[all_events_df['Event'].isin(valid_events)]

    print("Running greedy scan across target stocks...")
    results = []
    
    stock_up_dict = {ticker: set(stocks[(stocks['Ticker'] == ticker) & (stocks['Went_Up'] == True)]['Date']) for ticker in target_tickers.keys()}
    stock_down_dict = {ticker: set(stocks[(stocks['Ticker'] == ticker) & (stocks['Went_Down'] == True)]['Date']) for ticker in target_tickers.keys()}
    stock_all_dates_dict = {ticker: set(stocks[stocks['Ticker'] == ticker]['Date']) for ticker in target_tickers.keys()}
    
    event_to_dates = events_df_filtered.groupby('Event')['Date'].apply(set).to_dict()
    
    for event_name, dates_set in event_to_dates.items():
        for ticker, company_name in target_tickers.items():
            valid_market_dates = dates_set.intersection(stock_all_dates_dict[ticker])
            n_occurrences = len(valid_market_dates)
            
            if n_occurrences < 40:
                continue
                
            up_days = len(valid_market_dates.intersection(stock_up_dict[ticker]))
            down_days = len(valid_market_dates.intersection(stock_down_dict[ticker]))
            
            up_pct = (up_days / n_occurrences) * 100
            down_pct = (down_days / n_occurrences) * 100
            
            if up_pct >= 65.0:
                results.append({
                    'Pattern': f"Whenever {event_name}, {company_name} stock GOES UP the next day!",
                    'Accuracy': up_pct,
                    'Occurrences': n_occurrences,
                    'Score': n_occurrences * (up_pct - 50)
                })
            elif down_pct >= 65.0:
                results.append({
                    'Pattern': f"Whenever {event_name}, {company_name} stock CRASHES the next day!",
                    'Accuracy': down_pct,
                    'Occurrences': n_occurrences,
                    'Score': n_occurrences * (down_pct - 50)
                })

    res_df = pd.DataFrame(results)
    if not res_df.empty:
        res_df.sort_values(by=['Score', 'Accuracy'], ascending=[False, False], inplace=True)
        res_df.to_csv('data/compound_patterns.csv', index=False)
        print("\n=== TOP COMPOUND YOUTUBE PATTERNS SAVED TO CSV ===\n")
        for i, row in res_df.head(15).iterrows():
            print(f"{row['Pattern']} | {row['Accuracy']:.1f}% | N={row['Occurrences']}")
    else:
        print("No patterns met the criteria.")

if __name__ == "__main__":
    run_compound_miner()
