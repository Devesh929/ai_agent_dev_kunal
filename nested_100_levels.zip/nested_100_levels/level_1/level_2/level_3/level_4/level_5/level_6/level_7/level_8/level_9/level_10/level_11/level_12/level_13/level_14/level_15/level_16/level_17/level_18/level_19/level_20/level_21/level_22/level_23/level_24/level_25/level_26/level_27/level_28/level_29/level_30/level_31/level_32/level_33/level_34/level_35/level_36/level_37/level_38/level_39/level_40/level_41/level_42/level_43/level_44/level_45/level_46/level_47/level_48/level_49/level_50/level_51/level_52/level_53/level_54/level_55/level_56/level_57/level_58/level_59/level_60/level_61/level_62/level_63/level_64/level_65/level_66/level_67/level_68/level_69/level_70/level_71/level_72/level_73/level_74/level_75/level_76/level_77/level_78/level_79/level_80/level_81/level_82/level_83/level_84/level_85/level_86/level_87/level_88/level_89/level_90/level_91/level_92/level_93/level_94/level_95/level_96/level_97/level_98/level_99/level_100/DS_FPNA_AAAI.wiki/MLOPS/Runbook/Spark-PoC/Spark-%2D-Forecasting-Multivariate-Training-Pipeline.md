## Process Overview
::: mermaid
graph TB

  

    %% External nodes

    Note["Note: A Spark Application is created for each model and target variable"]

    App[Spark Application]

    Storage[Storage Account]

    MLflow[Azure ML Workspace - MLFlow]

  

    %% Kubernetes Cluster

    subgraph KUBERNETES CLUSTER

        GroupBy[groupBy on division]

        Task1[Task 1 - ELSB]

        Task2[Task 2 - ELSP]

        Task3[Task 3 - ELSE]

        Task4[Task 4 - ELDS]

        Task5[Task 5 - ELIP]

  

        subgraph Node1

            Driver[Spark Driver]

        end

  

        subgraph Node2

            Exec1["Spark Executor 1<br>• Data Preprocessing<br>• Train/Test/Val Prep<br>• Optuna Tuning"]

        end

  

        subgraph Node3

            Exec2["Spark Executor 2<br>• Data Preprocessing<br>• Train/Test/Val Prep<br>• Optuna Tuning"]

        end

  

        subgraph Node4

            Exec3["Spark Executor 3<br>• Data Preprocessing<br>• Train/Test/Val Prep<br>• Optuna Tuning"]

        end

  

        subgraph Node5

            Exec4["Spark Executor 4<br>• Data Preprocessing<br>• Train/Test/Val Prep<br>• Optuna Tuning"]

        end

  

        subgraph Node6

            Exec5["Spark Executor 5<br>• Data Preprocessing<br>• Train/Test/Val Prep<br>• Optuna Tuning"]

        end

    end

  

    %% Flow connections

    Note --> App

    App -->|submits to| Driver

    Driver --> GroupBy

    GroupBy --> Task1

    GroupBy --> Task2

    GroupBy --> Task3

    GroupBy --> Task4

    GroupBy --> Task5

  

    Task1 --> Exec1

    Task2 --> Exec2

    Task3 --> Exec3

    Task4 --> Exec4

    Task5 --> Exec5

  

    %% External logging & output connections

    Exec1 --> Storage

    Exec1 --> MLflow

    Exec2 --> Storage

    Exec2 --> MLflow

    Exec3 --> Storage

    Exec3 --> MLflow

    Exec4 --> Storage

    Exec4 --> MLflow

    Exec5 --> Storage

    Exec5 --> MLflow
:::

1. ## Directory Structure Overview

<pre>├── core/
│   ├── forecasting_components/       # Modular pipeline steps
│   │   ├── preprocessing.py          # Raw data preprocessing logic
│   │   ├── training.py               # Model training orchestration
│   │   └── prepare.py                # Feature engineering and prep
│   │
│   ├── forecasting_utils/           # Shared utility modules
│       ├── io_utils.py              # ADLS I/O with Workload Identity
│       ├── pipeline.py              # Orchestrates applyInPandas execution
│       ├── modelling_utils.py       # Optuna tuning & evaluation metrics
│       ├── prepare_utils.py         # Feature transformations
│       └── preprocess_utils.py      # Date handling, filtering, etc.

├── projects_EL_order_forecasting/  # Pipeline entry points and job triggers
│   ├── el_order_forecasting_training.py  # Unified training launcher
│   ├── main.py                           # Main entry point (if standalone)
│   └── multivariate_pipeline.py          # Partitioned multivariate run logic

├── configs/                        # Spark job and pipeline configurations
│   ├── spark_submit_multivariate/  # One YAML per target model combination
│   │   ├── spark_multivariate_orders_*.yaml
│   │   └── spark_multivariate_revenue_*.yaml
│   ├── consolidate.yaml            # Consolidation job after model runs
│   ├── multivariate_pipeline_config.yaml  # pipeline config
│   └── spark_multivariate_configs.sh  # Parallel job launcher script

├── helpers/                        # One-off scripts/utilities (e.g., consolidation)
│   └── consolidate.py              # Merges partitioned outputs

├── venv/                           # Python virtual environment (excluded from Git)

├── forecasting-architecture.mermaid  # Diagram of execution architecture
├── .gitignore                      # Excludes binaries, data artifacts
├── Dockerfile                      # Dockerized environment definition
├── README.md                       # Project overview and usage
└── requirements.txt                # Python dependency lockfile
</pre>

2. ## Submitting Multiple Spark Applications via Bash Script
The **`spark_multivariate_configs.sh`** script loops over a set of YAML files inside the `configs/spark_submit_multivariate/` directory. Each YAML file defines a separate Spark application targeting a **specific forecasting model and target variable** combination. The script uses `kubectl apply -f` to submit these YAMLs in parallel, leveraging Kubernetes to schedule independent Spark jobs concurrently.
Each YAML file acts as a fully declarative specification of one Spark application.
### Key Fields in the Spark YAML

Here’s how core fields are configured in each Spark application spec:

| Field | Description |
| --- | --- |
| `metadata.name` | Unique application name per model/target, e.g., `spark-el-order-dt-forecasting-pilot` |
| `spec.image` | Docker image for Spark job container:  <br>`asia.azurecr.io/spark-el-forecasting-pilot:<tag>` |
| `spec.mainApplicationFile` | Entry point script inside container:  <br>`/opt/spark/work-dir/projects/EL_order_forecasting/pipelines/main.py` |
| `env.MODEL_NAME` | Model to train (e.g., `decisiontree_multivariate`) |
| `env.MODELLING_TARGET` | Target variable to forecast (e.g., `Net_Revenue_net`) |

These environment variables are injected into **both driver and executor** pods via `env:` section, making them accessible within the code to dynamically configure the pipeline. <br>
![image.png](/.attachments/image-929d521e-19b2-4fce-8c3b-bf98d495df76.png)

3. ## Pipeline Steps and Data Level Parallelization
The `multivariate_pipeline()` function constructs and executes a modular forecasting pipeline using the `SparkPipeline` class. Each pipeline consists of **independently defined steps** that operate on partitioned data in parallel.
### Step Composition

The pipeline is composed as a list of modular steps:

`steps = [     (preprocess, {"pass_partitioned_data": True}),     (prepare, {"pass_partitioned_data": False}),     (optuna_training, {"pass_partitioned_data": False}), ]`

Each step is:
*   A callable (e.g., `preprocess`, `prepare`, `optuna_training`)
    
*   Paired with metadata specifying whether the function should receive partitioned data directly
    
This design allows each step to be controlled and reused independently.

### Parallelism Based on Grouping Columns

The grouping logic is determined by the project configuration. Specifically:

`input_data_path = config["paths"]["input_path"]["order_data"]`

The `SparkPipeline` class internally uses a **grouping column** (e.g., `division`, `channel`, etc.) defined in the config to partition the input data.
This enables **parallel execution**:
*   Each group is processed **independently** on its own executor
    
*   The pipeline steps are executed using `.groupBy().applyInPandas()` behind the scenes

4. ## Model Tracking and Artifacts
### Tracking Experiments
*   MLflow is integrated with `mlflow.log_param` and `mlflow.log_metric`
    
*   Trials and metrics from Optuna are recorded for each run
    
*   Backend is Azure ML Workspace (remote URI via `mlflow.set_tracking_uri()`)
### Accessing Azure Blob Storage from AKS
All file paths in your config (e.g. `order_data`, `manual_features`, `output_path`) use the **ABFS URI scheme**, which points to Azure Data Lake Storage Gen2.<br>
![image.png](/.attachments/image-6361861a-d8c2-4bdd-a4e9-4e6e9ebee2e4.png)
Access to these paths is enabled through **Azure Workload Identity** configured in the Spark job YAML. No connection strings or keys are required — authentication is handled using a federated identity and token mounted in the driver and executor pods.

Note: Always use the utility functions from `core.forecasting_utils.io_utils` to interact with files