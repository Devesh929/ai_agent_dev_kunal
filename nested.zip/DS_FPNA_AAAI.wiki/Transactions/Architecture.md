::: mermaid
flowchart TB

  %% -------- Global theme for a clean canvas --------

  %% (optional, can remove if your renderer ignores it)

  %%{init: {'theme':'base','themeVariables':{'background':'#ffffff'}}}%%

  

  %% -------- Styles: white boxes, dark text, colored borders --------

  classDef store   fill:#ffffff,stroke:#2563eb,stroke-width:1px,color:#111827;

  classDef external fill:#ffffff,stroke:#d97706,stroke-width:1px,color:#111827;

  classDef job     fill:#ffffff,stroke:#6b7280,stroke-width:1px,color:#111827;

  classDef comp    fill:#ffffff,stroke:#0f766e,stroke-width:1px,color:#111827;

  classDef thread  fill:#ffffff,stroke:#7c3aed,stroke-width:1px,color:#111827;

  

  %% -------- Layer 0: User --------

  U["[0] Analyst / Business User"]

  

  %% -------- Layer 1: Presentation --------

  subgraph L1[Presentation Layer]

    UI["[1] Streamlit UI<br/>Python / Streamlit"]

  end

  

  %% -------- Layer 2: Orchestration & Compute --------

  subgraph L2[Orchestration & Compute Layer]

    API["[2] Orchestrator API<br/>FastAPI"]

    JobQueue["[2.1] Job Queue / Workload Manager<br/>Multi-user load"]

  

    subgraph AML[Azure ML / Azure Jobs]

      ValidationJob["[3.0] Data Validation & Quality Checks Job"]

      Profiling["[3.1] Profiling Job"]

      ConfigJob["[3.2] Config / Mode Detection Job"]

      FeatJob["[3.3] Feature Selection Job"]

      ModelJob["[3.4] Model Selection + Scoring Job"]

      ExplainJob["[3.5] Thresholding & Explanation Job"]

      ClusterJob["[3.6] Clustering & Grouping Job"]

      GenAIJob["[3.7] Gen-AI Summary Job"]

      AlertingJob["[3.8] Alerting & Notification Job"]

      DriftJob["[3.9] Drift Detection Pipeline"]

      RetrainJob["[3.10] Retraining Pipeline"]

  

      ThreadPool["[3.T] In-Job Thread Pool<br/>Parallel workers (joblib / futures / Dask)"]

    end

  end

  

  %% -------- Layer 3: Data & Storage --------

  subgraph L3[Data & Storage Layer]

    Artifacts["[4.1] Session Artifact Storage<br/>Blob / ADLS"]

    Meta["[4.2] Metadata Store"]

    Logs["[4.3] Logging & Telemetry"]

  end

  

  %% -------- Layer 4: External & Monitoring --------

  subgraph L4[External & Monitoring]

    AOAI["[5.1] Azure OpenAI"]

    AAD["[5.2] Azure AD /<br/>Managed Identity"]

    Monitor["[5.3] Ops & Monitoring Dashboards"]

  end

  

  %% -------- Main top-down flow (incl. validation & scaling) --------

  U --> UI --> API

  API --> JobQueue

  JobQueue --> ValidationJob

  ValidationJob --> Profiling --> ConfigJob --> FeatJob --> ModelJob --> ExplainJob --> ClusterJob --> GenAIJob

  GenAIJob --> AlertingJob

  GenAIJob --> API

  

  %% API surfaces results & alerts back to UI

  API --> UI

  

  %% Background pipelines side but still top-down

  DriftJob --> RetrainJob

  

  %% -------- Data interactions downwards into storage layer --------

  ValidationJob --> Artifacts

  Profiling --> Artifacts

  ConfigJob --> Artifacts

  FeatJob --> Artifacts

  ModelJob --> Artifacts

  ExplainJob --> Artifacts

  ClusterJob --> Artifacts

  GenAIJob --> Artifacts

  AlertingJob --> Artifacts

  DriftJob --> Artifacts

  RetrainJob --> Artifacts

  

  ModelJob --> Meta

  DriftJob --> Meta

  RetrainJob --> Meta

  AlertingJob --> Meta

  

  %% -------- Logging: everyone logs down to Logs --------

  UI --> Logs

  API --> Logs

  JobQueue --> Logs

  ValidationJob --> Logs

  Profiling --> Logs

  ConfigJob --> Logs

  FeatJob --> Logs

  ModelJob --> Logs

  ExplainJob --> Logs

  ClusterJob --> Logs

  GenAIJob --> Logs

  AlertingJob --> Logs

  DriftJob --> Logs

  RetrainJob --> Logs

  

  %% -------- Monitoring & alerting --------

  Monitor --- Logs

  Monitor --- Meta

  AlertingJob --> Monitor

  

  %% -------- External services --------

  GenAIJob --> AOAI

  AAD --> UI

  AAD --> API

  

  %% -------- Thread-level parallelisation (dashed = internal impl detail) --------

  ValidationJob -. "parallel checks" .-> ThreadPool

  Profiling -. "parallel stats / scans" .-> ThreadPool

  FeatJob -. "parallel feature calcs" .-> ThreadPool

  ModelJob -. "parallel models / folds" .-> ThreadPool

  ExplainJob -. "SHAP / explain in threads" .-> ThreadPool

  ClusterJob -. "parallel clustering" .-> ThreadPool

  DriftJob -. "drift metrics in parallel" .-> ThreadPool

  RetrainJob -. "retrain steps in parallel" .-> ThreadPool

  

  %% -------- Failure / alert paths back to UI --------

  ValidationJob -. "on failure" .-> AlertingJob

  Profiling -. "on failure" .-> AlertingJob

  ConfigJob -. "on failure" .-> AlertingJob

  FeatJob -. "on failure" .-> AlertingJob

  ModelJob -. "on failure" .-> AlertingJob

  ExplainJob -. "on failure" .-> AlertingJob

  ClusterJob -. "on failure" .-> AlertingJob

  DriftJob -. "on failure" .-> AlertingJob

  RetrainJob -. "on failure" .-> AlertingJob

  

  AlertingJob --> API

  

  %% -------- Class assignments --------

  class Artifacts,Meta,Logs store;

  class AOAI,AAD,Monitor external;

  class ValidationJob,Profiling,ConfigJob,FeatJob,ModelJob,ExplainJob,ClusterJob,GenAIJob,AlertingJob,DriftJob,RetrainJob job;

  class UI,API,JobQueue comp;

  class ThreadPool thread;

  

  %% -------- Subgraph background styles (remove yellow) --------

  style L1 fill:#f9fafb,stroke:#d1d5db,stroke-width:1px,color:#111827;

  style L2 fill:#f9fafb,stroke:#d1d5db,stroke-width:1px,color:#111827;

  style L3 fill:#f9fafb,stroke:#d1d5db,stroke-width:1px,color:#111827;

  style L4 fill:#f9fafb,stroke:#d1d5db,stroke-width:1px,color:#111827;

:::
