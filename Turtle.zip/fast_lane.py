import os, time, json, hashlib, base64, uuid
from datetime import datetime
from typing import Optional, Dict, Any, List, Tuple

import requests
import pandas as pd
from tqdm import tqdm
from elasticsearch import Elasticsearch, exceptions as es_exc
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

# ========================
# CONFIG (EDIT THESE)
# ========================
CONFIG: Dict[str, Any] = {
    # ---- Elastic Cloud ----
    # Use ONE of:
    "cloud_id": 
    # e.g., "my-deployment:ZXMu..."; leave None if using es_endpoint 
    "es_endpoint": ,
      # ES https endpoint 
    "kibana_url": , # API key (encoded string or tuple ("id","api_key")) 
    "api_key":                       # e.g., "https://<deploy>.es.<region>.cloud.es.io"

    # Elasticsearch BASIC auth (no API key)
    "es_user": "elastic",
    "es_pass": "d7CHWSdYPfEjCb0ULCyN0hCV",

    # Kibana BASIC auth (usually same user/pass)
    
    "kibana_user": "elastic",
    "kibana_pass": "d7CHWSdYPfEjCb0ULCyN0hCV",               # often same as es_pass

    # TLS verification for Kibana requests: True | False | path-to-CA
    "requests_verify": False,                                # set False TEMPORARILY only for debugging
    # Optional: Kibana space prefix, e.g. "/s/my-space"
    "kibana_space": "",

    # ---- Data/index choices ----
    "data_index": "fastlane-data-cloud-demo1",              # reuse or create
    "create_data_index": False,                             # True=create/overwrite from CSV; False=reuse
    "pairs_index": None,                                    # None => auto: fastlane-pairs-<run_name>
    "runs_index": None,                                     # None => auto: fastlane-runs-<run_name>

    # CSV (only used if create_data_index=True)
    "data_path": "./quora_pairs_sample.csv",
    "task": "text_pairs",                                   # text_pairs | text_cls
    "run_name": "cloud-demo1",
    "id_col": None,
    "text_col_a": "question1",
    "text_col_b": "question2",
    "text_col": None,                                       # for text_cls
    "label_col": "is_duplicate",

    # ---- Shortlisting config ----
    "topk": 50,
    "shortlist_mode": "bm25",                               # 'bm25' (fast) or 'hybrid' (BM25+ELSER)
    "batch_size": 100,
    "sample_frac": 1.0,
    "only_side_prefix": None,                               # e.g. "A" to shortlist only "*-A"
    "hardneg": True,

    # ELSER (only if shortlist_mode='hybrid' AND you're creating a new data index with semantic_text)
    "elser_inference_id": "fastlane-elser",
    "elser_allocations": 1,
    "elser_threads": 1,

    # Kibana auto objects
    "build_kibana": True,                                   # False to skip all Kibana auto-creation
}

# ========================
# Helpers
# ========================
def make_es_client_from_cfg(cfg: Dict[str, Any]) -> Elasticsearch:
    basic_auth = (cfg["es_user"], cfg["es_pass"])
    if cfg.get("cloud_id") and "://" not in str(cfg["cloud_id"]):
        return Elasticsearch(cloud_id=cfg["cloud_id"], basic_auth=basic_auth, request_timeout=60)
    endpoint = cfg.get("es_endpoint")
    if not endpoint:
        raise RuntimeError("Provide either a valid cloud_id or es_endpoint.")
    return Elasticsearch(hosts=[endpoint], basic_auth=basic_auth, request_timeout=60)

def normalize_text(s: str) -> str:
    s = (s or "").strip()
    return " ".join(s.split())

def sha1(s: str) -> str:
    return hashlib.sha1(s.encode("utf-8", "ignore")).hexdigest()

# --------- Kibana session + headers ---------
def kib_basic_header(user: str, pwd: str) -> str:
    return "Basic " + base64.b64encode(f"{user}:{pwd}".encode()).decode()

def kb_session(cfg: Dict[str, Any]) -> requests.Session:
    s = requests.Session()
    r = Retry(total=5, connect=5, read=5, backoff_factor=0.6,
              status_forcelist=[502, 503, 504], allowed_methods=["GET","POST","PUT","HEAD","DELETE"])
    s.mount("https://", HTTPAdapter(max_retries=r))
    s.headers.update({
        "kbn-xsrf": "true",
        "Content-Type": "application/json",
        "Authorization": kib_basic_header(cfg["kibana_user"], cfg["kibana_pass"])
    })
    s.verify = cfg.get("requests_verify", False)
    return s

def kb_url(cfg: Dict[str, Any], path: str) -> str:
    space = cfg.get("kibana_space", "")
    return f'{cfg["kibana_url"].rstrip("/")}{space}{path}'

def kb_preflight(cfg: Dict[str, Any]) -> bool:
    s = kb_session(cfg)
    try:
        r = s.get(kb_url(cfg, "/api/status"), timeout=(10, 30))
        if r.status_code != 200:
            print(f"[Kibana] /api/status -> {r.status_code} {r.text[:200]}")
            return False
        return True
    except Exception as e:
        print(f"[Kibana] Preflight error: {e}")
        return False


# ========================
# ELSER endpoint (only if needed)
# ========================
def ensure_elser_endpoint(es: Elasticsearch, inference_id="fastlane-elser",
                          allocations=1, threads=1) -> Optional[str]:
    try:
        info = es.inference.get(inference_id=inference_id)
    except Exception:
        info = None
    if not info:
        try:
            es.options(request_timeout=120).inference.put(
                task_type="sparse_embedding",
                inference_id=inference_id,
                body={"service": "elser",
                      "service_settings": {"num_allocations": allocations, "num_threads": threads}}
            )
            print(f"[ELSER] Created inference endpoint: {inference_id}")
        except es_exc.BadRequestError as e:
            if getattr(e, "error", "") == "resource_already_exists_exception":
                print(f"[ELSER] Endpoint exists: {inference_id}")
            else:
                raise
    try:
        info = es.inference.get(inference_id=inference_id)
        model_id = info["endpoints"][0]["service_settings"].get("model_id")
        print(f"[ELSER] model_id = {model_id}")
    except Exception:
        print("[ELSER] Could not read endpoint info (continuing).")
        model_id = None

    t0 = time.time()
    while model_id:
        try:
            stats = es.ml.get_trained_models_stats(model_id=model_id)
            dep = stats["trained_model_stats"][0].get("deployment_stats")
            if dep and dep.get("nodes"):
                print("[ELSER] Model deployed.")
                break
        except Exception:
            pass
        if time.time() - t0 > 300:
            print("[ELSER] Timeout waiting for deployment; continuing anyway.")
            break
        print("[ELSER] Waiting for deployment...")
        time.sleep(5)
    return model_id

# ========================
# Index creation (optional)
# ========================
def create_or_reuse_indices(
    es: Elasticsearch,
    cfg: Dict[str, Any],
    create_data_index: bool,
    use_elser_in_mapping: bool
) -> Tuple[str, str, str]:
    run = cfg["run_name"]
    data_index = cfg.get("data_index") or f"fastlane-data-{run}"
    pairs_index = cfg.get("pairs_index") or f"fastlane-pairs-{run}"
    runs_index  = cfg.get("runs_index") or f"fastlane-runs-{run}"

    # (Re)create pairs/runs each run
    for idx in (pairs_index, runs_index):
        try: es.indices.delete(index=idx, ignore_unavailable=True)
        except Exception: pass

    es.indices.create(index=pairs_index, mappings={"properties": {
        "qid": {"type": "keyword"},
        "candidate_id": {"type": "keyword"},
        "rank": {"type": "integer"},
        "score": {"type": "float"},
        "label_same": {"type": "boolean"},
        "hard_negative": {"type": "boolean"},
        "ts": {"type": "date"}
    }})

    es.indices.create(index=runs_index, mappings={"properties": {
        "run_name": {"type": "keyword"},
        "task": {"type": "keyword"},
        "k": {"type": "integer"},
        "total_docs": {"type": "integer"},
        "unchanged_skipped": {"type": "integer"},
        "dup_collapsed": {"type": "integer"},
        "shortlist_pairs": {"type": "integer"},
        "hardnegs": {"type": "integer"},
        "elapsed_sec": {"type": "float"},
        "notes": {"type": "keyword"},
        "ts": {"type": "date"}
    }})

    # Data index
    if create_data_index:
        try: es.indices.delete(index=data_index, ignore_unavailable=True)
        except Exception: pass
        props = {
            "doc_id":       {"type": "keyword"},
            "content":      {"type": "text", "copy_to": ["content_lex"] + (["content_sem"] if use_elser_in_mapping else [])},
            "content_lex":  {"type": "text"},
            "label":        {"type": "keyword"},
            "content_hash": {"type": "keyword"},
            "ts_ingested":  {"type": "date"},
            "unchanged":    {"type": "boolean"},
        }
        if use_elser_in_mapping:
            props["content_sem"] = {"type": "semantic_text", "inference_id": cfg.get("elser_inference_id", "fastlane-elser")}
        es.indices.create(index=data_index, mappings={"properties": props})
    else:
        if not es.indices.exists(index=data_index):
            raise RuntimeError(f"Configured to reuse data_index '{data_index}', but it does not exist.")

    return data_index, pairs_index, runs_index

# ========================
# CSV ingest (only if creating data index)
# ========================
def ingest_text_pairs_csv(es: Elasticsearch, csv_path: str, data_index: str,
                          id_col: Optional[str], text_a: str, text_b: str,
                          label_col: Optional[str]) -> pd.DataFrame:
    df = pd.read_csv(csv_path)
    need = [text_a, text_b] + ([label_col] if label_col else [])
    for c in need:
        if c not in df.columns:
            raise ValueError(f"Column '{c}' not found in CSV.")
    if id_col and id_col not in df.columns:
        raise ValueError(f"ID column '{id_col}' not in CSV.")

    ops, rows = [], []
    for i, r in tqdm(df.iterrows(), total=len(df), desc="Indexing text_pairs"):
        rid = str(r[id_col]) if id_col else f"row{i}"
        a = normalize_text(str(r[text_a])); b = normalize_text(str(r[text_b]))
        lab = str(r[label_col]) if label_col and (label_col in r) and pd.notna(r[label_col]) else None

        for side, content in (("A", a), ("B", b)):
            doc_id = f"{rid}-{side}"
            ch = sha1(content)
            body = {"doc_id": doc_id, "content": content, "label": lab,
                    "content_hash": ch, "ts_ingested": datetime.utcnow().isoformat(), "unchanged": False}
            ops.append({"index": {"_index": data_index, "_id": doc_id}})
            ops.append(body)
            rows.append({"doc_id": doc_id, "content": content, "label": lab})
            if len(ops) >= 2000:
                es.bulk(operations=ops, refresh=False); ops = []
    if ops: es.bulk(operations=ops, refresh=True)
    return pd.DataFrame(rows)

def ingest_text_cls_csv(es: Elasticsearch, csv_path: str, data_index: str,
                        id_col: Optional[str], text_col: str, label_col: Optional[str]) -> pd.DataFrame:
    df = pd.read_csv(csv_path)
    need = [text_col] + ([label_col] if label_col else [])
    for c in need:
        if c not in df.columns:
            raise ValueError(f"Column '{c}' not found in CSV.")
    if id_col and id_col not in df.columns:
        raise ValueError(f"ID column '{id_col}' not in CSV.")

    ops, rows = [], []
    for i, r in tqdm(df.iterrows(), total=len(df), desc="Indexing text_cls"):
        rid = str(r[id_col]) if id_col else f"row{i}"
        content = normalize_text(str(r[text_col]))
        lab = str(r[label_col]) if label_col and (label_col in r) and pd.notna(r[label_col]) else None
        ch = sha1(content)
        body = {"doc_id": rid, "content": content, "label": lab,
                "content_hash": ch, "ts_ingested": datetime.utcnow().isoformat(), "unchanged": False}
        ops.append({"index": {"_index": data_index, "_id": rid}})
        ops.append(body)
        rows.append({"doc_id": rid, "content": content, "label": lab})
        if len(ops) >= 2000:
            es.bulk(operations=ops, refresh=False); ops = []
    if ops: es.bulk(operations=ops, refresh=True)
    return pd.DataFrame(rows)

# ========================
# Shortlisting (batched _msearch)
# ========================
def shortlist_query(text: str, mode: str):
    if mode == "bm25":
        return {"bool": {"must": {"multi_match": {"fields": ["content_lex"], "query": text, "operator": "or"}}}}
    return {
        "bool": {
            "must": {"multi_match": {"fields": ["content_lex"], "query": text, "operator": "or", "boost": 1.0}},
            "should": {"semantic": {"field": "content_sem", "query": text, "boost": 3.0}},
        }
    }

def build_shortlists_batched(es: Elasticsearch, data_index: str, pairs_index: str, df: pd.DataFrame,
                             k=50, labels=False, mine_hardneg=False,
                             mode="bm25", batch_size=100, sample_frac=1.0, only_side_prefix: Optional[str]=None):
    work = df
    if only_side_prefix:
        work = work[work["doc_id"].str.endswith(f"-{only_side_prefix}")]
    if sample_frac < 1.0 and len(work) > 0:
        work = work.sample(frac=sample_frac, random_state=42)

    docs = work.to_dict("records")
    pairs_ops, total_pairs, hardneg_count = [], 0, 0

    for i in tqdm(range(0, len(docs), batch_size), desc=f"Shortlisting(batched,K={k},{mode})"):
        batch = docs[i:i + batch_size]
        body: List[Dict[str, Any]] = []
        for r in batch:
            qid, text = r["doc_id"], r["content"]
            body.append({"index": data_index})
            body.append({
                "size": k, "_source": ["label"], "track_scores": True,
                "query": shortlist_query(text, mode),
            })
        resp = es.msearch(body=body)
        responses = resp.get("responses", [])

        for r_item, r_resp in zip(batch, responses):
            qid = r_item["doc_id"]
            lab = r_item.get("label")
            hits = r_resp.get("hits", {}).get("hits", [])
            hits = [h for h in hits if h.get("_id") != qid]

            for rank, h in enumerate(hits, start=1):
                cid = h["_id"]; score = float(h["_score"])
                label_same, hard_negative = None, False
                if labels:
                    clab = h.get("_source", {}).get("label")
                    if (lab is not None) and (clab is not None):
                        label_same = (str(lab) == str(clab))
                        hard_negative = (not label_same) and (rank <= max(5, k // 10))
                        if mine_hardneg and hard_negative:
                            hardneg_count += 1

                pairs_ops.append({"index": {"_index": pairs_index}})
                pairs_ops.append({
                    "qid": qid, "candidate_id": cid, "rank": rank, "score": score,
                    "label_same": label_same, "hard_negative": hard_negative if mine_hardneg else False,
                    "ts": datetime.utcnow().isoformat(),
                })
                if len(pairs_ops) >= 2000:
                    es.bulk(operations=pairs_ops, refresh=False); total_pairs += len(pairs_ops)//2; pairs_ops = []
    if pairs_ops:
        es.bulk(operations=pairs_ops, refresh=True); total_pairs += len(pairs_ops)//2
    return total_pairs, hardneg_count

# ========================
# Kibana objects: Data View → Saved Search → Lens panels → Dashboard
# ========================
def ensure_data_view(cfg: Dict[str, Any], title: str, name: Optional[str], time_field: str="@timestamp") -> Optional[str]:
    s = kb_session(cfg)
    body = {"data_view": {"title": title, "timeFieldName": time_field}}
    if name: body["data_view"]["name"] = name
    url = kb_url(cfg, "/api/data_views/data_view")
    r = s.post(url, data=json.dumps(body), timeout=(15, 120))
    if r.status_code in (200, 201):
        return r.json()["data_view"]["id"]
    if r.status_code == 409 or "exists" in r.text.lower():
        rl = s.get(kb_url(cfg, "/api/data_views"), timeout=(15,120))
        if rl.ok:
            for dv in rl.json().get("data_views", []):
                if dv.get("title") == title:
                    return dv.get("id")
    print(f"[Kibana] Data View create failed: {r.status_code} {r.text[:300]}")
    return None

def create_saved_search(cfg: Dict[str, Any], title: str, data_view_id: str, cols: List[str],
                        sort_field: str="ts", sort_dir: str="desc", kuery: str="") -> Optional[str]:
    s = kb_session(cfg)
    search_source = {"index": data_view_id, "query": {"language": "kuery", "query": kuery}, "filter": []}
    body = {
        "attributes": {
            "title": title,
            "columns": cols,
            "sort": [[sort_field, sort_dir]],
            "kibanaSavedObjectMeta": {"searchSourceJSON": json.dumps(search_source)}
        },
        "references": [{"id": data_view_id, "name": "kibanaSavedObjectMeta.searchSourceJSON.index", "type": "index-pattern"}]
    }
    r = s.post(kb_url(cfg, "/api/saved_objects/search"), data=json.dumps(body), timeout=(15,120))
    if r.status_code in (200, 201):
        return r.json()["id"]
    if r.status_code == 409:
        q = f'/api/saved_objects/_find?type=search&search_fields=title&search={title}'
        rf = s.get(kb_url(cfg, q), timeout=(15, 120))
        if rf.ok:
            items = rf.json().get("saved_objects", [])
            for it in items:
                if it["attributes"]["title"] == title:
                    return it["id"]
    print(f"[Kibana] Saved Search create failed: {r.status_code} {r.text[:300]}")
    return None


def create_saved_search_pairs_hardnegs(cfg, title, data_view_id):
    cols = ["ts","qid","candidate_id","rank","score","label_same","hard_negative"]
    return create_saved_search(cfg, title, data_view_id, cols, sort_field="ts", sort_dir="desc", kuery="hard_negative: true")


def _base_lens_attributes(data_view_id, layer_id, x_col_id, y_col_id, vis_type, series_type):
    return {
        "title": "",
        "visualizationType": vis_type,
        "type": "lens",
        "references": [{"type": "index-pattern", "id": data_view_id, "name": f"indexpattern-datasource-layer-{layer_id}"}],
        "state": {
            "visualization": {
                "legend": {"isVisible": True, "position": "right"},
                "valueLabels": "hide",
                "fittingFunction": "None",
                "axisTitlesVisibilitySettings": {"x": True, "yLeft": True, "yRight": True},
                "tickLabelsVisibilitySettings": {"x": True, "yLeft": True, "yRight": True},
                "labelsOrientation": {"x": 0, "yLeft": 0, "yRight": 0},
                "gridlinesVisibilitySettings": {"x": True, "yLeft": True, "yRight": True},
                "preferredSeriesType": series_type,
                "layers": [{
                    "layerId": layer_id,
                    "accessors": [y_col_id],
                    "position": "top",
                    "seriesType": series_type,
                    "showGridlines": False,
                    "layerType": "data",
                    "xAccessor": x_col_id
                }]
            },
            "query": {"query": "", "language": "kuery"},
            "filters": [],
            "datasourceStates": {
                "formBased": {
                    "layers": {layer_id: {"columns": {}, "columnOrder": [], "incompleteColumns": {}, "sampling": 1}}
                },
                "indexpattern": {"layers": {}},
                "textBased": {"layers": {}}
            },
            "internalReferences": [],
            "adHocDataViews": {}
        }
    }

def lens_xy_count_over_time(data_view_id, panel_w=24, panel_h=15, grid_x=0, grid_y=0):
    panel_id = str(uuid.uuid4())
    layer_id = str(uuid.uuid4())
    x_col_id = str(uuid.uuid4())
    y_col_id = str(uuid.uuid4())
    attrs = _base_lens_attributes(data_view_id, layer_id, x_col_id, y_col_id, "lnsXY", "bar_stacked")
    attrs["state"]["datasourceStates"]["formBased"]["layers"][layer_id]["columns"][x_col_id] = {
        "label": "@timestamp", "dataType": "date", "operationType": "date_histogram",
        "sourceField": "@timestamp", "isBucketed": True, "scale": "interval",
        "params": {"interval": "auto", "includeEmptyRows": True, "dropPartials": False}
    }
    attrs["state"]["datasourceStates"]["formBased"]["layers"][layer_id]["columns"][y_col_id] = {
        "label": "Count of records", "dataType": "number", "operationType": "count",
        "isBucketed": False, "scale": "ratio", "sourceField": "___records___", "params": {"emptyAsNull": True}
    }
    attrs["state"]["datasourceStates"]["formBased"]["layers"][layer_id]["columnOrder"] = [x_col_id, y_col_id]
    panel = {"type": "lens", "gridData": {"x": grid_x, "y": grid_y, "w": panel_w, "h": panel_h, "i": panel_id},
             "panelIndex": panel_id, "embeddableConfig": {"attributes": attrs, "enhancements": {}}}
    dash_ref = {"type": "index-pattern", "id": data_view_id,
                "name": f"{panel_id}:indexpattern-datasource-layer-{layer_id}"}
    return panel, dash_ref

def lens_xy_metric_over_time(data_view_id, field: str, label: str, op: str="percentile", percentile=95,
                             panel_w=24, panel_h=15, grid_x=24, grid_y=0):
    panel_id = str(uuid.uuid4()); layer_id = str(uuid.uuid4())
    x_col_id = str(uuid.uuid4()); y_col_id = str(uuid.uuid4())
    attrs = _base_lens_attributes(data_view_id, layer_id, x_col_id, y_col_id, "lnsXY", "line")
    attrs["state"]["datasourceStates"]["formBased"]["layers"][layer_id]["columns"][x_col_id] = {
        "label": "@timestamp", "dataType": "date", "operationType": "date_histogram",
        "sourceField": "@timestamp", "isBucketed": True, "scale": "interval",
        "params": {"interval": "auto", "includeEmptyRows": True, "dropPartials": False}
    }
    if op == "avg":
        ycol = {"label": f"avg {field}", "dataType": "number", "operationType": "average",
                "isBucketed": False, "scale": "ratio", "sourceField": field, "params": {"emptyAsNull": True}}
    else:
        ycol = {"label": label, "dataType": "number", "operationType": "percentile",
                "isBucketed": False, "scale": "ratio", "sourceField": field,
                "params": {"percentile": percentile, "emptyAsNull": True}}
    attrs["state"]["datasourceStates"]["formBased"]["layers"][layer_id]["columns"][y_col_id] = ycol
    attrs["state"]["datasourceStates"]["formBased"]["layers"][layer_id]["columnOrder"] = [x_col_id, y_col_id]
    panel = {"type": "lens", "gridData": {"x": grid_x, "y": grid_y, "w": panel_w, "h": panel_h, "i": panel_id},
             "panelIndex": panel_id, "embeddableConfig": {"attributes": attrs, "enhancements": {}}}
    dash_ref = {"type": "index-pattern", "id": data_view_id,
                "name": f"{panel_id}:indexpattern-datasource-layer-{layer_id}"}
    return panel, dash_ref

def create_dashboard_with_panels(cfg: Dict[str, Any], title: str,
                                 panels: List[Dict[str, Any]], refs: List[Dict[str, Any]],
                                 time_from: str="now-24h", time_to: str="now") -> Optional[str]:
    s = kb_session(cfg)
    body = {
        "attributes": {
            "version": 1,
            "kibanaSavedObjectMeta": {"searchSourceJSON": json.dumps({"query": {"query": "", "language": "kuery"}, "filter": []})},
            "description": "Auto-created dashboard",
            "timeRestore": True,
            "optionsJSON": json.dumps({"useMargins": True, "syncColors": False, "syncCursor": True,
                                       "syncTooltips": False, "hidePanelTitles": False}),
            "panelsJSON": json.dumps(panels),
            "title": title,
            "timeFrom": time_from,
            "timeTo": time_to,
        },
        "references": refs
    }
    r = s.post(kb_url(cfg, "/api/saved_objects/dashboard"), data=json.dumps(body), timeout=(15,120))
    if r.status_code in (200, 201):
        return r.json()["id"]
    if r.status_code == 409:
        rf = s.get(kb_url(cfg, f"/api/saved_objects/_find?type=dashboard&search_fields=title&search={title}"),
                   timeout=(15,120))
        if rf.ok:
            items = rf.json().get("saved_objects", [])
            for it in items:
                if it["attributes"]["title"] == title:
                    return it["id"]
    print(f"[Kibana] Dashboard create failed: {r.status_code} {r.text[:300]}")
    return None
# -------- Extra Lens helpers focused on USP (hard negatives, shortlist quality) --------
def lens_metric_count(data_view_id, label="Count", kql: str = "", grid=(0,0), size=(12,8)):
    panel_id = str(uuid.uuid4()); layer_id = str(uuid.uuid4()); y_col_id = str(uuid.uuid4())
    attrs = {
        "title": label,
        "visualizationType": "lnsMetric",
        "type": "lens",
        "references": [{"type":"index-pattern","id":data_view_id,"name":f"indexpattern-datasource-layer-{layer_id}"}],
        "state": {
            "visualization": {"layerId": layer_id, "accessor": y_col_id, "layerType":"data"},
            "query": {"query": kql or "", "language": "kuery"},
            "filters": [],
            "datasourceStates": {
                "formBased": {"layers": {
                    layer_id: {
                        "columns": {
                            y_col_id: {"label": label, "dataType":"number", "operationType":"count",
                                       "isBucketed": False, "scale":"ratio", "sourceField":"___records___",
                                       "params":{"emptyAsNull": True}}
                        },
                        "columnOrder": [y_col_id], "incompleteColumns": {}, "sampling": 1
                    }
                }}
            },
            "internalReferences": [], "adHocDataViews": {}
        }
    }
    panel = {
        "type":"lens",
        "gridData":{"x":grid[0],"y":grid[1],"w":size[0],"h":size[1],"i":panel_id},
        "panelIndex":panel_id,
        "embeddableConfig":{"attributes":attrs,"enhancements":{}}
    }
    ref = {"type":"index-pattern","id":data_view_id,"name":f"{panel_id}:indexpattern-datasource-layer-{layer_id}"}
    return panel, ref

def lens_pie_hardneg_share(data_view_id, field="hard_negative", label="Hard negative share", grid=(12,0), size=(12,16)):
    panel_id = str(uuid.uuid4()); layer_id = str(uuid.uuid4()); a_id = str(uuid.uuid4()); b_id = str(uuid.uuid4())
    attrs = {
        "title": label, "visualizationType":"lnsPie", "type":"lens",
        "references":[{"type":"index-pattern","id":data_view_id,"name":f"indexpattern-datasource-layer-{layer_id}"}],
        "state":{
            "visualization":{
                "legend":{"isVisible":True,"position":"right"},
                "labels":{"position":"default","values":True,"category":"hide"},
                "categoryDisplay":"default","numberDisplay":"percent","nestedLegend":False,
                "shape":"pie","layerId":layer_id
            },
            "query":{"query":"","language":"kuery"},
            "filters":[],
            "datasourceStates":{
                "formBased":{"layers":{
                    layer_id:{
                        "columns":{
                            a_id: {"label": field, "dataType":"string","operationType":"terms","sourceField":field,
                                   "isBucketed": True, "scale":"ordinal",
                                   "params":{"size":2,"orderBy":{"type":"alphabetical"}, "orderDirection":"asc"} },
                            b_id: {"label":"count","dataType":"number","operationType":"count",
                                   "isBucketed": False, "scale":"ratio", "sourceField":"___records___",
                                   "params":{"emptyAsNull": True}}
                        },
                        "columnOrder":[a_id,b_id],"incompleteColumns":{}, "sampling":1
                    }
                }}
            },
            "internalReferences":[], "adHocDataViews":{}
        }
    }
    panel = {"type":"lens","gridData":{"x":grid[0],"y":grid[1],"w":size[0],"h":size[1],"i":panel_id},
             "panelIndex":panel_id,"embeddableConfig":{"attributes":attrs,"enhancements":{}}}
    ref = {"type":"index-pattern","id":data_view_id,"name":f"{panel_id}:indexpattern-datasource-layer-{layer_id}"}
    return panel, ref

def lens_xy_with_kql(data_view_id, y_label="Count", kql: str = "", grid=(0,8), size=(24,12)):
    # date histogram over ts + count, with panel-level KQL
    panel_id = str(uuid.uuid4()); layer_id = str(uuid.uuid4()); x_id = str(uuid.uuid4()); y_id = str(uuid.uuid4())
    attrs = _base_lens_attributes(data_view_id, layer_id, x_id, y_id, "lnsXY", "bar_stacked")
    attrs["state"]["query"] = {"query": kql or "", "language":"kuery"}
    # X
    attrs["state"]["datasourceStates"]["formBased"]["layers"][layer_id]["columns"][x_id] = {
        "label":"ts","dataType":"date","operationType":"date_histogram","sourceField":"ts",
        "isBucketed":True,"scale":"interval","params":{"interval":"auto","includeEmptyRows":True,"dropPartials":False}
    }
    # Y
    attrs["state"]["datasourceStates"]["formBased"]["layers"][layer_id]["columns"][y_id] = {
        "label": y_label, "dataType":"number","operationType":"count","isBucketed":False,"scale":"ratio",
        "sourceField":"___records___","params":{"emptyAsNull":True}
    }
    attrs["state"]["datasourceStates"]["formBased"]["layers"][layer_id]["columnOrder"] = [x_id,y_id]
    panel = {"type":"lens","gridData":{"x":grid[0],"y":grid[1],"w":size[0],"h":size[1],"i":panel_id},
             "panelIndex":panel_id,"embeddableConfig":{"attributes":attrs,"enhancements":{}}}
    ref = {"type":"index-pattern","id":data_view_id,"name":f"{panel_id}:indexpattern-datasource-layer-{layer_id}"}
    return panel, ref

def lens_terms_bar(data_view_id, field="qid", label="Top confusing queries", kql="hard_negative: true",
                   size_terms=10, grid=(24,8), size=(24,12)):
    # horizontal bar: top qids by hard negatives
    panel_id = str(uuid.uuid4()); layer_id = str(uuid.uuid4()); x_id = str(uuid.uuid4()); y_id = str(uuid.uuid4())
    attrs = _base_lens_attributes(data_view_id, layer_id, x_id, y_id, "lnsXY", "bar_horizontal")
    attrs["state"]["query"] = {"query": kql or "", "language":"kuery"}
    # X: terms on field
    attrs["state"]["datasourceStates"]["formBased"]["layers"][layer_id]["columns"][x_id] = {
        "label": field, "dataType":"string","operationType":"terms","sourceField":field,
        "isBucketed": True,"scale":"ordinal","params":{"size": size_terms, "orderBy":{"type":"column","columnId": y_id},
        "orderDirection":"desc","otherBucket":False,"missingBucket":False}
    }
    # Y: count
    attrs["state"]["datasourceStates"]["formBased"]["layers"][layer_id]["columns"][y_id] = {
        "label":"count","dataType":"number","operationType":"count","isBucketed":False,"scale":"ratio",
        "sourceField":"___records___","params":{"emptyAsNull":True}
    }
    attrs["state"]["datasourceStates"]["formBased"]["layers"][layer_id]["columnOrder"] = [x_id, y_id]
    panel = {"type":"lens","gridData":{"x":grid[0],"y":grid[1],"w":size[0],"h":size[1],"i":panel_id},
             "panelIndex":panel_id,"embeddableConfig":{"attributes":attrs,"enhancements":{}}}
    ref = {"type":"index-pattern","id":data_view_id,"name":f"{panel_id}:indexpattern-datasource-layer-{layer_id}"}
    return panel, ref

def lens_score_histogram(data_view_id, kql: str = "", grid=(0,20), size=(24,12)):
    # histogram of 'score' (where ranking is uncertain); KQL can isolate hard negatives
    panel_id = str(uuid.uuid4()); layer_id = str(uuid.uuid4()); x_id = str(uuid.uuid4()); y_id = str(uuid.uuid4())
    attrs = _base_lens_attributes(data_view_id, layer_id, x_id, y_id, "lnsXY", "bar_stacked")
    attrs["state"]["query"] = {"query": kql or "", "language":"kuery"}
    # X: histogram on 'score'
    attrs["state"]["datasourceStates"]["formBased"]["layers"][layer_id]["columns"][x_id] = {
        "label": "score", "dataType":"number","operationType":"histogram","sourceField":"score",
        "isBucketed": True,"scale":"interval","params":{"interval": 0.5, "maxBars":100}
    }
    # Y: count
    attrs["state"]["datasourceStates"]["formBased"]["layers"][layer_id]["columns"][y_id] = {
        "label":"count","dataType":"number","operationType":"count","isBucketed":False,"scale":"ratio",
        "sourceField":"___records___","params":{"emptyAsNull":True}
    }
    attrs["state"]["datasourceStates"]["formBased"]["layers"][layer_id]["columnOrder"] = [x_id, y_id]
    panel = {"type":"lens","gridData":{"x":grid[0],"y":grid[1],"w":size[0],"h":size[1],"i":panel_id},
             "panelIndex":panel_id,"embeddableConfig":{"attributes":attrs,"enhancements":{}}}
    ref = {"type":"index-pattern","id":data_view_id,"name":f"{panel_id}:indexpattern-datasource-layer-{layer_id}"}
    return panel, ref


# ========================
# Metrics & push
# ========================
def push_run_metrics(es: Elasticsearch, runs_index: str, run_name: str, task: str,
                     k: int, total_docs: int, unchanged_skipped: int, dup_collapsed: int,
                     shortlist_pairs: int, hardnegs: int, elapsed_sec: float, notes: str):
    es.index(index=runs_index, document={
        "run_name": run_name, "task": task, "k": k,
        "total_docs": total_docs, "unchanged_skipped": unchanged_skipped,
        "dup_collapsed": dup_collapsed, "shortlist_pairs": shortlist_pairs,
        "hardnegs": hardnegs, "elapsed_sec": elapsed_sec, "notes": notes,
        "ts": datetime.utcnow().isoformat()
    }, refresh=True)

# ========================
# Main
# ========================
def main(cfg: Dict[str, Any]):
    # ES client (basic auth)
    es = make_es_client_from_cfg(cfg)
    info = es.info()
    print(f"[ES] Connected: {info['version']['number']} cluster={info['cluster_name']}")

    t0 = time.time()
    run = cfg["run_name"]
    shortlist_mode = cfg.get("shortlist_mode", "bm25")

    # Ensure ELSER only if hybrid and creating new semantic mapping
    need_elser = (shortlist_mode == "hybrid") and bool(cfg.get("create_data_index", False))
    if need_elser:
        ensure_elser_endpoint(
            es,
            inference_id=cfg.get("elser_inference_id", "fastlane-elser"),
            allocations=int(cfg.get("elser_allocations", 1)),
            threads=int(cfg.get("elser_threads", 1)),
        )

    # Indices
    data_index, pairs_index, runs_index = create_or_reuse_indices(
        es, cfg, create_data_index=bool(cfg.get("create_data_index", False)),
        use_elser_in_mapping=(shortlist_mode == "hybrid" and bool(cfg.get("create_data_index", False)))
    )
    print(f"[Index] Data={data_index}  Pairs={pairs_index}  Runs={runs_index}")

    # Ingest (only if creating data index)
    if cfg.get("create_data_index", False):
        if cfg["task"] == "text_pairs":
            df = ingest_text_pairs_csv(es, cfg["data_path"], data_index,
                                       id_col=cfg.get("id_col"),
                                       text_a=cfg["text_col_a"], text_b=cfg["text_col_b"],
                                       label_col=cfg.get("label_col"))
        elif cfg["task"] == "text_cls":
            df = ingest_text_cls_csv(es, cfg["data_path"], data_index,
                                     id_col=cfg.get("id_col"),
                                     text_col=cfg["text_col"],
                                     label_col=cfg.get("label_col"))
        else:
            raise RuntimeError("Supported tasks: text_pairs, text_cls")
    else:
        # reuse existing data index → fetch minimal fields
        df_rows = []
        page = es.search(index=data_index, size=1000, query={"match_all": {}}, _source=["doc_id","content","label"])
        while True:
            hits = page["hits"]["hits"]
            if not hits: break
            for h in hits:
                src = h["_source"]
                df_rows.append({"doc_id": src.get("doc_id", h["_id"]), "content": src.get("content",""), "label": src.get("label")})
            if len(hits) < 1000: break
            last_sort = hits[-1].get("sort")
            if not last_sort: break
            page = es.search(index=data_index, size=1000, query={"match_all": {}},
                             sort=[{"_shard_doc":"asc"}], search_after=last_sort,
                             _source=["doc_id","content","label"])
        df = pd.DataFrame(df_rows)

    total_docs = len(df)

    # unchanged count (best-effort)
    try:
        ag = es.search(index=data_index, size=0, aggs={"unchanged": {"filter": {"term": {"unchanged": True}}}})
        unchanged_skipped = ag["aggregations"]["unchanged"]["doc_count"]
    except Exception:
        unchanged_skipped = 0

    # Shortlists
    total_pairs, hardnegs = 0, 0
    if total_docs > 0:
        total_pairs, hardnegs = build_shortlists_batched(
            es, data_index, pairs_index, df,
            k=int(cfg["topk"]),
            labels=(cfg.get("label_col") is not None),
            mine_hardneg=bool(cfg.get("hardneg", False)),
            mode=shortlist_mode,
            batch_size=int(cfg.get("batch_size", 100)),
            sample_frac=float(cfg.get("sample_frac", 1.0)),
            only_side_prefix=cfg.get("only_side_prefix"),
        )

    elapsed = time.time() - t0
    notes = f"{cfg.get('task','reuse')} K={cfg['topk']} mode={shortlist_mode} labels={'yes' if cfg.get('label_col') else 'no'}"
    push_run_metrics(es, runs_index, run, cfg.get("task","reuse"), int(cfg["topk"]),
                     total_docs, unchanged_skipped, 0, total_pairs, hardnegs, elapsed, notes)

    # Summary
    print("\n[RUN] Summary")
    print(f"  run_name          : {run}")
    print(f"  data_index        : {data_index} (reused={not cfg.get('create_data_index', False)})")
    print(f"  shortlist mode    : {shortlist_mode}")
    print(f"  docs              : {total_docs}")
    print(f"  unchanged skipped : {unchanged_skipped}")
    print(f"  shortlist pairs   : {total_pairs} (K={cfg['topk']})")
    print(f"  hard negatives    : {hardnegs}")
    print(f"  elapsed (sec)     : {elapsed:.1f}")

    # =======================
    # Kibana: Data Views → Saved Search → Lens → Dashboard
    # =======================
        # =======================
    # Kibana: Data Views → Saved Search → Lens → Dashboard (USP-focused)
    # =======================
    if cfg.get("build_kibana", True):
        runs_title  = cfg.get("runs_index")  or f"fastlane-runs-{run}"
        pairs_title = cfg.get("pairs_index") or f"fastlane-pairs-{run}"

        runs_dv_id  = ensure_data_view(cfg, runs_title,  name=f"dv-{runs_title}",  time_field="ts")
        pairs_dv_id = ensure_data_view(cfg, pairs_title, name=f"dv-{pairs_title}", time_field="ts")
        if not (runs_dv_id and pairs_dv_id):
            print("[Kibana] Skipping dashboard build (data view creation failed).")
        else:
            # Saved searches
            runs_search_id  = create_saved_search(cfg, f"Runs ({run})", runs_dv_id,
                                ["run_name","k","total_docs","shortlist_pairs","hardnegs","elapsed_sec","notes","ts"],
                                sort_field="ts", sort_dir="desc")
            hardneg_search_id = create_saved_search_pairs_hardnegs(cfg, f"Hard negatives ({run})", pairs_dv_id)

            panels = []; refs = []

            # --- Metrics (pairs) ---
            p_tot_pairs, r_tot_pairs = lens_metric_count(pairs_dv_id, label="Total pairs", kql="", grid=(0,0), size=(12,8))
            p_tot_hn,    r_tot_hn    = lens_metric_count(pairs_dv_id, label="Hard negatives", kql="hard_negative: true", grid=(12,0), size=(12,8))
            panels += [p_tot_pairs, p_tot_hn]; refs += [r_tot_pairs, r_tot_hn]

            # --- Share (pie) ---
            p_share, r_share = lens_pie_hardneg_share(pairs_dv_id, field="hard_negative", label="Hard negative share", grid=(24,0), size=(12,16))
            panels.append(p_share); refs.append(r_share)

            # --- Time series (pairs) ---
            p_hn_ts, r_hn_ts = lens_xy_with_kql(pairs_dv_id, y_label="Hard negatives over time",
                                                kql="hard_negative: true", grid=(0,8), size=(24,12))
            panels.append(p_hn_ts); refs.append(r_hn_ts)

            # --- Top confusing queries (pairs) ---
            p_top_q, r_top_q = lens_terms_bar(pairs_dv_id, field="qid", label="Top confusing queries (by hard negatives)",
                                              kql="hard_negative: true", size_terms=10, grid=(24,8), size=(24,12))
            panels.append(p_top_q); refs.append(r_top_q)

            # --- Score distribution (pairs) ---
            p_score_all, r_score_all = lens_score_histogram(pairs_dv_id, kql="", grid=(0,20), size=(24,12))
            p_score_hn,  r_score_hn  = lens_score_histogram(pairs_dv_id, kql="hard_negative: true", grid=(24,20), size=(24,12))
            panels += [p_score_all, p_score_hn]; refs += [r_score_all, r_score_hn]

            # --- Runs overview (keep your existing run-level insights) ---
            p_runs_count, r_runs_count = lens_xy_count_over_time(runs_dv_id, panel_w=24, panel_h=12, grid_x=0, grid_y=32)
            p_runs_p95,   r_runs_p95   = lens_xy_metric_over_time(runs_dv_id, field="elapsed_sec",
                                                                  label="p95 elapsed_sec", op="percentile", percentile=95,
                                                                  panel_w=24, panel_h=12, grid_x=24, grid_y=32)
            panels += [p_runs_count, p_runs_p95]; refs += [r_runs_count, r_runs_p95]

            # --- Tables ---
            if runs_search_id:
                runs_table_id = str(uuid.uuid4())
                panels.append({
                    "type": "search",
                    "gridData": {"x": 0, "y": 44, "w": 24, "h": 14, "i": runs_table_id},
                    "panelIndex": runs_table_id, "embeddableConfig": {},
                    "id": runs_search_id, "version": "8.0.0", "panelRefName": "panel_runs_table"
                })
                refs.append({"name":"panel_runs_table","type":"search","id":runs_search_id})

            if hardneg_search_id:
                hn_table_id = str(uuid.uuid4())
                panels.append({
                    "type": "search",
                    "gridData": {"x": 24, "y": 44, "w": 24, "h": 14, "i": hn_table_id},
                    "panelIndex": hn_table_id, "embeddableConfig": {},
                    "id": hardneg_search_id, "version": "8.0.0", "panelRefName": "panel_hn_table"
                })
                refs.append({"name":"panel_hn_table","type":"search","id":hardneg_search_id})

            dash_id = create_dashboard_with_panels(cfg, f"Fastlane USP ({run})", panels, refs,
                                                   time_from="now-24h", time_to="now")
            if dash_id:
                print("\n[Kibana] USP Dashboard created:")
                print(f"  {cfg['kibana_url'].rstrip('/')}/app/dashboards#/view/{dash_id}")
            else:
                print("[Kibana] Dashboard creation failed.")

    print(f"\nOpen Kibana Discover:\n  {cfg['kibana_url'].rstrip('/')}/app/discover\n")

if __name__ == "__main__":
    # ENV overrides for convenience
    if os.getenv("CLOUD_ID"): CONFIG["cloud_id"] = os.getenv("CLOUD_ID")
    if os.getenv("ES_ENDPOINT"): CONFIG["es_endpoint"] = os.getenv("ES_ENDPOINT")
    if os.getenv("ES_USER"): CONFIG["es_user"] = os.getenv("ES_USER")
    if os.getenv("ES_PASS"): CONFIG["es_pass"] = os.getenv("ES_PASS")
    if os.getenv("KIBANA_URL"): CONFIG["kibana_url"] = os.getenv("KIBANA_URL")
    if os.getenv("KIBANA_USER"): CONFIG["kibana_user"] = os.getenv("KIBANA_USER")
    if os.getenv("KIBANA_PASS"): CONFIG["kibana_pass"] = os.getenv("KIBANA_PASS")
    if os.getenv("REQUESTS_VERIFY"):
        rv = os.getenv("REQUESTS_VERIFY")
        CONFIG["requests_verify"] = False if rv.lower() in ("0","false","no") else (rv if rv.lower() not in ("1","true","yes") else True)
    if os.getenv("KIBANA_SPACE"): CONFIG["kibana_space"] = os.getenv("KIBANA_SPACE").strip()

    main(CONFIG)
