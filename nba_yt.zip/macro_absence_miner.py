import pandas as pd
import numpy as np

def run_macro_and_absence():
    print("Loading Team and Player data...")
    try:
        players = pd.read_csv('data/nba_player_logs_2012_2026.csv', low_memory=False)
        teams = pd.read_csv('data/nba_team_logs_2012_2026.csv', low_memory=False)
        stocks = pd.read_csv('data/sp500_stock_data_2012_2026.csv', low_memory=False)
    except Exception as e:
        print(f"Error loading data: {e}")
        return

    players['GAME_DATE'] = pd.to_datetime(players['GAME_DATE']).dt.tz_localize(None)
    teams['GAME_DATE'] = pd.to_datetime(teams['GAME_DATE']).dt.tz_localize(None)
    stocks['Date'] = pd.to_datetime(stocks['Date']).dt.tz_localize(None)
    
    stocks.sort_values(by=['Ticker', 'Date'], inplace=True)
    stocks['Pct_Change'] = stocks.groupby('Ticker')['Close'].pct_change() * 100
    stocks['Went_Up'] = stocks['Pct_Change'] > 0
    stocks['Went_Down'] = stocks['Pct_Change'] < 0

    famous_tickers = {
        'TSLA': 'Tesla', 'AAPL': 'Apple', 'MSFT': 'Microsoft', 'AMZN': 'Amazon',
        'META': 'Meta', 'JPM': 'JPMorgan', 'BAC': 'Bank of America', 'GS': 'Goldman Sachs'
    }
    
    # We will check against ALL stocks to find the best macro connections
    all_tickers = stocks['Ticker'].unique()
    stock_groups = stocks.groupby('Ticker')

    stock_dates = sorted(stocks['Date'].unique())
    stock_date_df = pd.DataFrame({'Stock_Date': stock_dates})
    
    def get_next_trading_day(game_date):
        future = stock_date_df[stock_date_df['Stock_Date'] > game_date]
        if not future.empty:
            return future.iloc[0]['Stock_Date']
        return pd.NaT

    teams['Next_Trading_Date'] = teams['GAME_DATE'].apply(get_next_trading_day)
    
    events = []
    print("Extracting Macro Team Events...")
    
    # Process Team Macro (GSW and NYK)
    teams.sort_values(by=['TEAM_ABBREVIATION', 'GAME_DATE'], inplace=True)
    
    for team_abbr, group in teams.groupby('TEAM_ABBREVIATION'):
        if team_abbr not in ['GSW', 'NYK']: continue
        
        win_streak = 0
        for _, row in group.iterrows():
            date = row['Next_Trading_Date']
            if pd.isna(date): continue
            
            # GSW Logic
            if team_abbr == 'GSW':
                if row['WL'] == 'W':
                    win_streak += 1
                    if win_streak >= 5:
                        events.append({'Date': date, 'Event': "Warriors on a 5+ Game Winning Streak"})
                    if pd.notna(row['PLUS_MINUS']) and row['PLUS_MINUS'] >= 25:
                        events.append({'Date': date, 'Event': "Warriors win by 25+ Points"})
                else:
                    win_streak = 0
            
            # NYK Logic
            if team_abbr == 'NYK':
                if pd.notna(row['PLUS_MINUS']) and row['PLUS_MINUS'] <= -25:
                    events.append({'Date': date, 'Event': "Knicks get blown out by 25+ Points"})

    print("Extracting Player Absence Events...")
    
    superstars = ["LeBron James", "Stephen Curry", "Kevin Durant", "Victor Wembanyama"]
    
    for player_name in superstars:
        player_df = players[players['PLAYER_NAME'] == player_name]
        if player_df.empty: continue
        
        player_played_game_ids = set(player_df['GAME_ID'])
        
        # Get every team the player has played for
        for team_id in player_df['TEAM_ID'].unique():
            team_stints = player_df[player_df['TEAM_ID'] == team_id]
            min_date = team_stints['GAME_DATE'].min()
            max_date = team_stints['GAME_DATE'].max()
            
            # All games this team played during the player's tenure
            team_games = teams[(teams['TEAM_ID'] == team_id) & (teams['GAME_DATE'] >= min_date) & (teams['GAME_DATE'] <= max_date)]
            
            for _, team_row in team_games.iterrows():
                if team_row['GAME_ID'] not in player_played_game_ids:
                    date = team_row['Next_Trading_Date']
                    if pd.notna(date):
                        events.append({'Date': date, 'Event': f"{player_name} MISSES the game (Load Management / Injury)"})

    events_df = pd.DataFrame(events).drop_duplicates()
    
    results = []
    print("Cross-referencing events against stock market (14-Year and 25-26 Blind Test)...")
    
    for event_name in events_df['Event'].unique():
        event_dates = events_df[events_df['Event'] == event_name]['Date']
        
        for ticker in all_tickers:
            try:
                stock_slice = stock_groups.get_group(ticker)
                event_stock_slice = stock_slice[stock_slice['Date'].isin(event_dates)]
                if len(event_stock_slice) == 0: continue
                
                # 14 Year Calculation
                up_days_14 = event_stock_slice['Went_Up'].sum()
                down_days_14 = event_stock_slice['Went_Down'].sum()
                total_14 = len(event_stock_slice)
                
                if total_14 < 15: continue # Need decent sample size for absence/streaks
                
                up_pct_14 = (up_days_14 / total_14) * 100
                down_pct_14 = (down_days_14 / total_14) * 100
                
                target = "UP" if up_pct_14 > down_pct_14 else "DOWN"
                acc_14 = max(up_pct_14, down_pct_14)
                
                # 25-26 Backtest Calculation
                stock_slice_2526 = event_stock_slice[event_stock_slice['Date'] >= '2025-10-01']
                total_26 = len(stock_slice_2526)
                
                acc_26 = 0
                if total_26 > 0:
                    if target == "UP":
                        acc_26 = (stock_slice_2526['Went_Up'].sum() / total_26) * 100
                    else:
                        acc_26 = (stock_slice_2526['Went_Down'].sum() / total_26) * 100

                # Look for high accuracy macro correlations
                if acc_14 >= 62:
                    company_name = famous_tickers.get(ticker, ticker) # Use famous name if exists, else ticker
                    results.append({
                        'Pattern': f"Whenever {event_name}, {company_name} stock GOES {target}!",
                        '14_Year_Accuracy': f"{acc_14:.1f}%",
                        '14_Year_N': total_14,
                        '25_26_Accuracy': f"{acc_26:.1f}%" if total_26 > 0 else "N/A",
                        '25_26_N': total_26
                    })
            except KeyError:
                continue

    res_df = pd.DataFrame(results)
    if not res_df.empty:
        res_df.sort_values(by=['14_Year_N', '14_Year_Accuracy'], ascending=[False, False], inplace=True)
        res_df.to_csv('data/macro_absence_patterns.csv', index=False)
        print("\n=== MACRO AND ABSENCE RESULTS ===\n")
        print(res_df.head(40).to_string())
    else:
        print("No patterns met the threshold.")

if __name__ == "__main__":
    run_macro_and_absence()
