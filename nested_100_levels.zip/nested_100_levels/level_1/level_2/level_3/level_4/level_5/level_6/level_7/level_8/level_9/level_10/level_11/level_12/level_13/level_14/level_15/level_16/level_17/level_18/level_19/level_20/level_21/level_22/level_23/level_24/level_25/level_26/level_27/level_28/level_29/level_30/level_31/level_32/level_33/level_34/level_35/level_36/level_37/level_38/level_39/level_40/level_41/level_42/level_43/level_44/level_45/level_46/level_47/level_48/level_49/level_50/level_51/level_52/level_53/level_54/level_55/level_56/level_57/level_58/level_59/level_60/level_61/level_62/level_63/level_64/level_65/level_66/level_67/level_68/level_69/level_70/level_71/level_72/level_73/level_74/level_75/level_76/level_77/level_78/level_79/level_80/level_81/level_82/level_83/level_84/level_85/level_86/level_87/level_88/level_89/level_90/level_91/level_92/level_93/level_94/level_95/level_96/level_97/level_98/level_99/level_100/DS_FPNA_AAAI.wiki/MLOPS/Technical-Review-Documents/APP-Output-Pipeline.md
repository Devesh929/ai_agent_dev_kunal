[[_TOC_]]
# Output Table Schema and Logic
## Residual Table
### Schema
| Column Name | Data Type |
| --- | --- |
| forecast_date | datetime |
| forecast_value | float |
| actuals | float |
| mgmt | string |
| kpi | string |
| forecast_type | string |
| run_date | datetime |
| train_data_month_year | integer |
| model_version | string |
| model_type | string |
| residuals | float |
### Input Files Required
- Forecasting Pipeline Output
- Latest Raw Data
### Transformation Logic
- Filter for latest run date.
- Convert run date and forecast date to datetime.
- Drop BA and Prediction Window Columns.
- For mgmt, forecast_type groups if "base_orders_net" is not present populate the KPI with "orders_recieved_net" values.
- Pick latest raw_data and update the actuals and residuals in the residual table.
- Convert the values (*(-1)) from raw table for these KPIs : 'operational_cost_of_sales_net', 'operational_nonorder_related_rd_expenses_net', 'operational_sga_expenses_net'.
- Residual table will be updated for all the combinations present in the pipeline output data.
- Historic validation & Test data is available for ST & LT with the run date of "2025-07-01".
- For Val and Test Train Month Year column will represent the training data month and year which is considered for the validation / testing.
## Calculated KPI Table
### Schema
| Column Name | Data Type |
| --- | --- |
| forecast_date | datetime |
| forecast_value | float |
| actuals | float |
| mgmt | string |
| kpi | string |
| forecast_type | string |
| run_date | datetime |
| train_data_month_year | integer |
| model_version | string |
| model_type | string |
| residuals | float |
### Input Files Required
- Forecasting Pipeline Output
- Latest Raw Data
### Transformation Logic
- This table will only be updated with calculated values of 'operational_cost_of_sales_net', 'operational_revenues_gross_profit_net' for ST forecast type.
- for each mgmt under ST, the values will be calculated as : GP = Revenue - COS ; COS = Revenue - GP.
- Pick latest raw_data and update the actuals and residuals.
- Convert the values (*(-1)) from raw table for these KPIs : 'operational_cost_of_sales_net', 'operational_nonorder_related_rd_expenses_net', 'operational_sga_expenses_net'.
## Calculated BA Table
### Schema
| Column Name | Data Type |
| --- | --- |
| forecast_date | datetime |
| forecast_value | float |
| actuals | float |
| mgmt | string |
| kpi | string |
| forecast_type | string |
| run_date | datetime |
| train_data_month_year | integer |
| model_version | string |
| model_type | string |
| residuals | float |
### Input Files Required
- residual_data
- cons_consolidated
- calculated_kpi_data
- division_kpi_mapping
- Latest Raw Data
### Transformation Logic
- BA table has LT & ST values for : EL, MO and IA.
- LT Values are directly fetched from residual table as the forecast is available at BA level.
- ST values are created by adding CONS to every BA-KPI combination.
- For KPIs ('operational_cost_of_sales_net' & 'operational_revenues_gross_profit_net') we check the division KPI mapping to confirm the "Calculated/ Forecasted" tag of the KPI. The KPI with 'Forecated' tag will get the values from residual table while the KPI with 'Calculated' tag will get the values from Calculated KPI table.
- New actuals are fetched from raw_data at BA level.
## Intermediate Quarter Table
### Schema
| Column Name | Data Type |
| --- | --- |
| mgmt | string |
| kpi | string |
| quarter | string |
| run_date | datetime |
| train_month_date | integer |
| forecast_type | string |
| forecast_value | float |
| actuals | float |
| residuals | float |
| forecast_version | string |
| forecast_KPIS_tag | string |
| model_version | string |
### Input Files Required
- residual_data
- calculated_ba_data
- latest raw data
- calculated_kpi_data
- business_rolling_forecast
### Transformation Logic
- This table will have values from residual table and ST BA level data from Calculated BA table.
**Quarter Sum Logic (KPIS tag: forecast)**
- Unique *forecasted* values will be present for mgmt, kpi, forecast_type, run_date and quarter combination.
- Remove forecasted values for KPIs: 'operational_nonorder_related_rd_expenses_net' & 'operational_sga_expenses_net' for ST forecast_type as these values will be ingested from business RF table.
- Forecast Version is defined as : <quarter> RF<training_data_month + 1>, where both the dates are in YYMM format.
- For run_date months of 1, 4, 7 and 10 forecast version will be updated with xxxx RFxx12, xxxx RFxx03, xxxx RFxx06 and xxxx RFxx09 respectively.  <br>Note: Due to this, forecast version does not always represent quarter + run_date.
- For quarters where forecast is starting mid quarter: we take the actual data for the missing months to create the quarter forecast.
- For quarters where forecast is ending mid quarter: we discard the extra months.
- All the forecasted values will be marked with KPIS tag: "forecast".
**Calculated Values (KPIS tag: Calculated)**
- For KPIs: 'operational_cost_of_sales_net' & 'operational_revenues_gross_profit_net', we will use Calculated / Forecasted values depending on the tags available in Division KPI mapping Sheet.
- For ST, these KPIs re Calculated:  <br>operational_ebita = operational_revenues_gross_profit_net (tags: forecast/calculated) - operational_nonorder_related_rd_expenses_net (tags: RF) - operational_sga_expenses_net (tags: RF)  <br>operational_ebita_% = (operational_ebita (tags: Calculated) / revenues_net (tags: forecast)) * 100  <br>operational_revenues_gross_margin_net_% = (operational_revenues_gross_profit_net (tags: forecast/calculated) / revenues_net (tags: forecast)) * 100
**orders_received_net (Base Orders Fc + Biz RF) (KPIS tag: forecasted + RF)**
- This KPI is calculated for both ST and LT.
- orders_received_net (Base Orders Fc + Biz RF) = base_orders_net (KPIS tag: forecast) + large_orders (from RF table)
**RF Values (KPIS tag: RF)**
- Get all the RF values available in the RF table for the following KPIs: <br>'operational_nonorder_related_rd_expenses_net'  <br>'operational_sga_expenses_net'  <br>'base_orders_net'  <br>'orders_received_net'  <br>'revenues_net'  <br>'operational_cost_of_sales_net'  <br>'operational_revenues_gross_profit_net'  <br>Note: we will follow the version naming convention at each run to fetch the latest RF values.
## Quarter Table
### Schema
| Column Name | Data Type |
| --- | --- |
| mgmt | string |
| kpi | string |
| quarter | string |
| run_date | datetime |
| train_month_date | integer |
| forecast_type | string |
| forecast_value | float |
| actuals | float |
| residuals | float |
| forecast_version | string |
| forecast_KPIS_tag | string |
| model_version | string |
| confidence_interval | string |
| lower_bound | float |
| upper_bound | float |
### Input Files Required
- distribution_output
- quarter_data
### Transformation Logic
- This extension adds three more columns: confidence interval, upper bound and lower bound to the intermediate quarter table. These values are fetched from distribution table.
- ST distribution values are available at quarter level, so for all the mgmt, kpi, forecast_version combination available in distribution the rows will be duplicated into 3 rows corresponding to 1-sigma, 2-sigma and 3-sigma.
- All the confidence interval values corresponding to KPI "orders_received_net (Base Orders Fc + Biz RF)" will be changed to "NA".
- KPIS tag "forecast" is renamed to "ML Forecast" for business reporting.
- KPIS tag "RF" is renamed to "Biz RF" for business reporting.
- quarter format is changed from "Qx YYMM" to "YYMM Qx" for business reporting.
**LT Distribution Rows (KPIS tag: prediction_total)**
- LT distribution values are calculated at annual level, so we append these directly as new rows to the intermediate quarter table.
- quarter: Q_Annual, forecast_type: Calculated, KPIS tag: prediction_total.
- Three LT rows would be added for each mgmt, kpi and forecast_version combination corresponding to 1-sigma, 2-sigma and 3-sigma confidence interval.