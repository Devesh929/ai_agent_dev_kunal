#Configuration Explanation


This document explains the various parameters used in the forecasting and analysis pipeline, likely for a machine learning or data science project. These parameters define file paths, sheet names within data assets, date ranges for predictions, and thresholds for analysis.

### General Experiment Settings

*   `"experiment_name"`
    *   **Purpose**: A unique identifier for the current experiment run. This is often used for organizing output files (e.g., plots, reports) into a dedicated folder.
        
*   `"modelling_level_list"`
    *   **Purpose**: Specifies the granular level(s) at which the modelling and analysis are performed. This typically indicates a specific business, division, or country and the target variable being forecasted.
        
*   `"models"`
    *   **Purpose**: A list of forecasting models that are part of the multivariate experiment. These are the models whose performance and components will be analyzed.
        
*   `"models_stl"`
    *   **Purpose**: A list of models for which STL (Seasonal-Trend Decomposition using Loess) features are generated and potentially plotted. This might be a subset or a different set of models compared to the general "models" list.
        
*   `"main_results_folder"`
    *   **Purpose**: The primary directory where all results, plots, and generated artifacts from the post-modelling analysis will be stored.
        
*   `"data_asset_path"`
    *   **Purpose**: The base path or identifier for the main data asset (e.g., a blob storage path, a database table name, or a local directory) where all input data files are located.
        
*   `"data_asset_label"`
    *   **Purpose**: A label or version indicator for the data asset, ensuring that the correct data version is used for the experiment.
        

### Data Sheet Names

These parameters specify the names of individual sheets or files within the main data asset that contain specific types of data.
*   `"features_used_sheet"`
    *   **Purpose**: The sheet containing information about the features used in the models.
        
*   `"val_sheet"`
    *   **Purpose**: The sheet containing validation period predictions alongside actual values. The `_m` suffix often indicates monthly granularity.
        
*   `"test_sheet"`
    *   **Purpose**: The sheet containing test period predictions alongside actual values.
        
*   `"future_forecast"`
    *   **Purpose**: The sheet containing future period forecasts.
        
*   `"full_trend_sheet"`
    *   **Purpose**: The sheet containing trend and seasonality components for the full historical data.
        
*   `"train_trend_sheet"`
    *   **Purpose**: The sheet containing trend and seasonality components for the training data.
        
*   `"val_trend_sheet"`
    *   **Purpose**: The sheet containing trend and seasonality components for the validation forecast period.
        
*   `"test_trend_sheet"`
    *   **Purpose**: The sheet containing trend and seasonality components for the test forecast period.
        
*   `"future_trend_sheet"`
    *   **Purpose**: The sheet containing trend and seasonality components for the future forecast period.
        
*   `"shapely_values_sheet"`
    *   **Purpose**: The sheet containing SHAP (SHapley Additive exPlanations) values for the full historical data, used for model interpretability.
        
*   `"shapely_values_future_sheet"`
    *   **Purpose**: The sheet containing SHAP values for the future forecast data.
        
*   `"importance_values_sheet"`
    *   **Purpose**: The sheet containing global feature importance scores, often derived from SHAP values or model coefficients.
        
*   `"base_value_sheet"`
    *   **Purpose**: The sheet containing the "expected value" or base value for SHAP explanations, representing the average model output.
        
*   `"prophet_coefficients_sheet"`
    *   **Purpose**: The sheet specifically storing the coefficients of regressors used in Prophet models.
        
*   `"prophet_components_sheet"`
    *   **Purpose**: The sheet storing the decomposed components (trend, seasonality, regressors) from Prophet models.
        
*   `"x_full_data_sheet"`
    *   **Purpose**: The sheet containing features for the full historical dataset.
        
*   `"y_full_data_sheet"`
    *   **Purpose**: The sheet containing target variable values for the full historical dataset.
        
*   `"x_future_forecast_sheet"`
    *   **Purpose**: The sheet containing features for the future forecast period.
        
*   `"x_val1_forecast_sheet"`
    *   **Purpose**: Features for the first validation forecast period. (The presence of `val1` to `val4` suggests multiple validation periods or a rolling validation setup).
        
*   `"x_val2_forecast_sheet"`
    *   **Purpose**: Features for the second validation forecast period.
        
*   `"x_val3_forecast_sheet"`
    *   **Purpose**: Features for the third validation forecast period.
        
*   `"x_val4_forecast_sheet"`
    *   **Purpose**: Features for the fourth validation forecast period.
        
*   `"x_test_forecast_sheet"`
    *   **Purpose**: Features for the test forecast period.
        

### Date Ranges and Thresholds

*   `"pred_start"`
    *   **Purpose**: The start date for the prediction period, used for filtering data for analysis and plotting.
        
*   `"pred_end"`
    *   **Purpose**: The end date for the prediction period.
        
*   `"future_start"`
    *   **Purpose**: The start date for the future forecast period.
        
*   `"future_end"`
    *   **Purpose**: The end date for the future forecast period.
        
*   `"univariate_experiment_name"`
    *   **Purpose**: A separate experiment name specifically for univariate analysis, if applicable.
        
*   `"growth_threshold_pct"`
    *   **Purpose**: A percentage threshold. Changes in metrics (e.g., mean, variance) above this value are flagged as "Significant Growth".
        
*   `"decline_threshold_pct"`
    *   **Purpose**: A percentage threshold. Changes in metrics below this value are flagged as "Significant Decline".
        
*   `"top_n_features"`
    *   **Purpose**: Specifies the number of top features to display in plots related to feature importance or contributions.
        

### Blob Storage Details

*   `"blob_storage_account_url"`
    *   **Purpose**: The URL of the Azure Blob Storage account where data assets are stored.
        
*   `"blob_container_name"`
    *   **Purpose**: The name of the container within the Blob Storage account where the relevant data resides.