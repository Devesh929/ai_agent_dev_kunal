## Objective
The objective here is to set up Prometheus for monitoring the experiments in an AKS cluster

---

## Pre-requisites
- Azure monitor workspace
- Grafana Workspace
- Log Analytics Workspace

---

## Steps

`#`Since, Prometheus is a single-tenant metrics monitoring tool we need to set it up for each kubernetes cluster and also because Azure offers a **Managed Prometheus** option we can easily integrate it with the aks service.

1. Go to your AKS Cluster and select the **Monitor** option in the left-side menu.
2. There select the **Monito Setting** option on the top.
3. On the right side-window that opens up select **Advance settings**.
4. Select the Azure Monitor Workspace that you had created.
5. Select the Grafana workspace.
6. Select the Log Analytic Workspace.
7. In the Logs presents option, select the **Syslog**, if you want to send all the data. Or whatever is your requirement.
8. Click **Configure**. and you are all set.

---

_For making a connection to grafana follow the grafana runbook_