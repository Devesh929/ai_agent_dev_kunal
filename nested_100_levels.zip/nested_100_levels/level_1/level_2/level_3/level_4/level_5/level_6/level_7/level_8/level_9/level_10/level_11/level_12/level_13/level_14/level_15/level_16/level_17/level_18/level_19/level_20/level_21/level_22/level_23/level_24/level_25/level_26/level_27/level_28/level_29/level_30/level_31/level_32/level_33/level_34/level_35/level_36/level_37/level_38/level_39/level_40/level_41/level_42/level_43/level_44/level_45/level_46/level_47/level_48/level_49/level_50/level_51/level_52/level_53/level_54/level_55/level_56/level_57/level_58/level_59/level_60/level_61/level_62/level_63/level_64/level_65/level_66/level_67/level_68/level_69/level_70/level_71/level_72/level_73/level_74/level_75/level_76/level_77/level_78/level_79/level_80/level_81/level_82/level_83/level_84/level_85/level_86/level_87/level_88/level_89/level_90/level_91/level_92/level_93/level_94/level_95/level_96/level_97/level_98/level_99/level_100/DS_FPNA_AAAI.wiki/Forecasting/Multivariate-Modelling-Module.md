This module implements an **Azure Machine Learning pipeline** for **multivariate time series forecasting with cross-validation, feature engineering, hyperparameter tuning, and consolidation of results**.

The pipeline automates the following stages of forecasting:
1.  **Data Preparation** – Filters, groups and structures the data for forecasting.
2.  **Splitting** – Parallelizes processing across modelling levels and targets.
3.  **Model Training** – Runs hyperparameter tuning using Optuna for multiple models (tree-based, linear, and Prophet/SARIMA).
4.  **Consolidation** – Aggregates results from all trained models.
5.  **Deployment Ready Outputs** – Stores prepared datasets, models objects, and forecast results in Azure ML data assets.

# **Code Files**

1. **app_pipeline.py** : **Entry point** to submit the pipeline. It defines a **DSL pipeline** (`submit_job`) with the following stages - prepare_data, spilt_data, hypertunning and consolidate. It uses Uses **Azure ML SDK v2** to create and submit jobs.

2. **azure_utility.py** : Defines reusable **Azure ML job templates**. It contains template for all the above stages.

3. **multivariate_cv.py** : It contains the main code of this pipeline. It has code written for all the above stages which is being called for each group.

4. **multivariate_cv_wrapper.py** : Filters by **date ranges** and **modelling levels**. Aggregates and saves per-combination datasets based on modelling levels and prepares inputs for `split_data` jobs which will run parallely for each combination and splits data into training, validation and test set.

5. **models.py** : Defines **abstract base classes** and model implementations for SARIMA, Prophet, RandomForest, XGBoost, LightGBM, ExtraTrees, Linear Regression. Each of these classes implements functions like retrain, predict, predict_with_lags etc.

# **Flow of Code**

This code is capable of running whole forecasting process on multiple KPIs and multiple groups/sub-groups at once in parallel. We can define these KPIs and Groups in config. Lets say we have to forecast Orders and Revenues for 2 divisions of EL. And lets say we are running 3 models - Prophet, XGBoost and LR only. Here target is orders, revenues. Groups are ELDS and ELSE. We will have total 4 unique time series. ELDS orders and revenues and ELSE orders and revenues. And these 4 combinations will run 3 times each because we have 3 unique models. Hence we will have 12 parallel jobs running together. This flow chart below explains all the stages for this example :

::: mermaid
graph TD
    A[All Input Data & Config] --> B[prepare_data_job]
    B --> C[split_data_job for ELDS_orders]
    B --> G[split_data_job for ELDS_revenues]
    B --> H[split_data_job for ELSE_orders]
    B --> I[split_data_job for ELSE_revenues]
    C --> D[hypertunning_job for ELDS_orders_prophet]
    C --> J[hypertunning_job for ELDS_orders_xgboost]
    C --> K[hypertunning_job for ELDS_orders_lightgbm]

    D --> E[consolidation_job]
    J --> E
    K --> E
    E --> F[Final Results & Outputs]
:::


# **Config File**

The pipeline is fully controlled by a **JSON config file** : 

```
{
  "experiment_name": "loss_function_experiment_2",
  "config_asset": "./default_config_multivariate.json",
  "data_asset": "./inputs/treated_data_with_lags_2506.xlsx",
  "manual_features_for_modelling_asset": "./inputs/el_selected_for_modelling.xlsx",
  "prophet_trend_seasonal_experiment_name": "multivariate_elsb_revenues_3months_1",
  "internal_feature_forecast": "./inputs/elsp_revenues_feature_forecast_1.xlsx",
  "external_feature_forecast": "./inputs/univariate_el_external_3months_full.xlsx",
  "output_asset": "el_app_2025_07_output",
  "output_asset_version": "1",
  "target_columns": ["orders_received_net"],
  "all_internal_features": ["base_orders_3rd_part_lag12"],
  "generatable_categorical_features": [
    "QUARTER_Q1","QUARTER_Q2","QUARTER_Q3","QUARTER_Q4","HALF_H1","HALF_H2",
    "MONTH_M1","MONTH_M2","MONTH_M3","MONTH_M4","MONTH_M5","MONTH_M6","MONTH_M7","MONTH_M8","MONTH_M9",
    "MONTH_M10", "MONTH_M11","MONTH_M12","QUARTER_END","QUARTER_START","YEAR_END_START"],
  "fourier_features": [
    "FOURIER_SINE_1","FOURIER_COSINE_1",
    "FOURIER_SINE_2","FOURIER_COSINE_2",
    "FOURIER_SINE_3","FOURIER_COSINE_3"],
  "stl_features": [],
  "lag_features": [],
  "shap_importance_filter_experiment": "multivariate_elsp_orders_3months_12",
  "use_shap_importance_filter": true,
  "compute_cluster": "cc-dev-forecasting-extvars",
  "forecast_interval_params": {
    "n_bootstraps": 100,
    "confidence_interval": 0.9
  },
  "modelling_levels": ["modelling_level"],
  "filters_on_modelling_level": {
    "modelling_level": ["ELSP"]
  },
  "filters_on_date": {
    "from": "2021-01-01",
    "to": "2025-06-01"
  },
  "n_folds": 4,
  "per_fold_duration": 3,
  "test": { "from": "2025-04-01", "to": "2025-06-01" },
  "forecast": { "from": "2025-07-01", "to": "2025-09-01" },
  "date_column": "date",
  "models_to_run":["sarima_multivariate", "randomforest_multivariate", "xgboosttree_multivariate", 
     "xgboostlinear_multivariate", "lightgbm_multivariate", "prophet_multivariate", 
     "extratree_multivariate", "linearregression_multivariate"],
  "sarima_multivariate":{
        "p":[0,10],
        "d":[0,2],
        "q":[0,10],
        "P":[0,10],
        "D":[0,2],
        "Q":[0,10],
        "s":["3", "6", "12"],
        "optuna_n_trials":200
    },
  "randomforest_multivariate":{
        "n_estimators": [5, 200],
        "max_depth": [2, 20],
        "min_samples_split": [2, 10],
        "min_samples_leaf":[2, 10],
        "max_features": [0.5, 1],
        "criterion":["friedman_mse", "absolute_error", "poisson", "squared_error"],
        "ccp_alpha":[0,5],
        "optuna_n_trials":200
    },
  "decisiontree_multivariate":{
        "max_depth":[2,20],
        "criterion":["friedman_mse", "absolute_error", "poisson", "squared_error"],
        "min_samples_split":[2,10],
        "min_samples_leaf":[1,3],
        "max_features":[0.5,1],
        "min_impurity_decrease":[0,5],
        "optuna_n_trials":200
    },
  "xgboosttree_multivariate": {
        "n_estimators": [5, 200],
        "max_depth": [2, 30],
        "learning_rate": [0.001, 0.2],
        "colsample_bytree": [0.2, 1.0],
        "min_child_weight":[1, 20],
        "lambda":[1, 20],
        "optuna_n_trials":1000
    },
  "xgboostlinear_multivariate": {
        "learning_rate": [0.01, 0.2],            
        "lambda": [0.01, 10.0],                       
        "alpha": [0.01, 10.0],                       
        "tree_method": ["approx", "auto", "exact", "gpu_hist", "hist"],  
        "feature_selector": ["cyclic", "shuffle"],
        "updater":["coord_descent","shotgun"],
        "optuna_n_trials": 1000
    },
   "svr_grid": {
        "kernel": ["linear", "rbf", "poly", "sigmoid"],
        "C": [1e-3, 1e3],
        "epsilon": [1e-3, 1e-1], 
        "gamma": [0,1],
        "max_iter": [5,20],
        "degree":[2,10],
        "optuna_n_trials":200
    },
  "prophet_multivariate": {
        "seasonality_mode": ["additive"],
        "changepoint_prior_scale": [0.001,2],
        "seasonality_prior_scale": [0.001, 10],
        "holidays_prior_scale": [0.001, 10],
        "growth":["linear", "logistic"],
        "n_changepoints": [5,50],
        "yearly_seasonality": [true],
        "uncertainty_samples": [100,200],
        "changepoint_range": [0.5, 0.95],
        "extra_seasonalities": [
            {
            "name": "yearly",  
            "period": 12,
            "fourier_orders": [3,10]
            },
            {
            "name": "quarterly",
            "period": 3,
            "fourier_orders": [3,10]
            }
        ],
        "optuna_n_trials":200
    },
  "extratree_multivariate": {
        "n_estimators": [5, 200],
        "max_depth": [2, 30],
        "min_samples_split": [2, 10],
        "min_samples_leaf": [1, 10],
        "max_features": [0.2, 1.0],
        "criterion": ["squared_error", "absolute_error", "friedman_mse", "poisson"],
        "ccp_alpha": [0.01, 5.0],
        "optuna_n_trials": 200
    },
  "lightgbm_multivariate": {
        "n_estimators": [5, 200],
        "num_leaves": [15, 255],
        "max_depth": [2, 30],
        "learning_rate": [0.001, 0.2],
        "min_child_samples": [5, 50],
        "min_split_gain": [0.000001, 1.0],
        "subsample": [0.2, 1.0],
        "colsample_bytree": [0.2, 1.0],
        "reg_alpha": [0.01, 10.0],
        "reg_lambda": [0.01, 10.0],
        "boosting_type": ["gbdt", "dart", "goss"],
        "optuna_n_trials": 1000
    },
  "linearregression_multivariate":{
        "optuna_n_trials": 1
    }

```

| **Field** | **Type** | **Description** |
| --- | --- | --- |
| `experiment_name` | str | Name of the experiment in Azure ML (shown in ML Studio). |
| `config_asset` | path | Path to the main config file relative to app_pipeline (self-reference) |
| `data_asset` | path | Input data file (xlsx file with time series data). |
| `manual_features_for_modelling_asset` | path | Path to manually selected features for training. |
| `compute_cluster` | str | Azure ML compute cluster to run jobs on (e.g., `"cc-dev-forecasting-extvars"`). |
| `prophet_trend_seasonal_experiment_name` | str | Previous experiment name to read TREND, SEASONALITY from Prophet decomposition. |
| `internal_feature_forecast` | path | Forecasted values of internal features. |
| `external_feature_forecast` | path | Forecasted values of external features. |
| `target_columns` | list | List of target KPIs to forecast (e.g., `["orders_received_net"]`). |
| `modelling_levels` | list | Columns used to group data for modelling (e.g., `"modelling_level", "country"`). |
| `filters_on_modelling_level` | dict | Filters to restrict modelling_level columns to specific values (e.g., `{ "modelling_level": ["ELDS", "ELSE"] }`). |
| `filters_on_date` | dict | Date filters: `from`, `to` (filters whole data on this period first). |
| `date_column` | str | Column name of the date field in input data (e.g., `"date"`). |
| `all_internal_features` | list | List of all internal features to be used in modelling (to be included if available). |
| `generatable_categorical_features` | list | Time-based categorical flags (e.g., `["QUARTER_Q1", "MONTH_M1", "HALF_H1"]`) |
| `fourier_features` | list | Fourier seasonal features (sine/cosine) for capturing periodicity. |
| `stl_features` | list | Features from Prophet Model Decomposition of previous run (e.g., `"TREND"` and `"SEASONALITY"`). |
| `lag_features` | list | Target lags which can be used in modelling (e.g., `LAG_1`) |
| `n_folds` | int | Number of validation folds for time-series cross-validation. |
| `per_fold_duration` | int | Duration of each validation fold (in months). |
| `test` | dict | Defines testing (blind) period on which the forecast will be evaluated. |
| `forecast` | dict | Defines future forecast period: `from`, `to`. |
| `forecast_interval_params` | dict | Parameters for bootstrapped forecast confidence intervals: `n_bootstraps`=number of resamples and `confidence_interval` = e.g., `0.9` for 90% CI |
| `models_to_run` | list | Models to train (e.g., `"randomforest_multivariate"`, `"xgboosttree_multivariate"`). |
| `use_shap_importance_filter` | bool | Whether to filter features based on SHAP importance. If true it will remove features with zero feature importance based on previous experiment defined in this field `shap_importance_filter_experiment` |
| `shap_importance_filter_experiment` | str | Experiment name to infer feature importance for `use_shap_importance_filter` field. Its not required if `use_shap_importance_filter` is `false` |
| `residual_modelling` | bool | If `true`, train a secondary model on residuals of base model. |
| `for_feature_forecast` | bool | If `true`, run feature forecasting pipeline as well. |
| `use_actuals_for_features_forecast` | bool | If `true`, use actual values instead of forecasted features. |
| `output_asset` | str | Name of registered Azure ML data asset to store all the outputs. |
| `output_asset_version` | str | Version of output asset. |

**Example of a working config -** 
This config also contains hyperparameter grid for each of the model. It also contains `optuna_n_trials` in each of those models grid which defines number of iterations to run for their respective models.

# **Input Files and its Formats**

- **data_asset** : This path in config contains xlsx file which is the main data. It should contain all the columns defined in `target_columns`, `modelling_levels`, `date`,  `manual_features_for_modelling_asset` file. Example - [treated_data_with_lags_2506.xlsx](https://abb.sharepoint.com/:x:/t/AAAITeam/EbFUUP5tsNdMonS8tEF_iSwBVkLWJ9Uiy7jJ6Mk_9IytPw?email=parikshit.nag%40in.abb.com&e=jbaNbe)

- **manual_features_for_modelling_asset** :  This path in config contains xlsx file which will have all the features listed for all the groups and target KPIs. Groups (or modelling_levels) should be sheet_names, column names should be target_kpi and rows should be features under its respective target. It should include all internal and external features which is to be used. Example - [el_selected_for_modelling (1).xlsx](https://abb.sharepoint.com/:x:/t/AAAITeam/ETayRcY1jP9KlMhd2zBCHtUBLu3t3JkCM10ANQexSm39zQ?email=parikshit.nag%40in.abb.com&e=pmv273)

- **internal_feature_forecast** : This path contains xlsx file which will have forecast of features based on the validation, test and future periods we are mentioning in config. We cant use actual values of these features to predict validation, test and future periods. Hence we need their forecast whose values will be used as features to predict target of this config. This file only contains forecast of internal features (features which are specific to a modelling_level and its values will change if we change modelling_level e.g. `ELIP_revenues`). We mostly use lag of internal features, so that we dont have to forecast them, as errors will compound. We create this file using a code which is explained in the end of documentation. This file should have three sheets `val_predictions_actuals` for predictions of validation periods. `test_predictions_actuals` for predictions of test period. `future_predictions` for predictions of future period. Example - [elsp_revenues_feature_forecast_1 (1).xlsx](https://abb.sharepoint.com/:x:/t/AAAITeam/EWoE9LlViehCvQFdFOorkgkBOXZLQcZRImkNg5weQ2f74Q?email=parikshit.nag%40in.abb.com&e=eBh2An)

- **external_feature_forecast** : This path contains xlsx file which will have forecast of features based on the validation, test and future periods we are mentioning in config. We cant use actual values of these features to predict validation, test and future periods. Hence we need their forecast whose values will be used as features to predict target of this config. This file only contains forecast of external features (features which are not specific to a modelling_level and its values will not change if we change modelling_level e.g. `gdp_usa`). As these external features are quite stable and easy to forecast, we use univariate modelling to forecast them and use its output here. `Univariate Modelling Module` is a seperate module which will output this file in a format which can be used in this code. This file should have three sheets `val_predictions_actuals` for predictions of validation periods. `test_predictions_actuals` for predictions of test period. `future_predictions` for predictions of future period. Example - [univariate_el_external_3months_full.xlsx](https://abb.sharepoint.com/:x:/t/AAAITeam/ERPFjHsvfpdPo81Yx8_L3f8BMww-3rfZJgVOATb7vvdKNg?email=parikshit.nag%40in.abb.com&e=VuHdhG)

**Note** : In current version, it cant be identified whether a feature is external or internal. Hence `all_internal_features` this field in config needs to be filled. It should contain name of all the internal features which is being used in an experiment.

# **Splitting and Cross Validation**

In this module, dates for cross validation periods can be created in dynamic way. User can specify number of cv folds `n_folds` and duration of each folds in config using `per_fold_duration`. These cv periods are made based on test and future periods which is to be specified by user in `test` and `future` fields of config. Validation folds start a month before test period start date. 

For Example - test period is 2025-04-01 to 2025-06-01, future period is 2025-07-01 to 2025-09-01, and if n_folds is 4, with per_fold_duration as 3, then val1 will be 2024-04-01 to 2024-06-01, val2 will be 2024-07-01 to 2024-09-01, val3 will be 2024-10-01 to 2024-12-01 and val4 will be 2025-01-01 to 2025-03-01. Training data will be till 2024-03-01. 

Forecasting in this module happens in **walk-forward** way. When forecasting all these folds, data till 2024-03-01 is taken and model is being trained. Then prediction happens on val1 period, while predicting this, features forecast for val1 period will be used (so that there is no leakage in these validation periods too). Now after having results of val1, model is getting trained with actual data till val1 period, which is till 2024-06-01 and forecast is done for val2 period. Similarly, model is being trained till val2 data, and forecast is done for val3 period. Then trained on val3 data, forecast on val4 period. Trained till val4 data which is 2025-03-01, forecast on test period. Then trained till test data which is 2025-06-01 and forecasted for future periods.

# **Feature Engineering**

The pipeline supports **time-based, decomposition-based, and lag-based features**, with flexibility controlled entirely via the config. These features are only used in `tree-based models`. Its not being used in prophet/sarima.

- **Time-Based Features** - These features are generated using `date` column. It gives a sense of time to tree based model. It includes features like quarter, month, half-yearly, quarter end, quarter start, year end, year start, period, fourier sine, fourier cosine. All these features help model seasonality in tree-based models. These are mostly flags like 0 and 1. For Example - feature `QUARTER_Q1` will be 1 in jan, feb, march and 0 in all other months. FOURIER_SINE_k and FOURIER_COSINE_k are signals with sin/cosine like patterns which are seasonal. The code for this is being written in `models_utility.py` in `generate_quarter_half_features` function. You can see this file to see how these features look - [Temporal_features.xlsx](https://abb.sharepoint.com/:x:/t/AAAITeam/EVKFu54zHThIqmXwg2l4XNIB39BWlHm1icnUmWFu6b7OkQ?email=parikshit.nag%40in.abb.com&e=NEE1hN)

- **Decomposition Based Features** - This module has flexibility to use `TREND` and `SEASONALITY` from prophet model. This prophet model should be available in an already ran previous experiment. Prophet models output TREND and SEASONALITY as byproduct. Including these features from prophet model can increase accuracy of our current tree based model. Before using this, keep in mind the accuracy of previous experiment should not be bad, features used in previous experiments also affects its trend and seasonality.
The experiment name of previous prophet run can be mentioned in this field `prophet_trend_seasonal_experiment_name`. It will only be used if `stl_features` is filled with atleast `TREND` or `SEASONALITY`.
In code, check function `get_prophet_trend_seaonality` in `models_utility.py`. This kind of file is generated to store trend and seasonality: [ELDS____base_orders_net-prophet_trend_seasonal (1).xlsx](https://abb.sharepoint.com/:x:/t/AAAITeam/EZCRg1n200lLtR5CITRWiqwB59bslvvrZQztu0AsEuX_xg?email=bijaya.dhande%40in.abb.com&e=tN8fgW)

- **Lag Based Features** - Lag of target variable can also be used in this module. If lags are being used, forecasting is done one step at a time, instead of one-shot. For Example - if `LAG_1` is being used as a feature, then model will predict the `first future period` using the `last actual value` of `target` present in data, then it will use its own `first prediction` (as we cant use actuals) to predict `second future period` and so on. These lag features can be mentioned in this field `lag_features`. It should be in the form of `LAG_n`. If this field is empty, then one-shot forecast is being done for all the future periods.

- **Shap-Importance Filter** - In tree based models, we can have decompositions using shap. These decompositions helps us calculate feature importances. Sometimes, feature importances can be zero of few features for a model. Removing these features often improves accuracy. In this module, we can specify an old experiment name using this field `shap_importance_filter_experiment` which will remove all the features which had zero importance in that experiment. It will only apply this filter if this field `use_shap_importance_filter` is `true`. For this filter, one model's feature importances will not be used in another model. For example - LightGBM's feature importances from previous experiment will only be used to filter out zero importance features in current experiment's LightGBM model.

# **Hypertunning**

In this module, hyperparameter-tunning is done using **Optuna**, which uses Bayesian-based convergence to find best parameters for a given objective function. We can specify whether we want to maximize or minimize our objective function (or loss function) and Optuna then takes care of what parameters are giving best results over all the trials. For Optuna, we need a hyperparameter grid with ranges of values which is mentioned in config example above. All hyperparameter grids also need `optuna_n_trials` field which will decide the number of iterations we need to run for that model.

**Objective function** in this module is defined using accuracy metric which is `1 - abs(pred-actual)/actual`. First weighted mean validation accuracy is getting calculated, which gives more weights to latest validation periods. Then coefficient of variance is being calculated for validation accuracies which is `x = (variance of validation accuracies)/(mean of validation accuracies)`. Then at last a weighted mean of x and weighted mean validation accuracy is done. The calculation code is below

```
 avg_accuracy = 0.5*val4_accuracy + 0.2*val3_accuracy + 0.2*val2_accuracy + 0.1*val1_accuracy
 var_accuracy = np.var(list(val_accuracies.values())) if len(val_accuracies) > 1 else 0
 cv_accuracy = 1 - np.std(list(val_accuracies.values()))/np.mean(list(val_accuracies.values()))
 final_accuracy = avg_accuracy*0.3 + cv_accuracy*0.7
```
These weights are decided after experimentation.
The final metric declared above is being maximized by Optuna.

# **Consolidation**

After running all the validation, test and future forecasts, results are being saved in files and folders in the Data Asset in Azure Storage which can be mentioned in `output_data_asset`. A folder is getting created with `experiment_name` in the give data asset. Folder Structure of output is :

    output_data_asset/experiment_name
    ├──data
       ├── modelling_level_prepared_data.xlsx
       ├── modelling_level_split_data.xlsx
    ├── artifacts
       ├── modelling_level_model.pkl
       ├── modelling_level_model_class.pkl                         
    ├── hypertunning
       ├── modelling_level_model_training_data.xlsx
       ├── modelling_level_model_results.xlsx       
       ├── modelling_level_model_shapley_decomposition.xlsx
    ├── results
       ├── final_results.xlsx

Example - [mlwsdevaaaifor7718243172 - Microsoft Azure](https://portal.azure.com/#@ABB.onmicrosoft.com/resource/subscriptions/f6baff3f-4299-4ea3-b5e4-d5f539f22f49/resourceGroups/rg-dev-aaai-forecasting/providers/Microsoft.Storage/storageAccounts/mlwsdevaaaifor7718243172/storagebrowser)

In artifacts folder, all the model objects are being stored for every modelling_level and KPI and for each validation folds too. Also objects of models.py classes are also being stored, which enables us to retrain and predict easily. 

In hypertunning folder, the following data is being stored : 

- **modelling_level_KPI-model_all_training_data.xlsx** : all the training data is being stored for all modelling level and KPIs and for all validation folds. This also include features data to forecast future values for all validation, test as well future periods.

- **modelling_level_KPI-model.xlsx** :  this excel includes accuracies, metrics, validation, test and future forecasts. It also has all the combinations that was tried by optuna.

- **modelling_level_KPI-model_shapley.xlsx** : this excel has feature importance and shap decompositions for all tree based models.

- **modelling_level_KPI-prophet_full_decomposition.xlsx** : this excel contains prophet decompositions (as prophet is not supported by shap). it also includes upper and lower bound for all of its components and its coefficients too.

- **modelling_level_KPI-prophet_trend_seasonal.xlsx** : this excel has trend seasonality decomposition for each validation, test and future periods. It is there for all periods to avoid leakage.

In results folder, one file is present which is having these things

- **features list** :  list of features for each kpi and modelling level which is used in this run.
- **all trials** : all models optuna hypertunning runs are being stored in this excel
- **all best trials** : for each model, a best model is picked based on `final_accuracy` which is being placed in this excel.
- **selected model** :  among all the best models, a final model is selected based on `final_accuracy`.
- **val predictions** : all validation predictions for selected model
- **test predictions** : all test predictions for selected model
- **future predictions** : all future predictions for selected model
- **feature importance** : this includes features importance of best xgboost model. it is not recommended to use these importances.


# **Shapley Decompositions**

Shap Decompositions for data till future predictions are being produced using `shap` library. Then we are using these decompositions to calculate feature importances. it is being done by finding mean of all shap values column wise, then dividing them by summing those means to calculate their percentages. It is being written in `models_utility.py` in `get_shapley` function.

# **Forecast Interval**

Forecast interval is calculated using bootstrapping method using past residuals of that model. The original prediction is takes and it is being added by randomly selected residual `n` times. All of these synthetic predictions are collected in a list and then using fixed percentiles defined by user to get a lower bound and upper bound. It is being written in `models_utility.py` in `get_forecast_interval` function.