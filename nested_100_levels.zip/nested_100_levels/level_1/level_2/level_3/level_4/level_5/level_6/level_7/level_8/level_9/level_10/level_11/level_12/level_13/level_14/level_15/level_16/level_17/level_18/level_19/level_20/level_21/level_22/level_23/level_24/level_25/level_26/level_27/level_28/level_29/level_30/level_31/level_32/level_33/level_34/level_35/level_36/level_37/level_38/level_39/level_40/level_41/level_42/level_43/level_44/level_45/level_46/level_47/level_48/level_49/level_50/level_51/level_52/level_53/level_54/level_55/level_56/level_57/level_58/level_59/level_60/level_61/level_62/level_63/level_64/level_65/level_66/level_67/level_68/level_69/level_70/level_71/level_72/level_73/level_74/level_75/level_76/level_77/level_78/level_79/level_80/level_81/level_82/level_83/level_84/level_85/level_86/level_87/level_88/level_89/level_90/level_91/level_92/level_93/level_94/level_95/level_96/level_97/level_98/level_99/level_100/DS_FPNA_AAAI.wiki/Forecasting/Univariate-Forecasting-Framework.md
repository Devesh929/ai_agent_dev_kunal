

* * *

Univariate Forecasting Framework
================================

1. Overview
-----------

This module provides a unified interface for performing univariate time series forecasting using multiple statistical and probabilistic models. The core design is modular, extensible, and built around a shared abstract base class with standardized training and prediction methods.

### Features:

*   Consistent interface across models: `retrain()` and `predict()`
    
*   Support for multiple backends: Holt-Winters, SARIMA, Orbit (DLT, LGT), Prophet
    
*   Forecasting with optional prediction intervals
    
*   Logger integration for debugging and traceability
    

* * *

2. Architecture
---------------

### Folder Structure

    forecasting/
    ├── logger.py               
    ├── models_utility.py      
    ├── main_pipeline.py            
    ├── ....        
    ├── .....        
    ├── .....        
    ├── model_factory.py           # this file
    └── __init__.py
    

* * *

3. Model Interface
------------------

All models inherit from `BaseUnivariateModel`, which extends an abstract `BaseModel`.

### Methods

    def retrain(self, y: pd.Series, params: dict = None) -> Tuple[np.array, object, dict]
    

Trains the model on the given time series `y`. Optionally accepts model parameters.

    def predict(self, steps: int, model: object = None, confidence_level: float = None) -> Union[np.array, Tuple[np.array, np.array, np.array]]
    

Generates a forecast for the specified number of `steps`. Supports confidence interval output.

* * *

4. Model Implementations
------------------------

### 4.1 HoltWintersModel

**Library**: `statsmodels.tsa.holtwinters.ExponentialSmoothing`
**Parameters**:
*   `trend`: str, e.g., `'additive'` or `'multiplicative'`
    
*   `damped_trend`: bool
    
*   `seasonal`: str, same options as `trend`
    
*   `seasonal_periods`: int
    
**Notes**:
*   Forecasting uses standard Holt-Winters logic.
    
*   Confidence intervals are calculated based on residuals and z-scores.
    

* * *

### 4.2 SarimaUnivariateModel

**Library**: `statsmodels.tsa.statespace.SARIMAX`
**Parameters**:
*   `order`: Tuple[int, int, int] (p, d, q)
    
*   `seasonal_order`: Tuple[int, int, int, int] (P, D, Q, s)
    
**Notes**:
*   Uses SARIMA with seasonal order and trend integration.
    
*   Handles convergence warnings.
    
*   Forecast intervals are extracted directly from the model's forecast results.
    

* * *

### 4.3 OrbitDLTModel

**Library**: `orbit.models.DLT`
**Parameters**:
*   `estimator`: str, e.g., `'stan-map'`
    
*   `seasonality`: str, e.g., `'yearly'`
    
*   `global_trend_option`: str
    
*   `n_bootstrap_draws`: int
    
**Notes**:
*   Requires `pd.DatetimeIndex` on the series.
    
*   Percentile-based prediction intervals supported.
    
*   Training and prediction handle index conversion, sorting, and duplication removal.
    

* * *

### 4.4 OrbitLGTModel

**Library**: `orbit.models.LGT`
**Parameters**: Same as DLT.
**Notes**:
*   Used for series exhibiting local/global trend patterns.
    
*   Handles frequency inference and percentile-based prediction intervals.
    
*   Reuses the same validation and setup as DLT.
    

* * *

### 4.5 ProphetUnivariateModel

**Library**: `prophet.Prophet`
**Parameters**:
*   `seasonality_mode`: `'additive'` or `'multiplicative'`
    
*   `changepoint_prior_scale`: float
    
*   `n_changepoints`: int
    
*   `yearly_seasonality`: bool or `'auto'`
    
*   `uncertainty_samples`: int
    
*   `changepoint_range`: float
    
*   `extra_seasonalities`: List[dict] (optional)
    
**Notes**:
*   Supports additional custom seasonalities.
    
*   Forecasts returned from Prophet’s native output.
    
*   Confidence intervals returned using `yhat_lower` and `yhat_upper`.
    

* * *

5. Model Factory
----------------

### `get_model_object(model_name: str, logger) -> BaseUnivariateModel`

**Description**: Returns the appropriate model class instance based on the input name.
**Supported Identifiers**:
*   `'holtwinters_univariate'`
    
*   `'sarima_univariate'`
    
*   `'orbitdlt_univariate'`
    
*   `'orbitlgt_univariate'`
    
*   `'prophet_univariate'`
    

* * *

6. Usage Example
----------------

    from forecasting.model_factory import get_model_object
    
    model = get_model_object('sarima_univariate', logger)
    params = {
        'order': (1, 1, 1),
        'seasonal_order': (1, 1, 1, 12)
    }
    
    train_preds, fitted_model, used_params = model.retrain(y=train_series, params=params)
    future_forecast, lower, upper = model.predict(steps=12, model=fitted_model, confidence_level=0.9)
    

* * *

7. Logging and Error Handling
-----------------------------

*   All models accept a logger instance.
    
*   Warnings and exceptions are explicitly caught and logged.
    
*   Models validate inputs (e.g., check for datetime index, missing parameters).
    
*   Confidence interval generation handles fallback if percentile columns are missing.
    

* * *

8. Testing & Validation
-----------------------

### Unit Test Scenarios

| Scenario | Validation |
| --- | --- |
| Training with invalid params | Raises appropriate `ValueError` |
| Calling `predict` before `retrain` | Raises `ValueError` |
| Series without `DatetimeIndex` | Automatically converted and logged |
| Confidence interval logic | Validated for each model with appropriate percentiles |

* * *

9. Version History
------------------

| Version | Date | Description |
| --- | --- | --- |
| 1.0 | 2025-07-14 | Initial release with 5 univariate forecasting models |

* * *






::: mermaid
classDiagram
    class BaseModel {
        <<abstract>>
        +logger
    }

    class BaseUnivariateModel {
        <<abstract>>
        +retrain(y, params)
        +predict(steps, model, confidence_level)
    }

    BaseModel <|-- BaseUnivariateModel
    BaseUnivariateModel <|-- HoltWintersModel
    BaseUnivariateModel <|-- SarimaUnivariateModel
    BaseUnivariateModel <|-- OrbitDLTModel
    BaseUnivariateModel <|-- OrbitLGTModel
    BaseUnivariateModel <|-- ProphetUnivariateModel

    class HoltWintersModel {
        +retrain()
        +predict()
    }

    class SarimaUnivariateModel {
        +retrain()
        +predict()
    }

    class OrbitDLTModel {
        +retrain()
        +predict()
    }

    class OrbitLGTModel {
        +retrain()
        +predict()
    }

    class ProphetUnivariateModel {
        +retrain()
        +predict()
    }

    class model_factory {
        +get_model_object(model_name, logger)
    }
:::
