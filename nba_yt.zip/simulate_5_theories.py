import pandas as pd

def run_simulation():
    print("Loading data...")
    players = pd.read_csv('data/nba_player_logs_2012_2026.csv', low_memory=False)
    stocks = pd.read_csv('data/sp500_stock_data_2012_2026.csv', low_memory=False)
    
    players['GAME_DATE'] = pd.to_datetime(players['GAME_DATE']).dt.tz_localize(None)
    stocks['Date'] = pd.to_datetime(stocks['Date']).dt.tz_localize(None)
    
    # Filter to 2025-2026 season
    players = players[players['GAME_DATE'] >= '2025-10-01']
    
    stock_dates = sorted(stocks['Date'].unique())
    stock_date_df = pd.DataFrame({'Stock_Date': stock_dates})
    
    def get_next_trading_day(game_date):
        future = stock_date_df[stock_date_df['Stock_Date'] > game_date]
        if not future.empty:
            return future.iloc[0]['Stock_Date']
        return pd.NaT

    trades = []
    
    # 1. Devin Booker -> TSLA (Surge) -> TOV >= 7
    booker = players[(players['PLAYER_NAME'] == 'Devin Booker') & (players['TOV'] >= 7)]
    for _, row in booker.iterrows():
        trades.append({'Date': get_next_trading_day(row['GAME_DATE']), 'Ticker': 'TSLA', 'Type': 'LONG', 'Reason': 'Booker 7+ TOV'})
        
    # 2. Paolo Banchero -> META (Surge) -> PLUS_MINUS >= 20
    banchero = players[(players['PLAYER_NAME'] == 'Paolo Banchero') & (players['PLUS_MINUS'] >= 20)]
    for _, row in banchero.iterrows():
        trades.append({'Date': get_next_trading_day(row['GAME_DATE']), 'Ticker': 'META', 'Type': 'LONG', 'Reason': 'Banchero +20 +/-'})

    # 3. Alperen Sengun -> MCD (Crash) -> AST >= 10
    sengun = players[(players['PLAYER_NAME'] == 'Alperen Sengun') & (players['AST'] >= 10)]
    for _, row in sengun.iterrows():
        trades.append({'Date': get_next_trading_day(row['GAME_DATE']), 'Ticker': 'MCD', 'Type': 'SHORT', 'Reason': 'Sengun 10+ AST'})

    # 4. Stephen Curry -> TSLA (Surge) -> FG3M >= 9
    curry = players[(players['PLAYER_NAME'] == 'Stephen Curry') & (players['FG3M'] >= 9)]
    for _, row in curry.iterrows():
        trades.append({'Date': get_next_trading_day(row['GAME_DATE']), 'Ticker': 'TSLA', 'Type': 'LONG', 'Reason': 'Curry 9+ 3PM'})

    # 5. Victor Wembanyama -> AAPL (Crash) -> TOV >= 6
    wemby = players[(players['PLAYER_NAME'] == 'Victor Wembanyama') & (players['TOV'] >= 6)]
    for _, row in wemby.iterrows():
        trades.append({'Date': get_next_trading_day(row['GAME_DATE']), 'Ticker': 'AAPL', 'Type': 'SHORT', 'Reason': 'Wemby 6+ TOV'})

    trade_df = pd.DataFrame(trades).dropna().sort_values('Date')
    
    # Run the simulation
    balance = 100.0
    print(f"\nStarting Balance: ${balance:.2f}\n")
    print(f"{'Date':<12} | {'Ticker':<5} | {'Type':<5} | {'Reason':<20} | {'Open':<8} | {'Close':<8} | {'Return %':<8} | {'New Balance'}")
    print("-" * 90)
    
    for _, trade in trade_df.iterrows():
        date = trade['Date']
        ticker = trade['Ticker']
        
        # Get stock data for that day
        day_data = stocks[(stocks['Ticker'] == ticker) & (stocks['Date'] == date)]
        if day_data.empty: continue
        
        open_price = day_data.iloc[0]['Open']
        close_price = day_data.iloc[0]['Close']
        
        if trade['Type'] == 'LONG':
            ret = (close_price - open_price) / open_price
        else:
            ret = (open_price - close_price) / open_price
            
        ret_pct = ret * 100
        balance = balance * (1 + ret)
        
        print(f"{date.strftime('%Y-%m-%d'):<12} | {ticker:<5} | {trade['Type']:<5} | {trade['Reason']:<20} | ${open_price:<7.2f} | ${close_price:<7.2f} | {ret_pct:>6.2f}% | ${balance:.2f}")

    print("-" * 90)
    print(f"\nFinal Balance: ${balance:.2f}")
    print(f"Total ROI: {((balance - 100) / 100) * 100:.2f}%")

if __name__ == "__main__":
    run_simulation()
