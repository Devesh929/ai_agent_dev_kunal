##Objective

To validate execution of a PySpark job using Azure Synapse Analytics (Serverless or Dedicated Spark pool), confirming job orchestration, Python environment setup, and dependency management.

---
##Prerequisites
- Azure Machine Learning Workspace
- Synapse Workspace (Provisioned)  
- Spark pool (e.g., `spark-compute`)  
- Access to Synapse Studio + Linked Storage  
- Azure Data Lake or Blob linked (optional for data ops) 
- Role: Synapse Contributor / Blob Storage Reader and Blob Storage Contributor

---
##Project Structure (Local Dev)
     .
     |
     |__ main.py
     |
     |__ train.py
     |
     |__ environment.yml
     |
     |__ requirements.txt

**Steps**
 - Create Azure Synapse Workspace
 - Create a Spark pool in azure Synapse workspace ( the python version for synapse is set at 3.11 cannot be changed)
 - Add Blob Storage Contributor role to the synapse and machine learning workspace
 - Assign Synapse Administrator to Azure Machine Learning Workspace
 - Add the spark pool in azure machine learning workspace in the attached compute


##Expected Output

| **Step** | **Expected Result** |
|------|-----------------|
| Job submission | Status: `Queued -> Running -> Completed`|
| Logs | Output from `train.py` visible in azure logs |
---

##Known Bugs & Fixes

| **Issue Code / Log Message** | **Cause** | **Fixes** |
|------------------------------|-----------|-----------|
|`ModuleNotFoundError`, `state=[dead]`|Spark can't find python environment or module|[ ]|
|`curl: (22) The requested URL returned error: 409`|Broken `Liberaries.zip` link in spark config|[ ]|

---
