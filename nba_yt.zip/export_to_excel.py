import pandas as pd
import os

def export_to_excel():
    print("Preparing to export all findings to Excel...")
    
    excel_path = 'Final_NBA_Stock_Patterns.xlsx'
    
    # We will write to multiple sheets using Pandas ExcelWriter
    with pd.ExcelWriter(excel_path, engine='openpyxl') as writer:
        
        # 1. Simple Famous Player Narratives
        if os.path.exists('data/youtube_patterns.csv'):
            df1 = pd.read_csv('data/youtube_patterns.csv')
            df1.to_excel(writer, sheet_name='Superstar_Hooks', index=False)
            print("Exported Superstar Hooks sheet.")
            
        # 2. Splash Brothers & 3-Point Snipers
        if os.path.exists('data/3pt_patterns.csv'):
            df2 = pd.read_csv('data/3pt_patterns.csv')
            df2.to_excel(writer, sheet_name='Three_Point_Anomalies', index=False)
            print("Exported 3-Point Anomalies sheet.")
            
        # 3. Greedy Algorithm (All Players & Blowouts)
        if os.path.exists('data/greedy_patterns.csv'):
            df3 = pd.read_csv('data/greedy_patterns.csv')
            df3.to_excel(writer, sheet_name='Greedy_Miner_RolePlayers', index=False)
            print("Exported Greedy Miner sheet.")
            
        # 4. Compound Scenarios (Player + Team Outcome)
        if os.path.exists('data/compound_patterns.csv'):
            df4 = pd.read_csv('data/compound_patterns.csv')
            df4.to_excel(writer, sheet_name='Compound_Scenarios', index=False)
            print("Exported Compound Scenarios sheet.")
            
        # 5. The Top Volatility/Gap Coincidences (from the Causal Experiment)
        if os.path.exists('data/decadal_coincidences.csv'):
            df5 = pd.read_csv('data/decadal_coincidences.csv')
            df5.to_excel(writer, sheet_name='Causal_Volatility_Gaps', index=False)
            print("Exported Causal Volatility Gaps sheet.")

    print(f"\nSuccessfully saved all data to {excel_path} in the root folder!")

if __name__ == "__main__":
    export_to_excel()
