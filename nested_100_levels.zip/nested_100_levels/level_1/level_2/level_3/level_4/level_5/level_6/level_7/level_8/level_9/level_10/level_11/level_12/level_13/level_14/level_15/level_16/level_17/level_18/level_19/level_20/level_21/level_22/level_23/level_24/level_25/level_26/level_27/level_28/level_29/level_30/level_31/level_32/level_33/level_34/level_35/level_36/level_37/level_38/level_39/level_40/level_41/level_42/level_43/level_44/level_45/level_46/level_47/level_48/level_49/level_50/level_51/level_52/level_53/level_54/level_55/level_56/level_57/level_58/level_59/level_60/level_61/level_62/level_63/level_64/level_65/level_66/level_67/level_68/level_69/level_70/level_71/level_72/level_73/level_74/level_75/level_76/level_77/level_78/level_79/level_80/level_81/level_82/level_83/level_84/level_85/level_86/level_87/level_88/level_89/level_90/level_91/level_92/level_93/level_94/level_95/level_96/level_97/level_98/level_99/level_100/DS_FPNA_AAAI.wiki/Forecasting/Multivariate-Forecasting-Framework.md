* * *

Multivariate Forecasting 
========================
1. Overview
-----------

The Multivariate Forecasting Framework is designed to facilitate advanced time series forecasting by leveraging multiple statistical and machine learning models. This framework aims to provide a seamless and intuitive interface for users to implement and compare various forecasting techniques, making it easier to derive insights from complex datasets.


### Key Features:

*   **Unified Model Interface**: All models adhere to a consistent set of methods, including `retrain()` and `predict()`, ensuring a smooth user experience.
    
*   **Diverse Algorithm Support**: The framework encompasses a wide array of models, including SARIMA, Holt-Winters, Random Forest, Decision Tree, XGBoost, LightGBM, SVR, Linear Regression, and Prophet, catering to different forecasting needs.
    
*   **Flexible Forecasting Options**: Users can generate forecasts with or without confidence intervals, allowing for a comprehensive understanding of prediction uncertainty.
    
*   **Integrated Logging Mechanism**: Built-in logging capabilities enhance debugging and provide traceability throughout the forecasting process, making it easier to track model performance and diagnose issues.
    
*   **Modular and Extensible Design**: The architecture is built to be modular, allowing for easy addition of new models and features, thus accommodating future advancements in forecasting methodologies.
    

* * *

2. Architecture
---------------

* * *

### Folder Structure

    forecasting_core/ components/ multivariate_modelling/
    ├── logger.py               
    ├── utility.py      
    ├── main.py            
    ├── wrapper.py        
    ├── .....        
    ├── .....        
    ├── model_all.py           # this file
    └── __init__.py
    

* * *

3. Model Interface
------------------

* * *

All models derive from `BaseMultivariateModel`, which extends the abstract `BaseModel`.

### Core Methods

`def retrain(self, X: pd.DataFrame, y: pd.Series, params: dict = None) -> Tuple[np.array, object, dict]`

This method trains the model using the provided feature set `X` and target variable `y`, with optional model parameters.

`def predict(self, X: pd.DataFrame, steps: int) -> np.array`

Generates forecasts for the specified number of `steps` based on the input features `X`.

`def predict_with_lag_features(self, X: pd.DataFrame, steps: int, lag_features: List[str]) -> np.array`

Produces forecasts while incorporating lag features of the target variable.

`def predict_rolling_with_actual_data(self, inputs: dict) -> np.array`

Facilitates rolling predictions that utilize actual observed data.

`def predict_rolling_without_actual_data(self, inputs: dict) -> np.array`

Enables rolling predictions based on previous forecasts.

* * *

4. Model Implementations
------------------------

* * *

### 4.1 SarimaMultivariateModel

**Library**: `statsmodels.tsa.statespace.SARIMAX`
**Parameters**:
*   `order`: Tuple[int, int, int] (p, d, q)
*   `seasonal_order`: Tuple[int, int, int, int] (P, D, Q, s)
**Notes**:
*   Implements SARIMAX for seasonal and trend integration.
*   Manages convergence warnings effectively.
*   Extracts forecast intervals directly from the model's output.

* * *

### 4.2 HoltWintersMultivariateModel

**Library**: `statsmodels.tsa.holtwinters.ExponentialSmoothing`
**Parameters**:
*   `trend`: str, e.g., `'additive'` or `'multiplicative'`
*   `seasonal`: str, same options as `trend`
*   `seasonal_periods`: int
**Notes**:
*   Utilizes the standard Holt-Winters methodology for forecasting.
*   Computes confidence intervals based on residuals and statistical properties.

* * *

### 4.3 RandomForestMultivariateModel

**Library**: `sklearn.ensemble.RandomForestRegressor`
**Parameters**:
*   `n_estimators`: int
*   `max_depth`: int, optional
*   `random_state`: int, optional
**Notes**:
*   Capable of handling multiple features for training.
*   Default behavior includes handling of missing values.

* * *

### 4.4 DecisionTreeMultivariateModel

**Library**: `sklearn.tree.DecisionTreeRegressor`
**Parameters**:
*   `max_depth`: int, optional
*   `min_samples_split`: int, optional
**Notes**:
*   Provides a straightforward and interpretable approach to regression tasks.
*   Prone to overfitting if not properly tuned.

* * *

### 4.5 XGBoostTreeMultivariateModel

**Library**: `xgboost.XGBRegressor`
**Parameters**:
*   `n_estimators`: int
*   `learning_rate`: float
*   `max_depth`: int
**Notes**:
*   An efficient and scalable implementation of gradient boosting.
*   Supports regularization techniques to mitigate overfitting.

* * *

### 4.6 XGBoostLinearMultivariateModel

**Library**: `xgboost.XGBRegressor`
**Parameters**: Same as XGBoostTree.
**Notes**:
*   Tailored for linear regression tasks using XGBoost.
*   Efficiently handles large datasets.

* * *

### 4.7 ExtraTreesMultivariateModel

**Library**: `sklearn.ensemble.ExtraTreesRegressor`
**Parameters**:
*   `n_estimators`: int
*   `max_depth`: int, optional
**Notes**:
*   Similar to Random Forest but employs a different tree-building strategy.
*   Generally faster and can yield improved accuracy.

* * *

### 4.8 SVRMultivariateModel

**Library**: `sklearn.svm.SVR`
**Parameters**:
*   `kernel`: str, e.g., `'linear'`, `'poly'`, `'rbf'`
*   `C`: float
**Notes**:
*   Effective in high-dimensional spaces and capable of modeling non-linear relationships.

* * *

### 4.9 LinearRegressionMultivariateModel

**Library**: `sklearn.linear_model.LinearRegression`
**Parameters**:
*   `fit_intercept`: bool
*   `normalize`: bool, optional
**Notes**:
*   A fundamental linear regression model.
*   Assumes a linear relationship between features and the target variable.

* * *

### 4.10 LightGBMMultivariateModel

**Library**: `lightgbm.LGBMRegressor`
**Parameters**:
*   `n_estimators`: int
*   `learning_rate`: float
**Notes**:
*   A fast and efficient gradient boosting framework.
*   Natively supports categorical features.

* * *

### 4.11 ProphetMultivariateModel

**Library**: `prophet.Prophet`
**Parameters**:
*   `seasonality_mode`: `'additive'` or `'multiplicative'`
*   `changepoint_prior_scale`: float
*   `n_changepoints`: int
**Notes**:
*   Capable of accommodating additional custom seasonalities.
*   Forecasts are derived from Prophet’s native output.

* * *

### 4.12 ProphetUnivariateModel

**Library**: `prophet.Prophet`
**Parameters**: Same as ProphetMultivariateModel.
**Notes**:
*   Specifically designed for univariate time series forecasting.
*   Effectively manages missing data and outliers.

* * *

5. Model Factory
----------------

* * *

### `get_model_object(model_name: str, logger) -> BaseMultivariateModel`

**Description**: Returns the appropriate model class instance based on the specified model name.
**Supported Identifiers**:
*   `'sarima_multivariate'`
*   `'holt_winters_multivariate'`
*   `'randomforest_multivariate'`
*   `'decisiontree_multivariate'`
*   `'xgboost_tree_multivariate'`
*   `'xgboost_linear_multivariate'`
*   `'extra_trees_multivariate'`
*   `'svr_multivariate'`
*   `'linear_regression_multivariate'`
*   `'lightgbm_multivariate'`
*   `'prophet_multivariate'`
*   `'prophet_univariate'`

* * *

6. Usage Example
----------------

* * *


    from forecasting.model_factory import get_model_object

model = get_model_object('sarima_multivariate', logger)
params = {
    'order': (1, 1, 1),
    'seasonal_order': (1, 1, 1, 12)
}

train_preds, fitted_model, used_params = model.retrain(X=train_data, y=train_target, params=params)
future_forecast = model.predict(X=future_data, steps=12)


* * *
    import pandas as pd
    import numpy as np
    from models_all import SarimaMultivariateModel  
    from logging import getLogger

    # Initialize a logger
    logger = getLogger(__name__)

    # Create example training data
    # Assume we have a target variable 'y' and two exogenousariables 'X1' and 'X2'
    dates = pd.date_range(start='2020-01-01', periods=50, freq='MS')
    y_train = pd.Series(np.random.rand(50), index=dates, name='target')
    X_train = pd.DataFrame({
    'X1': np.random.rand(50),
    'X2': np.random.rand(50)
    }, index=dates)

    # Create an instance of the SarimaMultivariateModel
    sarima_model = SarimaMultivariateModel(logger=logger)

    # Define model parameters
    params = {
    'order': (1, 1, 1),  # (p, d, q)
    'seasonal_order': (1, 1, 1, 12)  # (P, D, Q, s)
    }

    # Train the model
    retrain_output = sarima_model.retrain({
    'X': X_train,
    'y': y_train,
    'params': params
    })

    # Print retrain output
    print("Retrain Output:")
    print(retrain_output)

    # Create example future data for prediction
    future_dates = pd.date_range(start='2024-03-01', periods=10, freq='MS')
    X_future = pd.DataFrame({
    'X1': np.random.rand(10),
    'X2': np.random.rand(10)}, index=future_dates)

    # Make predictions for the next 10 steps
    predictions = sarima_model.predict({
    'X': X_future,
    'steps': 10
    })

    # Print predictions
    print("Predictions for the next 10 steps:")
    print(predictions)

* * *

7. Logging and Error Handling
-----------------------------

* * *

*   All models accept a logger instance for tracking.
*   Warnings and exceptions are explicitly captured and logged for clarity.
*   Input validation is performed (e.g., ensuring datetime indices and required parameters).
*   Confidence interval generation includes fallback mechanisms if percentile columns are absent.

* * *

8. Testing & Validation
-----------------------

* * *

### Unit Test Scenarios

| Scenario<br> | Validation<br> |
| --- | --- |
| Training with invalid parameters<br> | Raises appropriate `ValueError`<br> |
| Invoking `predict` before `retrain`<br> | Raises `ValueError`<br> |
| Series lacking `DatetimeIndex`<br> | Automatically converted and logged<br> |
| Confidence interval logic<br> | Validated for each model with appropriate percentiles<br> |

* * *

9. Version History
------------------

* * *

| Version<br> | Date<br> | Description<br> |
| --- | --- | --- |
| 1.0<br> | 2025-07-31<br> | Initial release featuring a suite of multivariate forecasting models<br> |

* * *

::: mermaid
classDiagram
    class BaseModel {
        <<abstract>>
        +logger
    }

    class BaseMultivariateModel {
        <<abstract>>
        +retrain(X, y, params)
        +predict(X, steps)
        +predict_with_lag_features(X, steps, lag_features)
        +predict_rolling_with_actual_data(inputs)
        +predict_rolling_without_actual_data(inputs)
    }

    BaseModel <|-- BaseMultivariateModel
    BaseMultivariateModel <|-- SarimaMultivariateModel
    BaseMultivariateModel <|-- HoltWintersMultivariateModel
    BaseMultivariateModel <|-- RandomForestMultivariateModel
    BaseMultivariateModel <|-- DecisionTreeMultivariateModel
    BaseMultivariateModel <|-- XGBoostTreeMultivariateModel
    BaseMultivariateModel <|-- XGBoostLinearMultivariateModel
    BaseMultivariateModel <|-- ExtraTreesMultivariateModel
    BaseMultivariateModel <|-- SVRMultivariateModel
    BaseMultivariateModel <|-- LinearRegressionMultivariateModel
    BaseMultivariateModel <|-- LightGBMMultivariateModel
    BaseMultivariateModel <|-- ProphetMultivariateModel
    BaseMultivariateModel <|-- ProphetUnivariateModel

    class SarimaMultivariateModel {
        +retrain()
        +predict()
    }

    class HoltWintersMultivariateModel {
        +retrain()
        +predict()
    }

    class RandomForestMultivariateModel {
        +retrain()
        +predict()
    }

    class DecisionTreeMultivariateModel {
        +retrain()
        +predict()
    }

    class XGBoostTreeMultivariateModel {
        +retrain()
        +predict()
    }

    class XGBoostLinearMultivariateModel {
        +retrain()
        +predict()
    }

    class ExtraTreesMultivariateModel {
        +retrain()
        +predict()
    }

    class SVRMultivariateModel {
        +retrain()
        +predict()
    }

    class LinearRegressionMultivariateModel {
        +retrain()
        +predict()
    }

    class LightGBMMultivariateModel {
        +retrain()
        +predict()
    }

    class ProphetMultivariateModel {
        +retrain()
        +predict()
        +predict_with_lag_features()
        +get_trend_seasonal()
        +get_train_trend_seasonal()
        +get_trend_seasonal_with_lag_features()
        +get_forecast_interval()
        +get_full_decomposition()
        +get_full_decomposition_with_lag_features()

    }

    class ProphetUnivariateModel {
        +retrain()
        +predict()
    }

    class models_all {
        +get_model_object(model_name, logger)
    }

:::
### Explanation of the Diagram:

*   **BaseModel**: The abstract base class that contains common attributes like `logger`.
    
*   **BaseMultivariateModel**: Inherits from `BaseModel` and defines the core methods for retraining and predicting across all multivariate models.
    
*   **Concrete Models**: Each specific model class (e.g., `SarimaMultivariateModel`, `HoltWintersMultivariateModel`, etc.) inherits from `BaseMultivariateModel` and implements the `retrain()` and `predict()` methods.
    
*   **Models**: The `models_all` class provides a method to instantiate the appropriate model based on the model name.