import pandas as pd

def run_exhaustive_miner():
    print("Loading data for Exhaustive Active Miner...")
    try:
        players = pd.read_csv('data/nba_player_logs_2012_2026.csv')
        stocks = pd.read_csv('data/sp500_stock_data_2012_2026.csv')
    except Exception as e:
        print(f"Error loading data: {e}")
        return

    players['GAME_DATE'] = pd.to_datetime(players['GAME_DATE']).dt.tz_localize(None)
    stocks['Date'] = pd.to_datetime(stocks['Date']).dt.tz_localize(None)
    stocks.sort_values(by=['Ticker', 'Date'], inplace=True)
    
    stocks['Pct_Change'] = stocks.groupby('Ticker')['Close'].pct_change() * 100
    stocks['Went_Up'] = stocks['Pct_Change'] > 0
    stocks['Went_Down'] = stocks['Pct_Change'] < 0

    famous_tickers = {
        'TSLA': 'Tesla', 'AAPL': 'Apple', 'MSFT': 'Microsoft', 'AMZN': 'Amazon',
        'NFLX': 'Netflix', 'META': 'Meta', 'KO': 'Coca-Cola', 'MCD': 'McDonalds',
        'SBUX': 'Starbucks', 'NKE': 'Nike', 'DIS': 'Disney', 'UBER': 'Uber'
    }
    stocks = stocks[stocks['Ticker'].isin(famous_tickers.keys())]

    stock_dates = sorted(stocks['Date'].unique())
    stock_date_df = pd.DataFrame({'Stock_Date': stock_dates})
    
    def get_next_trading_day(game_date):
        future = stock_date_df[stock_date_df['Stock_Date'] > game_date]
        if not future.empty:
            return future.iloc[0]['Stock_Date']
        return pd.NaT

    unique_game_dates = pd.DataFrame({'GAME_DATE': players['GAME_DATE'].unique()})
    unique_game_dates['Next_Trading_Date'] = unique_game_dates['GAME_DATE'].apply(get_next_trading_day)
    players = pd.merge(players, unique_game_dates, on='GAME_DATE', how='left')

    # Legends + Emerging Stars going into 2026-2027
    active_stars = [
        "LeBron James", "Stephen Curry", "Kevin Durant", "Giannis Antetokounmpo", 
        "James Harden", "Luka Doncic", "Nikola Jokic", "Devin Booker", "Jayson Tatum", "Joel Embiid",
        "Anthony Edwards", "Victor Wembanyama", "Tyrese Haliburton", "Jalen Brunson", "Paolo Banchero",
        "Shai Gilgeous-Alexander", "Chet Holmgren", "De'Aaron Fox", "Zion Williamson", "Trae Young",
        "Donovan Mitchell", "Jaylen Brown", "Tyrese Maxey", "Alperen Sengun", "Scottie Barnes"
    ]
    
    players = players[players['PLAYER_NAME'].isin(active_stars)]

    events = []
    print("Brute-forcing all box score metrics...")
    
    for _, row in players.iterrows():
        p_name = row['PLAYER_NAME']
        date = row['Next_Trading_Date']
        if pd.isna(date): continue
            
        pts = row['PTS']
        ast = row['AST']
        reb = row['REB']
        stl = row['STL']
        blk = row['BLK']
        tov = row['TOV']
        fga = row['FGA']
        pm = row['PLUS_MINUS']
        
        # Scoring
        if pts >= 30: events.append({'Date': date, 'Event': f"{p_name} scores 30+"})
        if pts >= 40: events.append({'Date': date, 'Event': f"{p_name} scores 40+"})
        
        # Playmaking
        if ast >= 10: events.append({'Date': date, 'Event': f"{p_name} dishes 10+ Assists"})
        if ast >= 14: events.append({'Date': date, 'Event': f"{p_name} dishes 14+ Assists"})
        
        # Boards
        if reb >= 15: events.append({'Date': date, 'Event': f"{p_name} grabs 15+ Rebounds"})
        
        # Defense
        if stl >= 4: events.append({'Date': date, 'Event': f"{p_name} gets 4+ Steals"})
        if blk >= 4: events.append({'Date': date, 'Event': f"{p_name} gets 4+ Blocks"})
        
        # Usage / Mistakes
        if tov >= 6: events.append({'Date': date, 'Event': f"{p_name} turns it over 6+ times"})
        if fga >= 25: events.append({'Date': date, 'Event': f"{p_name} takes 25+ shots"})
        
        # Impact
        if pd.notna(pm):
            if pm >= 20: events.append({'Date': date, 'Event': f"{p_name} dominates with +20 Plus/Minus"})
            if pm <= -20: events.append({'Date': date, 'Event': f"{p_name} is a liability with -20 Plus/Minus"})

    events_df = pd.DataFrame(events).drop_duplicates()
    
    results = []
    for event_name in events_df['Event'].unique():
        event_dates = events_df[events_df['Event'] == event_name]['Date']
        num_occurrences = len(event_dates)
        
        if num_occurrences < 15: # Threshold for emerging stars to have enough games
            continue
            
        for ticker, company_name in famous_tickers.items():
            stock_slice = stocks[(stocks['Ticker'] == ticker) & (stocks['Date'].isin(event_dates))]
            if len(stock_slice) == 0: continue
            
            up_days = stock_slice['Went_Up'].sum()
            down_days = stock_slice['Went_Down'].sum()
            
            up_pct = (up_days / len(stock_slice)) * 100
            down_pct = (down_days / len(stock_slice)) * 100
            
            # We want high accuracy (>= 72%) to ensure it's a solid pattern
            if up_pct >= 72:
                results.append({
                    'Pattern': f"Whenever {event_name}, {company_name} stock GOES UP!",
                    'Accuracy': up_pct,
                    'Occurrences': len(stock_slice),
                })
            elif down_pct >= 72:
                results.append({
                    'Pattern': f"Whenever {event_name}, {company_name} stock CRASHES!",
                    'Accuracy': down_pct,
                    'Occurrences': len(stock_slice),
                })

    res_df = pd.DataFrame(results)
    if not res_df.empty:
        res_df.sort_values(by=['Accuracy', 'Occurrences'], ascending=[False, False], inplace=True)
        res_df.to_csv('data/exhaustive_active_patterns.csv', index=False)
        print("\n=== TOP EXHAUSTIVE ACTIVE PATTERNS ===\n")
        # Print top 15 that aren't already heavily discussed
        for _, row in res_df.head(20).iterrows():
            print(f"{row['Pattern']} ({row['Accuracy']:.1f}% accuracy, N={row['Occurrences']})")
    else:
        print("No new patterns met the high threshold.")

if __name__ == "__main__":
    run_exhaustive_miner()
