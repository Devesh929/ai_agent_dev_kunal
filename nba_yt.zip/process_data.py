import pandas as pd
import numpy as np
import os
from tqdm import tqdm

def process_data():
    print("Loading data...")
    try:
        stocks = pd.read_csv('data/sp500_stock_data_2012_2026.csv')
        nba = pd.read_csv('data/nba_team_logs_2012_2026.csv')
    except FileNotFoundError:
        print("Data files not found. Run fetch scripts first.")
        return

    # Process Stock Data
    # Calculate daily percentage change
    print("Processing stock data...")
    stocks['Date'] = pd.to_datetime(stocks['Date']).dt.tz_localize(None)
    stocks.sort_values(by=['Ticker', 'Date'], inplace=True)
    stocks['Pct_Change'] = stocks.groupby('Ticker')['Close'].pct_change() * 100
    stocks['Direction'] = np.where(stocks['Pct_Change'] > 0, 1, 0)
    
    # We want a wide format for stocks to easily correlate against NBA events:
    # Date, AAPL_Pct_Change, MSFT_Pct_Change...
    stocks_wide = stocks.pivot(index='Date', columns='Ticker', values='Pct_Change').reset_index()
    
    # Process NBA Data
    print("Processing NBA data...")
    nba['GAME_DATE'] = pd.to_datetime(nba['GAME_DATE']).dt.tz_localize(None)
    
    # Create simple binary features
    # E.g. did a specific team win?
    # WL column is 'W' or 'L'
    nba['Win'] = np.where(nba['WL'] == 'W', 1, 0)
    
    # Let's create wide format for NBA team wins
    nba_wins_wide = nba.pivot_table(index='GAME_DATE', columns='TEAM_ABBREVIATION', values='Win', aggfunc='max').reset_index()
    nba_wins_wide.columns.name = None
    
    # Prefix NBA columns
    nba_wins_wide.columns = ['Date'] + [f'NBA_{col}_Win' for col in nba_wins_wide.columns if col != 'GAME_DATE']
    
    # Date Alignment: We want to align NBA Game Date (T) with Stock Date (T+1 or next valid trading day)
    print("Aligning dates...")
    stock_dates = sorted(stocks['Date'].unique())
    stock_date_df = pd.DataFrame({'Stock_Date': stock_dates})
    
    # For each NBA game date, find the first stock trading date that is strictly greater than the game date
    def get_next_trading_day(game_date):
        future_dates = stock_date_df[stock_date_df['Stock_Date'] > game_date]
        if not future_dates.empty:
            return future_dates.iloc[0]['Stock_Date']
        return pd.NaT

    nba_wins_wide['Next_Trading_Date'] = nba_wins_wide['Date'].apply(get_next_trading_day)
    
    # Merge NBA features with Stock Returns
    print("Merging datasets...")
    merged = pd.merge(nba_wins_wide, stocks_wide, left_on='Next_Trading_Date', right_on='Date', how='inner')
    
    # Drop redundant date columns
    merged.drop(columns=['Date_x', 'Date_y', 'Next_Trading_Date'], inplace=True)
    
    # Save the feature matrix
    output_file = 'data/feature_matrix.csv'
    merged.to_csv(output_file, index=False)
    print(f"Feature matrix saved to {output_file}. Shape: {merged.shape}")
    
    # Run basic correlations
    print("Computing massive correlation matrix...")
    nba_cols = [c for c in merged.columns if c.startswith('NBA_')]
    stock_cols = [c for c in merged.columns if not c.startswith('NBA_')]
    
    # We only care about correlation between NBA and Stocks (not Stock to Stock or NBA to NBA)
    corr_results = []
    
    for nba_col in tqdm(nba_cols):
        for stock_col in stock_cols:
            # Drop NaNs
            valid_data = merged[[nba_col, stock_col]].dropna()
            if len(valid_data) > 30: # Need minimum sample size
                corr = valid_data[nba_col].corr(valid_data[stock_col])
                if pd.notna(corr) and abs(corr) > 0.15: # Filter out very weak noise
                    corr_results.append({
                        'NBA_Event': nba_col,
                        'Stock': stock_col,
                        'Correlation': corr,
                        'Sample_Size': len(valid_data)
                    })
                    
    results_df = pd.DataFrame(corr_results)
    if not results_df.empty:
        results_df.sort_values(by='Correlation', key=abs, ascending=False, inplace=True)
        results_df.to_csv('data/top_correlations.csv', index=False)
        print("Top correlations saved to data/top_correlations.csv")
        print(results_df.head(20))
    else:
        print("No significant correlations found.")

if __name__ == "__main__":
    process_data()
