##Objective
Outline the steps to **set up**, **retrieve**, and **validate** features from **Azure Feature Store** in a secure and scalable manner. Focus areas include:
*   Configuring offline stores such as **ADLS Gen2** for feature materialization
    
*   Granting necessary access to users and managed identities
    
*   Retrieving features into **Pandas DataFrames** using the Azure ML SDK (without Spark)
    
*   Verifying successful integration through data validation and testing

---

##Pre-requisites
- Azure ML Workspace set up
- Pre-built Key vault
- Azure CLI
- Azure SDK v2
- Spark serverless instance
---

##Steps
The set up of azure featurestore is done with the use of both the Azure CLI and Azure ml sdkv2

- Login and authenticate azure subscription

```
az login
```

- Set up the feature using a *.yaml* file since with ABB policy does not allow resources to create there own key vault.
- Create the yaml file with a minimum set up like the following here the storage account is also already set up
```
$schema: https://azuremlschemas.azureedge.net/latest/featurestore.schema.json

name: feature-store-mlops-test

type: featurestore

location: eastus

description: Feature store for customer churn model

  

# Optional: Key Vault integration

key_vault: /subscriptions/f6baff3f-4299-4ea3-b5e4-d5f539f22f49/resourceGroups/rg-dev-aaai-mlops/providers/Microsoft.KeyVault/vaults/kv-featurestore

  

# Offline store configuration

offline_store:

  type: azure_data_lake_gen2

  target: "abfss://featurescontaine15400363@featuresstorage10c9d51db.dfs.core.windows.net/"

```
- Creating the Feature store using the following command
```
!az ml feature-store create --file ./Users/<user-name>/<folder-path>/<your-yaml-file>.yaml --resource-group $featurestore_resource_group_name --subscription $featurestore_subscription_id
```


- Before using the feature store make sure to assign the following roles to the feature store
  - AzureML Data Scientist to your User Identity
  - Storage Blob Data Contributor and Reader role to the storage accounts

- Creating the feature store entity using a yaml template
```
# Feature Store Entity yaml template

$schema: http://azureml/sdk-2-0/FeaturestoreEntity.json

name: account

version: "1"

description: account  entity

index_columns:

  - name: accountID

    type: string
```
```
account_entity_path = root_dir + "/featurestore/entities/account.yaml"

!az ml feature-store-entity create --file $account_entity_path --resource-group $featurestore_resource_group_name --feature-store-name $featurestore_name
```
- Creating the feature set using the yaml template
- The transformation code are stored with the set so the transformed data is returned as the output when retrieved.
```
# Example of a yaml template for the feature set

feature_transformation:

  transformation_code:

    path: ./transformation_code

    transformer_class: transaction_transform.TransactionFeatureTransformer

features:

- name: transaction_3d_count

  type: long

- name: transaction_amount_3d_sum

  type: double

- name: transaction_amount_3d_avg

  type: double

- name: transaction_7d_count

  type: long

- name: transaction_amount_7d_sum

  type: double

- name: transaction_amount_7d_avg

  type: double

index_columns:

- name: accountID

  type: string

source:

  path: wasbs://data@azuremlexampledata.blob.core.windows.net/feature-store-prp/datasources/transactions-source/*.parquet

  source_delay:

    days: 0

    hours: 0

    minutes: 20

  timestamp_column:

    name: timestamp

  type: parquet

source_lookback:

  days: 7

  hours: 0

  minutes: 0

temporal_join_lookback:

  days: 1

  hours: 0

  minutes: 0

```
---
## Retrieving Features from feature store

- Initializing featurestore in sdk
```
from azureml.featurestore import FeatureStoreClient

from azure.ai.ml.identity import AzureMLOnBehalfOfCredential

  

featurestore = FeatureStoreClient(

    credential=AzureMLOnBehalfOfCredential(),

    subscription_id=featurestore_subscription_id,

    resource_group_name=featurestore_resource_group_name,

    name=featurestore_name,

)
```
- Get registered feature set
```
# Look up the featureset by providing a name and a version.

transactions_featureset = featurestore.feature_sets.get("transactions", "1")

# List its features.

df = transactions_featureset.to_spark_dataframe()

```

---
##Errors and Fixes

| Errors | Fixes |
|--------|-------|
| `cannot import name 'AzureMLSDKLogHandler`| Update the azure-ai-ml module|
| `cannot materialize offline store`| access not granted to storage account|

---
##Points to note
- Make sure key vault name does not contain '-' sign. This does not let you attach resources to the key vault.
- Even if a storage container is attached to the feature store before creation, during creation one more container is created so the storage contributor and reader is to be granted for that account as well.
- azure feature store can only be created and used in a spark serverless instance.
---