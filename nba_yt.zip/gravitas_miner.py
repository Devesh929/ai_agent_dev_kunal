import pandas as pd
import numpy as np

def run_gravitas_miner():
    print("Loading data for Gravitas Miner...")
    try:
        players = pd.read_csv('data/nba_player_logs_2012_2026.csv')
        stocks = pd.read_csv('data/sp500_stock_data_2012_2026.csv')
    except Exception as e:
        print(f"Error loading data: {e}")
        return

    players['GAME_DATE'] = pd.to_datetime(players['GAME_DATE']).dt.tz_localize(None)
    stocks['Date'] = pd.to_datetime(stocks['Date']).dt.tz_localize(None)
    stocks.sort_values(by=['Ticker', 'Date'], inplace=True)
    
    stocks['Pct_Change'] = stocks.groupby('Ticker')['Close'].pct_change() * 100
    stocks['Went_Up'] = stocks['Pct_Change'] > 0
    stocks['Went_Down'] = stocks['Pct_Change'] < 0

    # Calculate 52-week (rolling 252 trading days) highs and lows
    stocks['Rolling_Low'] = stocks.groupby('Ticker')['Close'].rolling(window=252, min_periods=50).min().reset_index(0, drop=True)
    stocks['Rolling_High'] = stocks.groupby('Ticker')['Close'].rolling(window=252, min_periods=50).max().reset_index(0, drop=True)

    stock_dates = sorted(stocks['Date'].unique())
    stock_date_df = pd.DataFrame({'Stock_Date': stock_dates})
    
    def get_next_trading_day(game_date):
        future = stock_date_df[stock_date_df['Stock_Date'] > game_date]
        if not future.empty:
            return future.iloc[0]['Stock_Date']
        return pd.NaT

    unique_game_dates = pd.DataFrame({'GAME_DATE': players['GAME_DATE'].unique()})
    unique_game_dates['Next_Trading_Date'] = unique_game_dates['GAME_DATE'].apply(get_next_trading_day)
    players = pd.merge(players, unique_game_dates, on='GAME_DATE', how='left')

    # Define the best patterns to find Gravitas for
    patterns = [
        {"name": "Devin Booker turns the ball over 7+ times", "player": "Devin Booker", "condition": lambda r: r['TOV'] >= 7, "ticker": "TSLA", "company": "Tesla", "type": "UP"},
        {"name": "Kevin Durant shoots terribly (<35% on 18+ shots)", "player": "Kevin Durant", "condition": lambda r: r['FGA'] >= 18 and r['FG_PCT'] <= 0.35, "ticker": "META", "company": "Meta", "type": "DOWN"},
        {"name": "Jayson Tatum is a ball hog (takes 28+ shots)", "player": "Jayson Tatum", "condition": lambda r: r['FGA'] >= 28, "ticker": "AMZN", "company": "Amazon", "type": "DOWN"},
        {"name": "Shai Gilgeous-Alexander perfect on 12+ FTs", "player": "Shai Gilgeous-Alexander", "condition": lambda r: r['FTA'] >= 12 and r['FT_PCT'] == 1.0, "ticker": "TSLA", "company": "Tesla", "type": "DOWN"},
        {"name": "Dillon Brooks scores 20+ points", "player": "Dillon Brooks", "condition": lambda r: r['PTS'] >= 20, "ticker": "NKE", "company": "Nike", "type": "DOWN"},
        {"name": "Stephen Curry hits 9+ Threes", "player": "Stephen Curry", "condition": lambda r: r['FG3M'] >= 9, "ticker": "TSLA", "company": "Tesla", "type": "UP"},
        {"name": "Russell Westbrook fouls out", "player": "Russell Westbrook", "condition": lambda r: r['PF'] >= 6, "ticker": "AAPL", "company": "Apple", "type": "UP"}
    ]

    gravitas_results = []

    for p in patterns:
        player_df = players[players['PLAYER_NAME'] == p['player']]
        event_dates = []
        for _, row in player_df.iterrows():
            if p['condition'](row):
                if pd.notna(row['Next_Trading_Date']):
                    event_dates.append(row['Next_Trading_Date'])
        
        if not event_dates: continue

        stock_df = stocks[stocks['Ticker'] == p['ticker']].copy()
        event_stock_df = stock_df[stock_df['Date'].isin(event_dates)]
        
        # Calculate base stats
        n_occurrences = len(event_stock_df)
        if p['type'] == 'UP':
            accuracy = (event_stock_df['Went_Up'].sum() / n_occurrences) * 100
        else:
            accuracy = (event_stock_df['Went_Down'].sum() / n_occurrences) * 100

        # Find Gravitas Moments
        gravitas_moments = []
        
        # 1. Did any of these dates cause the lowest low of the year?
        if p['type'] == 'DOWN':
            lowest_days = event_stock_df[event_stock_df['Close'] <= event_stock_df['Rolling_Low'] * 1.02] # Within 2% of the 52-week low
            if not lowest_days.empty:
                best_drop = lowest_days.sort_values(by='Pct_Change').iloc[0]
                gravitas_moments.append(f"On {best_drop['Date'].strftime('%Y-%m-%d')}, this event triggered a massive crash that pushed {p['company']} stock to its 52-week low!")
            
            # Massive single day drop
            huge_drops = event_stock_df[event_stock_df['Pct_Change'] <= -4.0]
            if not huge_drops.empty:
                worst = huge_drops.sort_values(by='Pct_Change').iloc[0]
                gravitas_moments.append(f"On {worst['Date'].strftime('%Y-%m-%d')}, this event coincided with a brutal {abs(worst['Pct_Change']):.1f}% single-day wipeout for {p['company']}!")

        if p['type'] == 'UP':
            highest_days = event_stock_df[event_stock_df['Close'] >= event_stock_df['Rolling_High'] * 0.98] # Within 2% of 52-week high
            if not highest_days.empty:
                best_rise = highest_days.sort_values(by='Pct_Change', ascending=False).iloc[0]
                gravitas_moments.append(f"On {best_rise['Date'].strftime('%Y-%m-%d')}, this event triggered a surge that pushed {p['company']} stock to a 52-week HIGH!")
                
            # Massive single day rise
            huge_rises = event_stock_df[event_stock_df['Pct_Change'] >= 4.0]
            if not huge_rises.empty:
                best = huge_rises.sort_values(by='Pct_Change', ascending=False).iloc[0]
                gravitas_moments.append(f"On {best['Date'].strftime('%Y-%m-%d')}, {p['company']} surged by a massive {best['Pct_Change']:.1f}% the morning after this event!")

        gravitas_results.append({
            'Pattern': p['name'],
            'Player': p['player'],
            'Company': p['company'],
            'Type': p['type'],
            'Accuracy': accuracy,
            'Occurrences': n_occurrences,
            'Gravitas': " | ".join(gravitas_moments) if gravitas_moments else "Consistently moved the stock without hitting 52-week extremes."
        })

    # Output to markdown file
    with open('gravitas_report.md', 'w') as f:
        f.write("# Script Building: The Gravitas of NBA Anomalies\n\n")
        for res in gravitas_results:
            f.write(f"## {res['Player']} -> {res['Company']}\n")
            f.write(f"**The Trigger:** {res['Pattern']}\n")
            f.write(f"**The Result:** {res['Company']} stock GOES {res['Type']}\n")
            f.write(f"**The Math:** {res['Accuracy']:.1f}% Accuracy over {res['Occurrences']} games.\n")
            f.write(f"**The Gravitas (Script Gold):**\n")
            for moment in res['Gravitas'].split(' | '):
                f.write(f"- {moment}\n")
            f.write("\n---\n\n")

    print("Gravitas Report Generated successfully!")

if __name__ == "__main__":
    run_gravitas_miner()
