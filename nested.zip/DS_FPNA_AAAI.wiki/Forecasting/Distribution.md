### **1. Overview**
----------------

The **Distribution Module** is a critical part of the forecasting pipeline that quantifies uncertainty and variability around forecasted KPIs. While models provide a single _expected_ value (point forecast), this module helps answer the deeper question — _“What is the range of possible outcomes, and how likely are they?”_

It achieves this using a **data-driven probabilistic approach** that combines **bootstrapping, residual analysis, and Kernel Density Estimation (KDE)**. The module leverages residuals from validation and test phases — essentially capturing historical forecast error patterns — and applies them to point forecasts to simulate a large number of possible future scenarios. This creates an ensemble of outcomes that reflect the real uncertainty embedded in the forecasting process.

Each simulated set of outcomes is then analyzed statistically to estimate **confidence intervals** corresponding to user-specified sigma levels (e.g., ±1σ, ±2σ, ±3σ). These become the upper and lower forecast bounds. For example, a ±2σ interval represents approximately a 95% confidence level — showing the likely range within which the true KPI value will fall.

Beyond numeric bounds, the module visualizes the distribution of simulated forecasts using **KDE plots**. These plots display the density and spread of simulated KPI outcomes, giving an intuitive view of uncertainty. A narrow, symmetrical KDE curve indicates stable and confident forecasts, while wider or skewed distributions signal greater uncertainty or bias.
A key feature is its integration of **probability range estimation** based on user inputs. The file `Probability Ranges User Input.xlsx` defines numerical thresholds or performance targets for each KPI — for example, sales > ₹10 Cr, margin > 20%, etc. These raw numeric cut-offs are then plotted on the KDE distribution for the corresponding KPI. The module calculates the **proportion of simulated outcomes that exceed (or meet) these thresholds**, producing an **empirical probability of achieving that performance level**.

For instance, if 72 out of 100 bootstrap simulations for a KPI exceed the “target” value specified in the Excel input, the module reports a **72% probability** of achieving or surpassing that target. This bridges the gap between statistical forecasts and business interpretation — allowing stakeholders to see, in quantifiable terms, _“What’s the chance we’ll hit our growth target?”_

The system supports both **short-term** and **long-term** analysis tracks, ensuring flexibility across different forecast horizons. Each experiment automatically generates plots, tables, and logs under a standardized folder structure for full traceability.

### 2. **Folder Structure**
----------------

```
distribution/
│
├── main.py                          # Entry point for the module
├── long_term.py                     # Long-term (LT) forecast distribution logic
├── short_term.py                    # Short-term (ST) forecast distribution logic
├── utility.py                       # Common helper functions for filtering, KDE, bootstrapping, plotting, etc.
├── logger.py                        # Centralized logging utility
├── config.json                      # Configuration parameters
├── environment.yml                  # Environment dependencies
│
├── input_tables/
│   ├── Div-KPI Mapping.xlsx
│   └── Probability Ranges User Input.xlsx
│
└── plots/                           # Output KDE plots and probability visualizations
```

### 3. **Core Functionality**
---------------------

| Stage | Description |
| --- | --- |
| **1. Input & Config Load** | Reads configuration, raw forecast data, and mapping inputs. |
| **2. Residual Processing** | Collects and analyzes residuals (actual - predicted). |
| **3. Bootstrapping Simulation** | Generates multiple simulated forecasts using residual resampling. |
| **4. Distribution Estimation** | Calculates KPI-level upper/lower bounds for defined sigma levels. |
| **5. KDE Plotting** | Produces visual probability distributions for each KPI. |
| **6. Growth Probability Estimation** | Classifies KPIs based on user-defined probability thresholds. |
| **7. Output Generation** | Exports plots, summaries, and logs to organized folders. |

### 4. **Configuration (config.json)**
-------------------------------

The configuration file drives the module’s behavior dynamically:

| Key | Description |
| --- | --- |
| `data_folder` | Path for all Excel/CSV inputs |
| `model_version` | Version tag of the model (e.g., v1.0) |
| `run_date` | Execution reference date (YYYY-MM-DD) |
| `sigma_levels` | Confidence sigma levels for interval generation (e.g., [1,2,3]) |
| `n_bootstrap` | Number of bootstrap samples for residual simulation |
| `random_state` | Seed for reproducibility |
| `distribution_folder` | Output directory for plots |
| `residual_data_table` | Path to residual data file (actuals - predictions) |
| `calculated_output_kpi_table` | Processed KPI output table |
| `calculated_output_ba_table` | Business-area level results |
| `quarterly_residual_table` | Residuals at quarterly horizon |
| `raw_data` | Original KPI input data |
| `business_rolling_forecast` | Rolling forecast Excel file |
| `STORAGE_ACCOUNT_NAME`, `CONTAINER_NAME` | Azure Blob Storage connection parameters |

### 4. **Component-wise Summary**
--------------------------

### 4.1. **logger.py**

Initializes and configures the project-wide logger.  
Creates timestamped logs for every major step (debug, info, warning, error).  
Ensures traceability of every KPI/mgmt combination.

### 4.2. **utility.py**

A reusable helper module containing functions for:
*   **filter_residual_data()** → filters residuals by KPI, mgmt, forecast type, etc.
    
*   **get_forecast_interval_and_plot()** → performs bootstrapping using residuals to create multiple simulated forecasts, fits KDE, and plots confidence bands.
    
*   **compute_growth_probabilities()** → computes empirical probability of achieving certain user-specified thresholds or YoY growth targets.
    
*   Handles percentile computations, sigma-based intervals, and output DataFrame generation.

### 4.3. **long_term.py**

Core of the **Long-Term (LT)** distribution logic:
*   **filter_lt_forecast_data()** filters forecast residuals for the required horizon (Q+1 to Q+4 months).
    
*   **previous_year_total()** computes the prior year’s KPI total for comparison and growth analysis.
    
*   **business_rolling_forecast()** extracts relevant business forecast values and period notations from rolling forecast files.
    
*   **run_distribution()** orchestrates the LT pipeline:
    *   Iterates through all (mgmt, KPI) pairs
        
    *   Selects correct residual tables (Forecasted or Calculated)
        
    *   Generates bootstrapped distributions
        
    *   Produces KDE plots + probability outputs
        
    *   Computes prior year total and growth probabilities
        
Outputs are concatenated and returned as DataFrames:
*   `forecast_interval_results`
    
*   `growth_probability_results`

### 4.4. **short_term.py**

Parallels **long_term.py**, but for **Short-Term (ST)** horizon.  
Uses similar functions with adjusted time frames (usually months or quarters).  
Plots tighter confidence ranges since residual variance is smaller.

### 4.5. **main.py**

Acts as the **entry driver**:
*   Loads the configuration file and environment variables.
    
*   Reads all required input files (actuals, rolling forecasts, residuals, user inputs).
    
*   Invokes both short-term and long-term distribution functions.
    
*   Collects, merges, and stores all outputs (plots, CSVs).
    
*   Pushes final results to Azure Blob Storage for downstream visualization.


### 5. **Data Flow**
::: mermaid
```mermaid
graph TB
    subgraph Input
        A[Residual Data - Test and Val]
        B[Filter Residual Data]
    end

    subgraph Processing
        C[Bootstrapping:100 Samples]
        E[KDE Fit and Bounds]
        F[Growth Probabilities]
        G[Compute UB & LB and Probs]
    end

    subgraph Output
        H[Output Tables and Plots]
    end

    A --> B --> C --> E --> F --> G --> H
```
:::



### 6. **Probability and Growth Logic**
----------------------------

### **Bootstrapping**

*   Residuals from validation/test periods are sampled with replacement.
    
*   Each sample is added to the point forecast to generate multiple possible outcomes.
    
*   This forms an empirical distribution for each KPI’s forecast.
    

### **KDE Plotting**

*   The simulated data is used to fit a **Kernel Density Estimate** (smooth probability curve).
    
*   Each sigma level (1σ, 2σ, 3σ) defines the lower and upper bounds around the mean.
    
*   Plots are auto-saved under `/plots`.
    

### **User Probability Ranges**

*   _Probability Ranges User Input.xlsx_ contains numeric KPI thresholds.
    
*   During plotting, these values are drawn as vertical lines.
    
*   The module counts the proportion of bootstrap samples **≥ threshold**, giving the **empirical probability**.
    *   Example: if 68 out of 100 samples exceed ₹10 Cr → Probability = 68%.
        
*   These probabilities are logged and stored for reporting.
    
    
### 7. **Outputs**
-----------

| Output Type | Description | Location |
| --- | --- | --- |
| **Forecast Distribution Plots** | KDE plots showing forecast distribution with sigma bands and thresholds | `/plots/<mgmt>_<kpi>_LT.png` |
| **Forecast Interval Data** | Lower, upper, and mean forecast per KPI/mgmt | DataFrame output |
| **Growth Probability Table** | Probabilities of KPI growth | DataFrame output |
| **Log File** | All runtime logs | `all_logs.log` |
| **Azure Upload** | Final combined outputs pushed to Azure Blob | Config-defined container |

### 8. **Key Parameters Summary**
----------------------

| Parameter | Role | Typical Range |
| --- | --- | --- |
| `n_bootstrap` | Number of resampled iterations | 100–1000 |
| `sigma_levels` | Confidence multipliers for bounds | [1,2,3] |
| `run_date` | Anchor forecast start date | Quarterly start (Jan, Apr, Jul, Oct) |
| `residual_flag` | Indicates which residual dataset to use | Forecasted / Calculated |

### 9. **Summary**
-------

The **Distribution module** transforms deterministic model forecasts into actionable probabilistic insights.  

It bridges the gap between _model accuracy_ and _business confidence_, enabling clear communication of uncertainty, target probabilities, and expected ranges — all while maintaining full traceability and automation across both **short-term** and **long-term** forecast horizons.
