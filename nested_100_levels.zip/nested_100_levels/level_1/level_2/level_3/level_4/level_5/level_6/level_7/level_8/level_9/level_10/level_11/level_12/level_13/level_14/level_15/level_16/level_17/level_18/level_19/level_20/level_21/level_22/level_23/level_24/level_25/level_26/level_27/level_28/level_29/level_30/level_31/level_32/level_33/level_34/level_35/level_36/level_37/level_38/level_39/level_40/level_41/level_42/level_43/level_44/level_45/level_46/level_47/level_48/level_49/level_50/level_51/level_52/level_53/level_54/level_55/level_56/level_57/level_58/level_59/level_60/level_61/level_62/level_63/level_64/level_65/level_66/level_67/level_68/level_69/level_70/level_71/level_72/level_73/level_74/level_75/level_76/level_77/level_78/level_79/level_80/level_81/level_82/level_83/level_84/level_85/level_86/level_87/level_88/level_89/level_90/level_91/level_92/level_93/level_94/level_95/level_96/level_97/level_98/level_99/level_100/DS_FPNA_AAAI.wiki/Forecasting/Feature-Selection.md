**Module Location:**  
`forecasting/feature_selection/`

The **Feature Selection module** is designed to identify the most relevant features for each forecasting target while minimizing redundancy and instability.
  
It integrates multiple methods that capture different aspects of variable importance — from simple correlations to model-driven predictiveness — ensuring both statistical and practical relevance.

The **Feature Selection Methods** component employs a suite of techniques including:
*   **Pearson Correlation** – measures the linear association between each feature and the target variable.
    
*   **Spearman Correlation** _(optional)_ – evaluates rank-based monotonic relationships, useful when the data contains nonlinear but ordered patterns.
    
*   **Mutual Information Score (MI)** – quantifies the dependency between features and the target beyond linearity, capturing both linear and nonlinear relationships.
    
*   **Predictive Power Score (PPS)** – evaluates how well a feature can predict the target using a decision-tree-based predictive model; ideal for complex dependencies where correlation is insufficient.
    
These methods collectively produce a weighted assessment of feature importance.  

The module then filters features based on statistical thresholds, lags, and configuration rules (e.g., excluding rolling or seasonal derived variables, enforcing lag windows, and applying feature grouping rules).

After selection, the filtered dataset is optionally passed to the **Data Drift Methods** submodule.  

This submodule ensures temporal stability of the chosen features by identifying potential drifts or structural changes in their statistical distribution over time.  
It supports:
*   **ADWIN (Adaptive Windowing)** – a streaming algorithm that detects changes in the mean of a signal.
    
*   **Ruptures-based Change Point Detection** – uses kernel-based segmentation (e.g., RBF) to identify shifts in data behavior.
    
*   **Domain Classifier Method** – trains a lightweight classifier to distinguish between pre- and post-period data; a high AUC indicates drift.
    
By combining feature selection with drift detection, the module ensures that only **stable and predictive features** are used downstream for model training, improving both performance and robustness.

### **Overall flow of module**:

::: mermaid
 graph TD
    A[new_config]
    B[run_fs]
    C[Wrapper]
    D[FeatureSelection]
    E[FeatureSelectionMethods]
    F[FeatureSelectionProcessor]
    G[DataDriftProcessor]
    H[FilteredFeatures]
    I[Logs]
    J[IntermediateResults]
    K[FinalResults]
    L[DataDriftMethods]

    A --> B
    B --> C
    C --> D
    D --> E
    E --> F
    F --> H
    H --> J
    H --> K
    H -->|if use_data_drift:true|L
    L --> G
    G --> J
    G --> K
    G --> I

:::


Configuration (new_config.json)
----------------------------------

| Key | Description |
| --- | --- |
| `input_path`, `output_path` | Directory paths for input and output data |
| `experiment_name` | Name used to create folder hierarchy under `output_path` |
| `date_range` | Range of dates used to filter data |
| `modelling_levels` | Defines hierarchical grouping for model combinations |
| `filter_on_modelling_levels` | Filters input data on allowed modelling level values |
| `feature_selection_config.input_file_name` | Name of the Excel file containing treated data |
| `target_columns` | List of target variables for which features will be selected |
| `use_specific_feature_sets_enabled` | If `true`, feature sets are specified in `target_feature_explore_dict` |
| `feature_selection_methods_config` | Controls parameters and algorithms used for feature selection |
| `data_drift_methods_config` | Controls drift detection algorithms and thresholds |
| `use_data_drift` | Enables/disables data drift detection after feature selection |


Example:

`"feature_selection_config": {   "input_file_name": "treated_data_2506",   "column_loop_in_wrapper": true,   "target_columns": ["base_orders_net"],   "use_specific_feature_sets_enabled": true,   "use_data_drift": true,   "feature_selection_methods_config": {       "pearson_enabled": true,       "mutual_information_score_enabled": true,       "predictive_power_score_enabled": true   } }`

**Execution Flow**

### 1. **Entry Point — run_fs.py**

Located at root:

`combs = Wrapper('feature_selection', config_dict).run() 
featureselection_module = modules_metadata.get_module_from_name('feature_selection', full_config=config_dict) 
featureselection_module.run(combs)`

*   Loads configuration (`new_config.json`)
    
*   Initializes the wrapper to preprocess and structure data
    
*   Triggers the `FeatureSelection` module execution

### 2. **Wrapper Layer (forecasting_utils/wrapper.py)**

**Responsibilities:**
*   Reads and validates configuration
    
*   Loads input Excel data
    
*   Filters by date range and modelling levels
    
*   Groups data by modelling level and date
    
*   Builds per-combination datasets (`all_combs`)
    
**Output:**  
Dictionary →  
`{ "combination_name____target": DataFrame_with_target_and_features }`

### 3. **FeatureSelection (feature_selection/main.py)**

**Responsibilities:**
*   Initializes the `FeatureSelectionMethods` module
    
*   Runs all feature selection algorithms
    
*   Retrieves filtered datasets
    
*   If configured, triggers **DataDriftMethods** for post-selection drift analysis
    
`feature_selection = FeatureSelectionMethods(self.full_config)
feature_selection_results = feature_selection.run(all_combs) 
filtered_dfs = feature_selection_results["filtered_dataframes"]`


### 4. **FeatureSelectionMethods (feature_selection/feature_selection_methods/main.py)**

**Responsibilities:**
*   Prepares output directories and logging
    
*   Passes configuration to `FeatureSelectionMethodsProcessor`
    
*   Executes feature selection algorithms (Pearson, MI, PPS, etc.)
    
*   Returns filtered features and metadata

### 5. **DataDriftMethods (feature_selection/data_drift_methods/main.py)**

**Responsibilities:**
*   Detects data drift between baseline and recent data windows
    
*   Supports multiple methods (`adwin`, `ruptures`, `domain classifier`)
    
*   Reports drift alerts when multiple methods confirm a drift
    
*   Controlled by `use_data_drift` flag in configuration

Supporting Utilities
-----------------------

###  **FileHandler**

`core/forecasting_utils/file_handler.py`
*   Creates folder structures for experiments (`logs`, `intermediate`, `final_results`)
    
*   Handles reading and writing of Excel and JSON files
    
*   Ensures clean sheet naming and directory safety
    

###  **Logger**

`core/forecasting_utils/logger.py`
*   Unified logging handler for both console and file output
    
*   Each module logs to its own file under `<experiment_name>/logs/`


###  **Inputs**

`input/treated_data_2506.xlsx`

* In the input folder, place the input data that is output of `data prep module`, for example `treated_data_2506.xlsx`.

###  **Outputs**

| Folder | Description |
| --- | --- |
| `intermediate/` | Intermediate computation files (optional saves) |
| `logs/` | Text logs for Wrapper, FeatureSelection, and submodules |
| `final_results/` | Final selected feature sets and drift reports |


Folder Structure (Auto-created per experiment)
-------------------------------------------------

```
output/
└── feature_selection/
    ├── ABB_feature_selection_test/
    └── ELSB_base_orders_long_term/
        ├── final_results/
        │   └── consolidated_final_features.json
        │
        ├── intermediate/
        │   ├── detailed_data_drift_results.xlsx
        │   ├── detailed_feature_selection_results.xlsx
        │   └── selected_kpis_from_feature_selection.json
        │
        └── logs/
            ├── data_drift_methods.txt
            ├── data_drift_methods_processor.txt
            ├── feature_selection.txt
            ├── feature_selection_methods.txt
            ├── feature_selection_methods_processor.txt
            └── feature_selection_wrapper.txt
```

Example End-to-End Run
----------------------

`python run_fs.py`

### Log Output (Excerpt)

`2025-11-04 10:15:03 - feature_selection - INFO - Feature Selection Started 2025-11-04 10:15:10 - feature_selection_methods - INFO - Running Pearson and MI selection 2025-11-04 10:15:42 - feature_selection - INFO - Data drift detection is enabled. 2025-11-04 10:15:55 - data_drift_methods - INFO - Drift detected in 2 of 3 methods for 'base_orders_net' 2025-11-04 10:15:57 - feature_selection - INFO - Feature Selection Completed`

Key Configuration Flags
--------------------------

| Flag | Type | Default | Description |
| --- | --- | --- | --- |
| `use_specific_feature_sets_enabled` | bool | false | Uses custom feature sets per target if true |
| `use_data_drift` | bool | true | Enables data drift detection |
| `column_loop_in_wrapper` | bool | true | Iterates through each target column separately |
| `pearson_enabled`, `mutual_information_score_enabled`, etc. | bool | — | Enables/disables feature selection methods |
| `lag_min`, `lag_max` | int | 0 | Lag creation for time-based features |
| `confidence_interval` | int | 95 | Statistical confidence for permutation testing |

Summary
-------

| Component | Role |
| --- | --- |
| **Wrapper** | Prepares modelling-level datasets |
| **FeatureSelection** | Orchestrates selection and drift steps |
| **FeatureSelectionMethods** | Runs feature selection algorithms |
| **DataDriftMethods** | Detects temporal feature drift |
| **FileHandler & Logger** | Handle structure and tracking |
| **Config (new_config.json)** | Drives all behavior end-to-end |