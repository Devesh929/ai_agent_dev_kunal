# Access Approval Process
1. Mail request to AAAI-MLOPS-DEVELOPERS@abb.com for **Azure DevOps Boards** and **common group access**.
2. Task on Azure DevOps boards for **Repository** and **Workspace Access**.

# Onboarding Steps
1. Add resource to "AAAI-FPNA-MEMBERS" on [Microsoft Entra admin center](https://entra.microsoft.com/#home).
_This gives read access to Azure DevOps boards and Subscription resources._
2. Add resource to Azure DevOps Organization.
Organization settings > Users > Add user.
3. Add resource to project data science team.
DS_FPNA_AAAI > Project settings > Teams > DS_FPNA_AAAI Team > Add
_This gives user access to the DevOps boards and other components (except repositories)._
4. Add resource to squad group based on capabilities mentioned in the Azure Boards task.
_This gives user access to the respective capability repositories._
5. Add resource to the Entra group(s) from [Microsoft Entra admin center](https://entra.microsoft.com/#home) based on capabilities mentioned in the Azure Boards task.
Example - Forecasting: "AAAI-FORECASTING-DS_DEVELOPERS"
_This gives access to capability related resources on Azure subscription._
6. Create a personal compute instance for the resource on the Azure ML workspace mentioned in the Azure Boards task.
Naming convention: <u>ci-<user-short-name>-01-<capability-short-name></u> . Example: ci-inutpra-01-for
Assign compute instance to the resource during setup configuration.
Assign a user assigned managed identity (<u>mi-dev-aaai-<capability-short-name>computes</u> to the instance during setup configuration. Note: This managed identity has the following IAM roles: 
    
    - storage blob data reader (on AML workspace default storage account)
    - storage blob data reader (on AML workspace default storage account)
    - storage file data privileged contributor (on AML workspace default storage account)
    - AzureML Data Scientist (on AML workspace)
    - storage blob data reader (on common data input container)