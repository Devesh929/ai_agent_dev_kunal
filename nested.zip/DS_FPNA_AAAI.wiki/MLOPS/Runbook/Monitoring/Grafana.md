## Objective
The objective here is to set up Grafana and add loki, tempo, pyroscope and prometheus as data source. Grafana is a great tool to visualize logs metrics. Also how to set up alert in grafana.

---
## Pre-requisite
- Tempo
- Loki
- Prometheus
- Pyroscope

---
## Steps
Azure offers a managed grafana service so we do not need to deploy it in any cluster or separately.

1. In azure portal, search for _**Azure Managed Grafana**_.
2. Click the **+ Create** button to create the grafana workspace.
3. In Basic tab, select the resource group, and assign a name.
4. In permission, tab you can assign the user admin right if you need, or you can do this afterwards in the Access control tab.

---
## Connection Data Source

1. Open the grafana workspace (does not open on ABB network)
2. Go to the connection tab in the left had menu
3. Select **Add New Connection**.

- ### Loki
  1. Search for _**LOKI**_.
  2. Click _**Add new data source**_
  3. In URL, enter the Loki distributed svc external IP.
  4. in Authentication, select Basic auth.
  5. Enter the Username and password.
  6. **Also, do not forget add the HTTP 'X-Scope-OrgId' header, else you would not be able to connect to loki**
  7. Click _**Save & test**_

- ### Prometheus
  1. Search for **_Prometheus_**
  2.  Click _**Add new data source**_ 
  3. In the monitor workspace attached to the prometheus open the workspace.
  4. Copy the query endpoint.
  5. In the URL, enter this query endpoint.
  6. In auth, select _**Azure auth**_
  7. Select Managed Identity
  8. Click _**Save & test**_

- ### Tempo
  1. Search for _**Tempo**_
  2. Click _**Add new data source**_
  3. In URL, enter the query frontend external IP
  4. Click _**Save & test**_

- ### Pyroscope
  1. Search for **_Pyroscope_**
  2. Enter the Pyroscope external IP.
  3. Click _**Save & test**_
  4. To have the profiling data, go to the data connection of tempo and go to the Trace to profiles section add the Pyroscope data source there and select the profile type.
  5. Click _**Save & test**_
---
## Setting up alert in grafana
We can set up alert in grafana in case an error is captured in a job or on some metric we can get an alert in team channel or any other platform we configure for. here we have configured for teams channel.
- Just have the channel webhook ready.
  1. In channel, select the "...".
  2. Select _**Manage Channel**_, in the connector section select _**Edit**_
  3. In the pop up, click **_Confgiure_** on the incoming webhook.
  4. assign it a name and click create a webhook would e generated.
- Select the _**ALert rules**_ option under the Alerting option in the left side menu.
- Click _**New Alert Rule**_
- Give it a name.
- Select the connection in _**Define query and alert condition**_
- then write the condition for alert
- Select a folder for the alert
- In evaluation behavior select a period
- For Configuration notification section in the contact point select _**teams**_
- If you do not have a contact point configured select the _**View or create contact points**_.
  1. There select the _**Create Contact point**_ option
  2. Assign a name to the connection.
  3. select microsoft teams in integration dropbox.
  4. Click _**Save contact point**_
- Click _**Save rule and exit**_

This should configure an alert to be sent in case the condition matches