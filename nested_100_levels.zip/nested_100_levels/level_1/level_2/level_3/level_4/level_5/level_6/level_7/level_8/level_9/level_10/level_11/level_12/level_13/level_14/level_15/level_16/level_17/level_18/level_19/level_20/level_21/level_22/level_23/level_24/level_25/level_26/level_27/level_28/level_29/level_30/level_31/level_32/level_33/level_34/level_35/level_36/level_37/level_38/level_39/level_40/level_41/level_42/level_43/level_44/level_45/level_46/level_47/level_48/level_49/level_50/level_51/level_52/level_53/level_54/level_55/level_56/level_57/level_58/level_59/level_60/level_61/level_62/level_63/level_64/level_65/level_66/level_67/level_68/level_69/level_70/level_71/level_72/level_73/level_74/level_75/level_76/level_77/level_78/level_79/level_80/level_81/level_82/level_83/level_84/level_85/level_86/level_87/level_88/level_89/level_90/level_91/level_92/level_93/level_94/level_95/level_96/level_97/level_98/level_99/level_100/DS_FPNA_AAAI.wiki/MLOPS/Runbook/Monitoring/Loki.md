## Objective
The objective here is to set up Loki for storing logs from projects or experiments. Loki makes it easy to send logs and query them.

---
## Pre-requisites
- EntraID app
- Storage account
- Azure CLI
- YAML
- AKS
- Kubernetes
---
## Steps
These steps are to set up Loki in an AKS cluster using a YAML template

### Setting up an AKS Cluster

- If you want to create a Cluster follow the _**Create AKS**_ runbook.

- Bind the cluster to kubectl
```
az aks get-credentials --resource-group <MY_RESOURCE_GROUP_NAME> --name <MY_AKS_CLUSTER_NAME>
```

### Creating Federated Token in EntraId assigning storage blob contributor role
- To Create Federated Token See the **_Create Federated Token_** runbook.
- Assign the **Storage Blob Data Contributor** role to the Entra app
### Deploy helm chart
1. Add the Grafana chart repo to Helm
```
helm repo add grafana https://grafana.github.io/helm-charts
```
2. Update Chart Repo
```
helm repo update
```
3. Create the namespace for loki
```
kubectl create namespace <namespace-name>
```
### Loki basic authentication
Using htpasswd create a .htpasswd file to the add the basic authentication layer to access loki logs
from grafana with a User ID and password
1. Create the .htpasswd file
```
htpasswd -c .htpasswd <username>
```
2. When prompted add the password.
3. Create the secret in kubernetes
```
 kubectl create secret generic loki-basic-auth --from-file=.htpasswd -n <namespace>
```
4. Also create a canary basic auth to for allowing traffic within use the same username and password.
```
kubectl create secret generic canary-basic-auth --from-literal=username=<USERNAME> --from-literal=password=<PASSWORD> -n <namespace>
```
### Deploying Loki in kubernetes as a microservice
1. To deploy kubernetes use this template of YAML
`#` Make sure you have a Chunk container and ruler container created in the storage account
```
loki:
   podLabels:
    "azure.workload.identity/use": "true" # Add this label to the Loki pods to enable workload identity
   schemaConfig:
     configs:
       - from: "2024-04-01"
         store: tsdb
         object_store: azure
         schema: v13
         index:
           prefix: loki_index_
           period: 24h
   storage_config:
     azure:
      account_name: "<INSERT-STORAGE-ACCOUNT-NAME>" 
      container_name: "<CHUNK-CONTAINER-NAME>" # Your actual Azure Blob Storage container name (loki-azure-dev-chunks)
      use_federated_token: true # Use federated token for authentication
   ingester:
       chunk_encoding: snappy
   pattern_ingester:
       enabled: true
   limits_config:
     allow_structured_metadata: true
     volume_enabled: true
     retention_period: 672h # 28 days retention
   compactor:
     retention_enabled: true 
     delete_request_store: azure
   ruler:
    enable_api: true
    storage:
      type: azure
      azure:
        account_name: <INSERT-STORAGE-ACCOUNT-NAME>
        container_name: <RULER-CONTAINER-NAME> # Your actual Azure Blob Storage container name (loki-azure-dev-ruler)
        use_federated_token: true # Use federated token for authentication
      alertmanager_url: http://prom:9093 # The URL of the Alertmanager to send alerts (Prometheus, Mimir, etc.)

   querier:
      max_concurrent: 4

   storage:
      type: azure
      bucketNames:
        chunks: "<CHUNK-CONTAINER-NAME>" # Your actual Azure Blob Storage container name (loki-azure-dev-chunks)
        ruler: "<RULER-CONTAINER-NAME>" # Your actual Azure Blob Storage container name (loki-azure-dev-ruler)
        # admin: "admin-loki-devrel" # Your actual Azure Blob Storage container name (loki-azure-dev-admin)
      azure:
        accountName: <INSERT-STORAGE-ACCOUNT-NAME>
        useFederatedToken: true # Use federated token for authentication

# Define the Azure workload identity
serviceAccount:
  name: loki
  annotations:
    "azure.workload.identity/client-id": "<APP-ID>" # The app ID of the Azure AD app
  labels:
    "azure.workload.identity/use": "true"

deploymentMode: Distributed

ingester:
 replicas: 3
 zoneAwareReplication:
  enabled: false

querier:
 replicas: 3
 maxUnavailable: 2

queryFrontend:
 replicas: 2
 maxUnavailable: 1

queryScheduler:
 replicas: 2

distributor:
 replicas: 3
 maxUnavailable: 2
compactor:
 replicas: 1

indexGateway:
 replicas: 2
 maxUnavailable: 1

ruler:
 replicas: 1
 maxUnavailable: 1


# This exposes the Loki gateway so it can be written to and queried externaly
gateway:
 service:
   type: LoadBalancer
 basicAuth: 
     enabled: true
     existingSecret: loki-basic-auth

# Since we are using basic auth, we need to pass the username and password to the canary
lokiCanary:
  extraArgs:
    - -pass=$(LOKI_PASS)
    - -user=$(LOKI_USER)
  extraEnv:
    - name: LOKI_PASS
      valueFrom:
        secretKeyRef:
          name: canary-basic-auth
          key: password
    - name: LOKI_USER
      valueFrom:
        secretKeyRef:
          name: canary-basic-auth
          key: username

# Enable minio for storage
minio:
 enabled: false

backend:
 replicas: 0
read:
 replicas: 0
write:
 replicas: 0

singleBinary:
 replicas: 0
```
2. Deploy Loki
```
helm install --values values.yaml loki grafana/loki -n <namespace> --create-namespace
```

```
kubectl apply -f values.yaml -n <namespace>
```

3. Get the external IP of the loki-gateway service and use these to send logs to loki.
```
kubectl get svc -n <namespace>
```

### Sending logs to loki

to send logs to loki use this code

```Python
import logging

import time

import requests

import json

import os

  
  

class LokiHandler(logging.Handler):

    def __init__(self, url, labels, username=None, password=None, org_id="foo"):

        super().__init__()

        self.url = url

        self.auth = (username, password) if username and password else None

        self.headers = {

            "Content-Type": "application/json",

            "X-Scope-OrgId": org_id

        }

        self.labels = labels

  

    def emit(self, record):

        log_entry = self.format(record)

        timestamp = str(int(time.time() * 1e9))

  

        payload = {

            "streams": [

                {

                    "stream": self.labels,

                    "values": [[timestamp, log_entry]]

                }

            ]

        }

  

        try:

            requests.post(

                self.url,

                headers=self.headers,

                auth=self.auth,

                data=json.dumps(payload),

                timeout=2

            )

        except Exception as e:

            print(f"[LokiHandler] Failed to send log: {e}")

  
  

class LoggingLoki():

    def __init__(self, labels={"job": "test-job"}):

        self.logger = logging.getLogger("tes-pipeline")

        self.logger.setLevel(logging.DEBUG)

  

        loki_handler = LokiHandler(

            url="http://<LOKI_GATEWAY_EXTERNAL_IP>/loki/api/v1/push",

            labels=labels,

            username="<USER_NAME>",

            password="<USER_PASSWORD>",

            org_id="<ORG_ID>",

        )

        loki_handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))

        self.logger.addHandler(loki_handler)

  
  

logging = LoggingLoki(labels={"job": "test-job", "target": "alert-test", "model": "alert-test", "modelling_level": "alert-test"})

logger = logging.logger

logger.error(f"partition task created for modelling level: alert-test")
```

---
_see the grafana run book to see how to make connection_
