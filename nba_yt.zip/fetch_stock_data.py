import yfinance as yf
import pandas as pd
import os
import requests
import ssl_patch

ssl_patch.apply_patch()

def fetch_sp500_tickers():
    print("Fetching S&P 500 tickers from Wikipedia...")
    url = 'https://en.wikipedia.org/wiki/List_of_S%26P_500_companies'
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'}
    import io
    response = requests.get(url, headers=headers)
    tables = pd.read_html(io.StringIO(response.text))
    df = tables[0]
    tickers = df['Symbol'].tolist()
    # Replace dots with hyphens for yfinance (e.g. BRK.B -> BRK-B)
    tickers = [ticker.replace('.', '-') for ticker in tickers]
    return tickers

def fetch_stock_data():
    os.makedirs('data', exist_ok=True)
    
    tickers = fetch_sp500_tickers()
    # Add major indices
    tickers.extend(['^GSPC', '^IXIC', '^DJI']) # S&P 500, Nasdaq, Dow Jones
    
    print(f"Fetching historical data for {len(tickers)} tickers from 2012 to 2026...")
    
    # yfinance can download multiple tickers at once efficiently
    # However, sometimes it fails for delisted stocks if we just use the current S&P 500 list,
    # but since we are looking for patterns, current S&P 500 is a good proxy.
    
    # We will use yf.download
    # To save space and make it easier to align, we'll download all at once and save as parquet or csv
    # yf.download returns a multi-index dataframe. We will stack it.
    
    data = yf.download(tickers, start='2012-01-01', end='2026-12-31', group_by='ticker', auto_adjust=True, threads=True)
    
    # The dataframe has tickers as the top level of columns, and Price (Open, High, Low, Close, Volume) as second level.
    # We want a format like: Date, Ticker, Open, High, Low, Close, Volume
    
    print("Processing and formatting stock data...")
    # Stack the dataframe to get tickers as a column
    df_stacked = data.stack(level=0, future_stack=True).reset_index()
    df_stacked.rename(columns={'level_1': 'Ticker'}, inplace=True)
    
    # Clean up column names if needed
    df_stacked = df_stacked[['Date', 'Ticker', 'Open', 'High', 'Low', 'Close', 'Volume']]
    
    # Save to CSV
    output_file = 'data/sp500_stock_data_2012_2026.csv'
    df_stacked.to_csv(output_file, index=False)
    print(f"Saved stock data to {output_file}. Total rows: {len(df_stacked)}")

if __name__ == "__main__":
    fetch_stock_data()
