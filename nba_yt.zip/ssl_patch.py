import ssl
import urllib3
import requests
import warnings

def apply_patch():
    # Ignore warnings
    warnings.filterwarnings('ignore')
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
    
    # Global SSL unverified context
    ssl._create_default_https_context = ssl._create_unverified_context
    
    # Patch requests.Session.request
    original_request = requests.Session.request
    
    def request_with_no_verify(*args, **kwargs):
        kwargs['verify'] = False
        return original_request(*args, **kwargs)
        
    requests.Session.request = request_with_no_verify
    
    print("SSL Verification Disabled globally for requests.")
