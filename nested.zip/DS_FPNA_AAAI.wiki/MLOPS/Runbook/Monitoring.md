## Objective

The purpose of this POC here is to set up a complete monitoring pipeline for the **Data Science** projects. making them easy to use and implement.
Here we will set up 5 components which are:

- **Loki** for logs
- **Prometheus** for metrics
- **Tempo** for traces
- **Pyroscope** for profiling
- **Grafana** for visualization

also other than these components we will be setting up an alert manager such that an alert is sent when an error is detected in the pipeline

## Pre-requisites
- Azure CLI
- Kubernetes
- Azure storage account
- EntraID