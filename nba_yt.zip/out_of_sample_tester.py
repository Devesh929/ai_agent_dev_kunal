import pandas as pd
import numpy as np

def run_out_of_sample():
    print("Loading data for 2025-2026 Out-Of-Sample Test...")
    try:
        players = pd.read_csv('data/nba_player_logs_2012_2026.csv')
        teams = pd.read_csv('data/nba_team_logs_2012_2026.csv')
        stocks = pd.read_csv('data/sp500_stock_data_2012_2026.csv')
    except Exception as e:
        print(f"Error loading data: {e}")
        return

    # Isolate 25-26 Season Data for Out-Of-Sample
    players['GAME_DATE'] = pd.to_datetime(players['GAME_DATE']).dt.tz_localize(None)
    stocks['Date'] = pd.to_datetime(stocks['Date']).dt.tz_localize(None)
    teams['GAME_DATE'] = pd.to_datetime(teams['GAME_DATE']).dt.tz_localize(None)
    
    # FILTER FOR HOLD-OUT SET (2025-2026 Season starts ~Oct 2025)
    players = players[players['GAME_DATE'] >= '2025-10-01']
    teams = teams[teams['GAME_DATE'] >= '2025-10-01']
    stocks = stocks[stocks['Date'] >= '2025-10-01']
    
    stocks.sort_values(by=['Ticker', 'Date'], inplace=True)
    stocks['Pct_Change'] = stocks.groupby('Ticker')['Close'].pct_change() * 100
    stocks['Went_Up'] = stocks['Pct_Change'] > 0
    stocks['Went_Down'] = stocks['Pct_Change'] < 0

    famous_tickers = {
        'TSLA': 'Tesla', 'AAPL': 'Apple', 'MSFT': 'Microsoft', 'AMZN': 'Amazon',
        'NFLX': 'Netflix', 'META': 'Meta', 'KO': 'Coca-Cola', 'MCD': 'McDonalds',
        'SBUX': 'Starbucks', 'NKE': 'Nike', 'DIS': 'Disney'
    }
    stocks = stocks[stocks['Ticker'].isin(famous_tickers.keys())]

    stock_dates = sorted(stocks['Date'].unique())
    stock_date_df = pd.DataFrame({'Stock_Date': stock_dates})
    
    def get_next_trading_day(game_date):
        future = stock_date_df[stock_date_df['Stock_Date'] > game_date]
        if not future.empty:
            return future.iloc[0]['Stock_Date']
        return pd.NaT

    unique_game_dates = pd.DataFrame({'GAME_DATE': players['GAME_DATE'].unique()})
    unique_game_dates['Next_Trading_Date'] = unique_game_dates['GAME_DATE'].apply(get_next_trading_day)
    players = pd.merge(players, unique_game_dates, on='GAME_DATE', how='left')

    events = []
    print("Generating major events on out-of-sample data...")
    
    famous_players = [
        "LeBron James", "Stephen Curry", "Kevin Durant", "Giannis Antetokounmpo", 
        "James Harden", "Luka Doncic", "Nikola Jokic", "Devin Booker", "Jayson Tatum", "Joel Embiid"
    ]
    
    for _, row in players.iterrows():
        p_name = row['PLAYER_NAME']
        date = row['Next_Trading_Date']
        if pd.isna(date): continue
            
        pts = row['PTS']
        fg3m = row['FG3M']
        tov = row['TOV']
        fga = row['FGA']
        fg_pct = row['FG_PCT']
        
        # We test our top viral hooks
        if p_name in famous_players:
            if pts >= 40: events.append({'Date': date, 'Event': f"{p_name} scores 40+"})
            if fg3m >= 8: events.append({'Date': date, 'Event': f"{p_name} hits 8+ Threes"})
            if tov >= 7: events.append({'Date': date, 'Event': f"{p_name} turns the ball over 7+ times"})
            if fga >= 28: events.append({'Date': date, 'Event': f"{p_name} is a ball hog (takes 28+ shots)"})
            if fga >= 18 and fg_pct <= 0.35: events.append({'Date': date, 'Event': f"{p_name} shoots terribly (<35% on 18+ shots)"})

    # Clutch team games
    game_matchups = pd.merge(teams, teams, on='GAME_ID', suffixes=('', '_OPP'))
    game_matchups = game_matchups[game_matchups['TEAM_NAME'] != game_matchups['TEAM_NAME_OPP']]
    game_matchups['Margin'] = game_matchups['PTS'] - game_matchups['PTS_OPP']
    game_matchups['Next_Trading_Date'] = game_matchups['GAME_DATE'].apply(get_next_trading_day)
    for _, row in game_matchups.iterrows():
        t_name = row['TEAM_NAME']
        date = row['Next_Trading_Date']
        if pd.isna(date): continue
        if row['Margin'] in [1, 2, 3]: events.append({'Date': date, 'Event': f"The {t_name} win a nail-biter clutch game (by 1-3 pts)"})
        if row['Margin'] >= 30: events.append({'Date': date, 'Event': f"The {t_name} destroy an opponent by 30+"})

    events_df = pd.DataFrame(events).drop_duplicates()
    
    results = []
    for event_name in events_df['Event'].unique():
        event_dates = events_df[events_df['Event'] == event_name]['Date']
        num_occurrences = len(event_dates)
        
        if num_occurrences < 3: # In a single season, N will be small (3-10)
            continue
            
        for ticker, company_name in famous_tickers.items():
            stock_slice = stocks[(stocks['Ticker'] == ticker) & (stocks['Date'].isin(event_dates))]
            if len(stock_slice) == 0: continue
            
            up_days = stock_slice['Went_Up'].sum()
            down_days = stock_slice['Went_Down'].sum()
            
            up_pct = (up_days / len(stock_slice)) * 100
            down_pct = (down_days / len(stock_slice)) * 100
            
            # We look for patterns that hit 100% or near 100% in the current season
            if up_pct >= 75:
                results.append({
                    'Pattern': f"Whenever {event_name}, {company_name} stock GOES UP! [25-26 Season Proven]",
                    'Accuracy': up_pct,
                    'Occurrences': len(stock_slice),
                })
            elif down_pct >= 75:
                results.append({
                    'Pattern': f"Whenever {event_name}, {company_name} stock CRASHES! [25-26 Season Proven]",
                    'Accuracy': down_pct,
                    'Occurrences': len(stock_slice),
                })

    res_df = pd.DataFrame(results)
    if not res_df.empty:
        res_df.sort_values(by=['Accuracy', 'Occurrences'], ascending=[False, False], inplace=True)
        res_df.to_csv('data/25_26_backtest_results.csv', index=False)
        print("\n=== TOP OUT-OF-SAMPLE (25-26 SEASON) PATTERNS SAVED TO CSV ===\n")
        for _, row in res_df.head(20).iterrows():
            print(f"{row['Pattern']} ({int(row['Accuracy'])}% of the time this season, N={row['Occurrences']})")
    else:
        print("No patterns survived the out-of-sample test with high accuracy.")

if __name__ == "__main__":
    run_out_of_sample()
