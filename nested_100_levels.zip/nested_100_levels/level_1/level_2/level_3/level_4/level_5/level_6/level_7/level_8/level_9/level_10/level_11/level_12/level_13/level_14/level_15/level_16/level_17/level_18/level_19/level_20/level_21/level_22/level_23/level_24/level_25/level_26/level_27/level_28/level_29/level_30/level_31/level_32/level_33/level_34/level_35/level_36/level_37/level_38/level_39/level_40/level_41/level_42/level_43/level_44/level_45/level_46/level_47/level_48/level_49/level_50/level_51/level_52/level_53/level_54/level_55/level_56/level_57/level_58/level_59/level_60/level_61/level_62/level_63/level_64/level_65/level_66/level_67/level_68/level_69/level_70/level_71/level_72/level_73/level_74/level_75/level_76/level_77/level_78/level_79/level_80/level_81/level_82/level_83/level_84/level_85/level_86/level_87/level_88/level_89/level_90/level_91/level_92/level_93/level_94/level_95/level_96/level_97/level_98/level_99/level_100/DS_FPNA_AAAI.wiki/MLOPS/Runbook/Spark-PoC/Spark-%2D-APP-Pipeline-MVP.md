## Process Overview
::: mermaid
graph TB

    %% External nodes (centralized)
    App["Spark Application"]

    %% Kubernetes Cluster
    subgraph KUBERNETES CLUSTER

        %% Central driver node
        subgraph Node1
            Driver["Spark Driver<br>• Data Preprocessing"]
        end

        GroupBy["groupBy on <br> Division + KPI pair"]

        %% Task combinations as per new logic
        Task1["ELDS - Net Orders"]
        Task2["ELSP - Net Orders"]
        Task3["ELSE - Net Orders"]
        Task4["ELSP - Net Revenues"]
        Task5["ELSB - Net Revenues"]
        TaskN["... more Division + KPI pairs ..."]

        %% Executor nodes distributed across nodes
        subgraph Node2
            Exec1["Spark Executor 1<br>• Retraining<br>• Forecasting"]
            Exec2["Spark Executor 2<br>• Retraining<br>• Forecasting"]
            Exec3["Spark Executor 3<br>• Retraining<br>• Forecasting"]
        end

        subgraph Node3
            Exec4["Spark Executor 4<br>• Retraining<br>• Forecasting"]
            Exec5["Spark Executor 5<br>• Retraining<br>• Forecasting"]
        end

        subgraph NodeN
            ExecN["Spark Executor N<br> (Additional combinations)"]
        end
        
        %% Consolidation Job on the same cluster
        subgraph Consolidation-Job
        end
    end

    %% External logging & output
    Storage["Storage Account"]
    MLflow["MLFlow: Azure ML<br> Loki Database: Grafana"]

    %% Flow connections
    App -->|submits to| Driver
    Driver --> GroupBy

    GroupBy --> Task1
    GroupBy --> Task2
    GroupBy --> Task3
    GroupBy --> Task4
    GroupBy --> Task5
    GroupBy --> TaskN

    Task1 --> Exec1
    Task2 --> Exec2
    Task3 --> Exec3
    Task4 --> Exec4
    Task5 --> Exec5
    TaskN --> ExecN

    %% External connections from executors
    Exec1 --> Storage
    Exec1 --> MLflow

    Exec2 --> Storage
    Exec2 --> MLflow

    Exec3 --> Storage
    Exec3 --> MLflow

    Exec4 --> Storage
    Exec4 --> MLflow

    Exec5 --> Storage
    Exec5 --> MLflow

    ExecN --> Storage
    ExecN --> MLflow

    Consolidation-Job --> Storage
    Storage --> Consolidation-Job

:::

1. ## Directory Structure Overview

<pre>├── core/
│   ├── forecasting components/                       # Modular pipeline steps
│   │   ├── preprocessing.py                          # Raw data preprocessing logic
│   │   └── retrain_predict.py                        # Retraining models and forecasting
│   │
│   └── forecasting_utils/                            # Shared utility modules
│       ├── io_utils.py                               # ADLS I/O with Workload Identity
│       ├── logger.py                                 # log handler to post the generated logs to Loki database
│       ├── pipeline.py                               # Orchestrates applyInPandas execution
│       ├── models.py                                 # model classes implemented for forecasting
│       ├── missing_value_utils.py                    # helper function for missing value treatment step
│       ├── outlier_treatment_utils.py                # helper function for outlier treatment step
│       └── preprocess_utils.py                       # Date handling, filtering, etc.
│ 
├── projects/
|   └── EL_order_forecasting/
│       ├── configs/
│       │   ├── spark_app_prod_forecasting.yaml       # Spark job and pipeline configurations
│       │   ├── job_group_watcher.yaml                # Spark job for result consolidation
│       │   ├── app_submit_jobs.sh                    # Single shell script to submit APP pipeline and result consolidation job
│       │   └── app_prod_config.yaml                  # Pipeline config
│       │
│       ├── helpers/
│       └── pipelines/
│           ├── main.py                               # Main entry point for pipeline
│           └── app_prod_pipeline.py                  # APP forecasting pipeline
│
├── forecasting-architecture.mermaid                  # Diagram of execution architecture
├── .gitignore                                        # Excludes binaries, data artifacts
├── Dockerfile                                        # Dockerized environment definition
├── README.md                                         # Project overview and usage
└── requirements.txt                                  # Python dependency lockfile
</pre>

2. ## Submitting Forecasting Pipeline and Consolidation Job Through Bash Script
The **`app_submit_jobs.sh`** script submits two YAML files named **`spark_app_prod_forecasting.sh`** and **`job_group_watcher.sh`**. **`spark_app_prod_forecasting.sh`** has configuration for the forecasting pipeline, while **`job_group_watcher.sh`** keeps a watch on the submitted spark application and triggers the consolidation script as soon as they are completed.
Each YAML file acts as a fully declarative specification of one Spark application or a consolidation job.
### Key Fields in the Spark YAML

Here’s how core fields are configured in each Spark application spec:

| Field | Description |
| --- | --- |
| `metadata.name` | Application name, e.g., `spark-app-prod-forecasting` |
| `spec.image` | Docker image for Spark job container:  <br>`regdevaaaiforecasting.azurecr.io/spark-app-forecasting-prod:<tag>` |
| `spec.mainApplicationFile` | Entry point script inside container:  <br>`/opt/spark/work-dir/projects/EL_order_forecasting/pipelines/main.py` |

These environment variables are injected into **both driver and executor** pods via `env:` section, making them accessible within the code to dynamically configure the pipeline. <br>
![image.png](/.attachments/image-929d521e-19b2-4fce-8c3b-bf98d495df76.png)

3. ## Pipeline Steps and Data Level Parallelization
The `app_prod_pipeline()` function constructs and executes a modular forecasting pipeline using the `SparkPipeline` class. Each pipeline consists of **independently defined steps** that operate on partitioned data in parallel.
### Step Composition

The pipeline is composed as a list of modular steps:

`steps = [     (preprocess, {"pass_partitioned_data": True}),     (prepare, {"pass_partitioned_data": False}),     (optuna_training, {"pass_partitioned_data": False}), ]`

Each step is:
*   A callable (e.g., `preprocess`, `prepare`, `optuna_training`)
    
*   Paired with metadata specifying whether the function should receive partitioned data directly
    
This design allows each step to be controlled and reused independently.

### Parallelism Based on Grouping Columns

The grouping logic is determined by the project configuration.

The `SparkPipeline` class internally uses a **grouping column** (e.g., `Division`, `KPI`, etc.) defined in the config to partition the input data.
This enables **parallel execution**:
*   Each group is processed **independently** on its own executor
    
*   The pipeline steps are executed using `.groupBy().applyInPandas()` behind the scenes

4. ## Model Tracking and Artifacts
### Tracking Experiments
*   MLflow is integrated with `mlflow.log_param` and `mlflow.log_metric`
    
*   Trials and metrics from Optuna are recorded for each run
    
*   Backend is Azure ML Workspace (remote URI via `mlflow.set_tracking_uri()`)
### Accessing Azure Blob Storage from AKS
All file paths in your config (e.g. `order_data`, `manual_features`, `output_path`) use the **ABFS URI scheme**, which points to Azure Data Lake Storage Gen2.<br>
![image.png](/.attachments/image-6361861a-d8c2-4bdd-a4e9-4e6e9ebee2e4.png)
Access to these paths is enabled through **Azure Workload Identity** configured in the Spark job YAML. No connection strings or keys are required — authentication is handled using a federated identity and token mounted in the driver and executor pods.

Note: Always use the utility functions from `core.forecasting_utils.io_utils` to interact with files