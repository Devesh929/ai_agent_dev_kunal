### Basic Info

| **Field** | **Details (to be filled by user)** |
| --- | --- |
| Model / Forecast Name |  |
| Owner(s) / Contributors |  |
| Date Started |  |
| Management View | e.g., ABB, Division Name |
| Legal View | e.g., ABB, Entity Name |
| Forecast Cycle | e.g., Aug-2025 / Rolling 3M / 15M |
| KPIs Being Forecasted | e.g., Orders, Revenue, Ops EBITA % |
| Forecast Horizon | e.g., 3 months, Year-End, 15 months |

### Data Preparation

| **Step** | **Details / Notes** |
| --- | --- |
| Data Sources Used | List internal and external sources |
| Period Covered | e.g., Jan 2021 – Jul 2025 |
| Data Extracted From | e.g., Abacus, Oxf Econ |
| Extraction Date(s) |  |
| Data Preprocessing Steps | e.g., Null handling, normalization |
| Feature Engineering Applied |  |
| Data Partitioning (Train/Test) |  |


### Modeling & Execution

| **Step** | **Details / Notes** |
| --- | --- |
| Model Type Used | e.g., ARIMA, LSTM, XGBoost |
| Tools / Libraries Used | e.g., Python, Prophet, Scikit-learn |
| Model Training Date |  |
| Forecast Run Date(s) |  |
| Key Parameters Tuned |  |
| Output Variables |  |


### Output & Validation

| **Step** | **Details / Notes** |
| --- | --- |
| Output Generated For | e.g., Aug–Oct 2025 |
| Format of Output | e.g., CSV, Dashboard, API |
| Where Output is Used | e.g., Finance Dashboard, Business Review |
| Accuracy Metrics | e.g., MAPE: 6.3%, RMSE: 1200 |
| Validation Performed By |  |
| Pre-validation Notes |  |
| Known Issues / Limitations |  |

* * *

###  Handoff & Monitoring

| **Step** | **Details / Notes** |
| --- | --- |
| Owner for Ongoing Monitoring |  |
| Update Frequency Planned | e.g., Monthly |
| Alerting / Drift Detection Set Up? | Yes / No / Planned |
| Next Scheduled Update |