import pandas as pd
import numpy as np

def run_3pt_miner():
    print("Loading data for 3-Point Analysis...")
    try:
        players = pd.read_csv('data/nba_player_logs_2012_2026.csv')
        stocks = pd.read_csv('data/sp500_stock_data_2012_2026.csv')
    except Exception as e:
        print(f"Error loading data: {e}")
        return

    players['GAME_DATE'] = pd.to_datetime(players['GAME_DATE']).dt.tz_localize(None)
    stocks['Date'] = pd.to_datetime(stocks['Date']).dt.tz_localize(None)
    stocks.sort_values(by=['Ticker', 'Date'], inplace=True)
    
    stocks['Pct_Change'] = stocks.groupby('Ticker')['Close'].pct_change() * 100
    stocks['Went_Up'] = stocks['Pct_Change'] > 0
    stocks['Went_Down'] = stocks['Pct_Change'] < 0

    famous_tickers = {
        'TSLA': 'Tesla',
        'AAPL': 'Apple',
        'MSFT': 'Microsoft',
        'AMZN': 'Amazon',
        'NFLX': 'Netflix',
        'META': 'Meta (Facebook)',
        'KO': 'Coca-Cola',
        'MCD': 'McDonalds',
        'SBUX': 'Starbucks',
        'NKE': 'Nike',
        'DIS': 'Disney'
    }
    stocks = stocks[stocks['Ticker'].isin(famous_tickers.keys())]

    # Map Next Trading Day
    stock_dates = sorted(stocks['Date'].unique())
    stock_date_df = pd.DataFrame({'Stock_Date': stock_dates})
    
    def get_next_trading_day(game_date):
        future = stock_date_df[stock_date_df['Stock_Date'] > game_date]
        if not future.empty:
            return future.iloc[0]['Stock_Date']
        return pd.NaT

    unique_game_dates = pd.DataFrame({'GAME_DATE': players['GAME_DATE'].unique()})
    unique_game_dates['Next_Trading_Date'] = unique_game_dates['GAME_DATE'].apply(get_next_trading_day)
    players = pd.merge(players, unique_game_dates, on='GAME_DATE', how='left')

    events = []
    
    print("Mining different angles for 3-Point events...")
    
    for _, row in players.iterrows():
        p_name = row['PLAYER_NAME']
        date = row['Next_Trading_Date']
        if pd.isna(date): continue
            
        fg3m = row['FG3M']
        fg3a = row['FG3A']
        
        # Angle 1: The Splash Brothers Explosion
        if (p_name == "Stephen Curry" or p_name == "Klay Thompson") and fg3m >= 9:
            events.append({'Date': date, 'Event': f"{p_name} hits 9+ Threes"})
            
        # Angle 2: Any player hitting 10+ Threes (Insane Volume)
        if fg3m >= 10:
            events.append({'Date': date, 'Event': "ANY player hits 10+ Threes in a single game"})
            
        # Angle 3: Terrible Shooting Night (The "Brick" Effect)
        if fg3m == 0 and fg3a >= 8:
            events.append({'Date': date, 'Event': f"A player shoots 0% on 8+ Three-Point attempts"})
            
        # Angle 4: The Perfect Sniper (100% on high volume)
        if fg3m == fg3a and fg3a >= 6:
            events.append({'Date': date, 'Event': "A player shoots a PERFECT 100% on 6+ Three-Point attempts"})
            
        # Angle 5: Steph Curry going completely cold
        if p_name == "Stephen Curry" and fg3m <= 1:
            events.append({'Date': date, 'Event': "Stephen Curry makes 1 or fewer Threes"})

    events_df = pd.DataFrame(events).drop_duplicates()
    
    results = []
    for event_name in events_df['Event'].unique():
        event_dates = events_df[events_df['Event'] == event_name]['Date']
        num_occurrences = len(event_dates)
        
        if num_occurrences < 10: # Lowered threshold slightly to catch rare 3PT events
            continue
            
        for ticker, company_name in famous_tickers.items():
            stock_slice = stocks[(stocks['Ticker'] == ticker) & (stocks['Date'].isin(event_dates))]
            
            if len(stock_slice) == 0: continue
            
            up_days = stock_slice['Went_Up'].sum()
            down_days = stock_slice['Went_Down'].sum()
            
            up_pct = (up_days / len(stock_slice)) * 100
            down_pct = (down_days / len(stock_slice)) * 100
            
            if up_pct >= 65:
                results.append({
                    'Pattern': f"Whenever {event_name}, {company_name} stock GOES UP!",
                    'Accuracy': up_pct,
                    'Occurrences': len(stock_slice),
                    'Type': 'UP'
                })
            elif down_pct >= 65:
                results.append({
                    'Pattern': f"Whenever {event_name}, {company_name} stock CRASHES!",
                    'Accuracy': down_pct,
                    'Occurrences': len(stock_slice),
                    'Type': 'DOWN'
                })

    res_df = pd.DataFrame(results)
    if not res_df.empty:
        res_df.sort_values(by=['Accuracy', 'Occurrences'], ascending=[False, False], inplace=True)
        res_df.to_csv('data/3pt_patterns.csv', index=False)
        print("\n=== TOP 3-POINT YOUTUBE PATTERNS SAVED TO CSV ===\n")
        for _, row in res_df.head(20).iterrows():
            print(f"{row['Pattern']} ({int(row['Accuracy'])}% of the time, N={row['Occurrences']})")
    else:
        print("No patterns met the threshold.")

if __name__ == "__main__":
    run_3pt_miner()
