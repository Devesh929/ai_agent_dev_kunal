#Snowflake Data Download Process

##Context

During the Accelerator Program last year, the **ZC Snowflake instance** was used to download **GIS** and **SFDC** data. **ATLAS** data too was retrieved but since the data didn't match with the original source data it wasn't used.

##Key Points


1.  **Consolidation Database**
    *   Contains tables transformed from raw data into corrected column names and made user-friendly.
        
2.  **Staging Database**
    *   Contains the rawest form of data from the original source.
        
3.  **Column Search**
    *   If a column is not found in the Consolidation database, search for it in the Staging database.
        
    *   Currently, there is no documentation on Snowflake usage or table-level data storage. Verification must be done manually.
        
4.  **Data Verification**
    *   Each table was verified against its original source (e.g., Snowflake SFDC data was cross-checked with data downloaded directly from SFDC).
        
5.  **Access Requirements**
    *   Access to the Snowflake instance for the required business area was given by Wojciech Matuszewicz.
        
    *   ***Snowflake Sandbox*** access is needed if you want to save created tables or upload from local.
        
6.  **Table Creation & Upload**
    *   Once sandbox access is granted, you can upload data as a table to a schema:
        *   **Database → Schema → Create → Table → Upload**

##**Snowflake SFDC Data**


### Purpose

*   Extract sales opportunity data and customer data.
    
*   Link customer accounts to opportunities and locations.
    
*   Retrieve opportunity data by year, amount, and location.
    
*   Identify null account/opportunity data for quality checks.
    

### Data Source

*   **Database:** `PROD_HUB_CONSOLIDATION_EU`
    
*   **Schema:** `SFDC`
    

### Tables Used

1.  **DV_ACCOUNT** – Account data from Salesforce opportunities/customers.
    
2.  **DV_OPPORTUNITY** – Sales opportunity data.
    
3.  **DV_ABB_LOCATION** – ABB location details for customers.
    

### Columns Retrieved

**From DV_ACCOUNT:**  
`ID`, `ACCOUNT_ID`, `ACCOUNT_NAME`, `FAMILY_TREE_LEVEL`, `ACCOUNT_GUID`, `PARENT_GUID`,  
`PRIMARY_ADDRESS_COUNTRY_C`, `ROOT_ACCOUNT_GUID`
**From DV_OPPORTUNITY:**  
`ID`, `OPPORTUNITY_ID`, `ACCOUNT_ID`, `OPPORTUNITY_NAME`, `PRODUCT_GROUP_CODE`,  
`STAGE_NAME`, `EAD_EXPECTED_AWARD_DATE`, `OWNER_ID`, `BUSINESS_UNIT`,  
`OPPORTUNITY_NUMBER`, `OPP_AMOUNT`, `OPP_OPPORTUNITY_VALUE__C`,  
`TECHNICAL_AMOUNT_USD__C`
**From DV_ABB_LOCATION:**  
`ID`, `LOC_NAME`, `LOC_COUNTRY__C`

### Joins / Relationships

*   **DV_ACCOUNT → DV_OPPORTUNITY:**  
    `opportunity.ACCOUNT_ID = account.ACCOUNT_ID`  
    (One account can have multiple opportunities.)
    
*   **DV_OPPORTUNITY → DV_ABB_LOCATION:**  
    `opportunity.OPP_ABB_LOCATION__C = location.LOC_ID`  
    (Links an opportunity to its customer location.)
    

### Storage & Usage

*   Extracted data is stored in temporary tables in the warehouse.

##**Snowflake GIS Data**


### Data Source

*   **Data Warehouse:** `IA_DATASETS_PROD`
    
*   **Schema:** `MASTERDATA` (Stores customer master data)
    

### Tables Used

1.  **SAP_VENDOR** – Vendor master data from GIS.
    
2.  **FI_ISO_COUNTRY** – Reference table for ISO country codes and names.
    

### Columns Retrieved

**From SAP_VENDOR:**
*   `GLOBAL_VENDOR_GUID` – Unique global identifier for vendors.
    
*   `VENDOR_COUNTRY` – Country code for the vendor.
    
**From FI_ISO_COUNTRY:**
*   `COUNTRY_NAME` – Country name.
    
*   `COUNTRY_CODE` – Country code.


##**Snowflake ATLAS Data**

##Data Source


*   **Data Warehouse**: `IA_DATASETS_PROD` 
    
*   **Schema**: `ORDER_TO_CASH` → Stores ATLAS data.
    
*   **Table**: `ATLAS_REVENUE_CONTRIBUTION_MARGIN`

##Columns Retrieved

`Business Area`, `Customer_Country`, `Customer_Hq_GUID`, `Customer_Global_HQ`, `TIME Cal Year`, `Time/Cal Year Day`, `End_customer_country`, `End_customer_Guid`, `End_customer_Name`, `Mgmt_PG_IS_Service`, `Legal_supply_country`, `Orders_Received_net_USD`, `Order_ID`, `MGMT_PRODUCT_GROUP`, `MGMT_PRODUCT_KEY_TEXT`, `THIRD_PARTY`, `Order_ID`
