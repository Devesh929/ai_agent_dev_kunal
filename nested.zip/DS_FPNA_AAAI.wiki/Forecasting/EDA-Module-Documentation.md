**EDA Framework**
--
1. **Overview**
----------

The EDA Module is a robust and flexible tool designed to automate and streamline the Exploratory Data Analysis process for various datasets. It provides a comprehensive set of functionalities for understanding data distributions, identifying missing values and outliers, analyzing correlations, and visualizing key insights, enabling data scientists and analysts to quickly grasp the underlying structure and characteristics of their data.

The user has the functionality to run either of the Analyses or they can run both by marking the individual analysis true in the eda_config (part of the main config).
* * *
2. **Key Features**
-----
The EDA Module offers the following core functionalities:
*   Data Summary Statistics: Generates descriptive statistics for all columns (mean, median, std, min, max, quartiles, etc.).
    
*   Missing Value Analysis: Quantifies missing data patterns    
  
*   Outlier Detection (Basic): Provides initial insights into potential outliers using statistical methods (e.g., IQR, Z-score).

*   Time Series Analysis: Numerical: Checks for stationarity, if the series is seasonal, additive or multiplicative, the possible AR-MA parameters, fourier series, ACF-PACF plots, Growth charts and Line charts.

*   Univariate Analysis: Numerical: Distribution plots (histograms, KDE plots, box plots), checks for linearity and normality.
        
*   Multivariate Analysis: Two-way ANOVA, Pairplots, correlation matrices(Pearson, Spearman), Predictive Power Score and Mutual Information Score, and Regression Analysis. The relationship is also analyzed for lagged variables taking the input for number of lags from the user.

* * *
3. **Inputs**
-----
1. A Dataframe which is received from the data_prep module. Its a cleaned and outlier treated dataset.
2. A Config which include various configurations important to run the univariate and multivariate analysis separately and seamlessly. This config will be a sub-config in the main config (universal for all modules). 
Config Structure:
{"input_path":"input"              -->common across modules
.
.
 "eda_config": {                   -->main config for eda
"run_univariate":true,             -->set to true to run univariate
"run_multivariate":true,           -->set to true to run multivariate
"univariate_eda_config":{ 
  "column_loop_in_wrapper": true,  --> must be set to true
  "target_columns":[]              -->[] if all columns to be used
 },
"multivariate_eda_config":{  
  "column_loop_in_wrapper": false, --> must be set to false

* * *
4. **Architecture**
--------
### Folder Structure

    forecasting/
    ├── eda_module
       ├──eda_utility.py
       ├──main.py                     # this file     
    ├── streamlit     
       ├── main_streamlit.py 
       ├── univariate_streamlit.py       
       ├── multivariate_streamlit.py  
    ├── universal_utils 
    ├── universal_config     

* * *
5. **Class Responsibilities**
------------------
The EDA module is designed with a clear, hierarchical structure to manage the various analytical and reporting tasks. This modularity ensures maintainability, testability, and a clean separation of concerns, particularly regarding computational analysis versus visualization.
At its core, the `EDA` class orchestrates the entire process, delegating specific analytical tasks to specialized sub-modules and wrappers.

#### 1. `EDA` Class

*   **Purpose:** The main entry point and orchestrator for the entire Exploratory Data Analysis pipeline. It initializes the necessary sub-components and manages the flow of data through different analysis stages.
    
*   **Key Method:**
    *   `run()`: This central method executes the complete EDA process. It coordinates calls to the `UnivariateWrapper` for univariate analysis and the `MultivariateWrapper` for multivariate analysis, collecting their respective outputs.
        
*   **Usage:** You instantiate the `EDA` class with your DataFrame and configuration, then simply call its `run()` method to initiate the analysis.
    

#### 2. `UnivariateWrapper`

*   **Purpose:** Acts as an intermediary for all univariate analysis tasks. It standardizes the interface for performing single-variable explorations.
    
*   **Key Responsibility:** Calls the `UnivariateAnalyzer` class to perform detailed univariate calculations.
    
*   **Output:** Provides summarized univariate statistics and insights, ready for external plotting.
    

#### 3. `MultivariateWrapper`

*   **Purpose:** Acts as an intermediary for all multivariate analysis tasks. It coordinates complex analyses involving relationships between multiple variables.
    
*   **Key Responsibilities:** Calls dedicated classes for Correlation, Mutual Information (MI), Predictive Power Score (PPS), and Regression analysis.
    
*   **Output:** Provides rich data structures containing correlation matrices, MI scores, PPS matrices, and regression model results (metrics, predictions).
    

#### 4. Analytical Classes (Core Computations)

These classes perform the intensive calculations and generate the analytical tables and data summaries that are consumed by other parts of the system or external applications (like Streamlit) for visualization. All these classes consistently utilize a `logger` for operational insights and a `file_handler` for saving their respective outputs (e.g., summary tables, model artifacts).
*   **`UnivariateAnalyzer`**
    *   **Purpose:** Focuses solely on calculating descriptive statistics and identifying characteristics for individual variables (e.g., central tendency, dispersion, missing values, duplicates, outliers).
        
    *   **Key Output:** Detailed DataFrames summarizing univariate metrics.
        
    *   **Note on Plotting:** This class is responsible for _calculating_ univariate statistics. The actual _plotting_ of univariate distributions is offloaded to the Streamlit application layer, which consumes the data output by this class.
        
*   **`CorrelationAnalyzer`**
    *   **Purpose:** Calculates various correlation coefficients (e.g., Pearson, Spearman) between numerical features and identifies optimal lags for variables based on correlation strength.
        
    *   **Key Output:** Correlation matrices and a `best_combined` DataFrame indicating optimal lagged relationships.
        
*   **`MIAnalyzer` (Mutual Information)**
    *   **Purpose:** Quantifies the dependency between variables by calculating Mutual Information scores, which can capture non-linear relationships.
        
    *   **Key Output:** A matrix or DataFrame of MI scores between all relevant feature pairs.
        
*   **`PPSAnalyzer` (Predictive Power Score)**
    *   **Purpose:** Measures the predictive power of one feature on another, offering insights into potential non-linear relationships and asymmetries in predictions.
        
    *   **Key Output:** A matrix or DataFrame of PPS scores.
        
*    **`BestRegressionModel`** Class (Regression) 
     *   **Purpose:** Builds and evaluates linear and polynomial regression models based on the identified "best" variable-lag combinations. It generates predictions and evaluates model performance.       
     *   **Key Output:** Trained model objects, DataFrames of predictions, and detailed regression metrics (e.g., R²).  
     *   **Note on Plotting:** While this class internally generates regression fit plots, these are intended as direct outputs/artifacts from the module's execution, not for redundant generation within Streamlit.
        

#### 5. Shared Services

All analytical classes (`UnivariateAnalyzer`, `CorrelationAnalyzer`, `MIAnalyzer`, `PPSAnalyzer`, `Regression`) are designed to be instantiated with and utilize:
*   **`logger`**: A shared logging instance for consistent logging of information, warnings, and errors across the entire pipeline.
    
*   **`file_handler`**: A shared utility (likely an instance of `FileHandler`) for saving output artifacts (e.g., Excel tables of metrics, JSON files, plots generated by the `Regression` class).
    

#### **Strategy for Zero Redundancy in Plotting/Tables:**

A core principle of this architecture is to avoid redundant computation and visualization.
*   **Calculations First:** All computationally intensive analyses (like PPS, MI, correlations, and regression model fitting) are performed within the dedicated classes of the EDA module. These classes produce structured data (DataFrames, dictionaries of scores/metrics).
    
*   **Outputs for Consumption:** These structured data outputs are then consumed by the Streamlit application.
    
*   **Streamlit for Visualization:** The Streamlit application's primary role is to _display_ these pre-calculated results and handle the _interactive plotting_ of univariate distributions, providing a dynamic user experience without re-running heavy computations.
    
*   **Regression Plots:** Plots specifically generated by the `Regression` class are considered final artifacts of the module's execution, saved via the `file_handler`, and not re-generated within Streamlit to avoid duplication.

* * *
**5.1 Code Usage Example**
------------------

```
from core.forecasting_components.eda_module.eda_utility import UnivariateAnalyzer
series = comb_data[col]

analyzer = UnivariateAnalyzer(self.module_config, self.logger, self.file_handler, self.comb, series)

summary_df, summary_dict = analyzer.generate_univariate_summary(series)
is_stationary, adf_p, kpss_p = analyzer.check_stationarity(series)
```


* * *
**6. Output**
------------------
The streamlit Univariate Analysis page
![image.png](/.attachments/image-54570741-5b93-436e-a595-593b673e7296.png)

The streamlit Univariate Analysis page
![image.png](/.attachments/image-c2302ba1-08a2-4bdc-9205-2634cdbfa6d6.png)

* * *
**7. Logging and Handling**
------------------
*   All classes accept a logger and file handler instance.
    
*   Warnings and exceptions are explicitly caught and logged.