import os

def merge_databases():
    brain_dir = r"C:\Users\INDECHA13\.gemini\antigravity\brain\fe5b129f-027e-428d-9861-5c1df2d43a67"
    
    with open(os.path.join(brain_dir, 'ultimate_pattern_database.md'), 'r', encoding='utf-8') as f:
        gravitas_content = f.read()
        
    with open(os.path.join(brain_dir, 'the_absolute_master_database.md'), 'r', encoding='utf-8') as f:
        exhaustive_content = f.read()
        
    # Strip the heading from exhaustive_content
    exhaustive_content = exhaustive_content.replace("# 🏆 The Absolute Master Database (All Verified Patterns)", "## Part 2: The Exhaustive Parallel Miner Database")
        
    merged_content = "# 🏆 The Absolute Master Database\n\n"
    merged_content += "This master document contains literally every pattern we have discovered, perfectly organized for your video. It includes the highly curated 'Gravitas' storytelling hooks, followed by the massive exhaustive database of all players and macro patterns.\n\n"
    
    merged_content += "## Part 1: The 'Gravitas' Storytelling Hooks\n"
    merged_content += gravitas_content.split('tension.\n\n')[1] + "\n\n"
    
    merged_content += exhaustive_content
    
    with open(os.path.join(brain_dir, 'the_absolute_master_database.md'), 'w', encoding='utf-8') as f:
        f.write(merged_content)
        
if __name__ == "__main__":
    merge_databases()
