import pandas as pd
import numpy as np
import warnings
warnings.filterwarnings('ignore')

def build_market_features(stocks):
    print("Building Market Features...")
    stocks['Date'] = pd.to_datetime(stocks['Date']).dt.tz_localize(None)
    stocks.sort_values(by=['Ticker', 'Date'], inplace=True)
    
    # Calculate rolling 20-day volume average and standard deviation
    stocks['Vol_20d_Avg'] = stocks.groupby('Ticker')['Volume'].transform(lambda x: x.shift(1).rolling(20).mean())
    stocks['Vol_20d_Std'] = stocks.groupby('Ticker')['Volume'].transform(lambda x: x.shift(1).rolling(20).std())
    
    # Calculate Volume Surprise (Z-score)
    stocks['Volume_Surprise'] = (stocks['Volume'] - stocks['Vol_20d_Avg']) / stocks['Vol_20d_Std']
    
    # Calculate Overnight Gap: (Open / Prev Close) - 1
    stocks['Prev_Close'] = stocks.groupby('Ticker')['Close'].shift(1)
    stocks['Overnight_Gap'] = (stocks['Open'] / stocks['Prev_Close']) - 1
    
    # Calculate SPY Baseline Gap
    spy = stocks[stocks['Ticker'] == '^GSPC'][['Date', 'Overnight_Gap']].rename(columns={'Overnight_Gap': 'SPY_Gap'})
    
    stocks = pd.merge(stocks, spy, on='Date', how='left')
    stocks['Abnormal_Gap'] = stocks['Overnight_Gap'] - stocks['SPY_Gap']
    
    # Clean up infs and NaNs from low volume days
    stocks.replace([np.inf, -np.inf], np.nan, inplace=True)
    
    return stocks.dropna(subset=['Volume_Surprise', 'Abnormal_Gap'])

def build_nba_features(teams):
    print("Building NBA Features...")
    teams['GAME_DATE'] = pd.to_datetime(teams['GAME_DATE']).dt.tz_localize(None)
    teams.sort_values(by=['TEAM_ID', 'GAME_DATE'], inplace=True)
    
    # Win indicator
    teams['Win_Flag'] = (teams['WL'] == 'W').astype(int)
    
    # Rolling win percentage (Proxy for team strength)
    teams['Rolling_Wins'] = teams.groupby('TEAM_ID')['Win_Flag'].transform(lambda x: x.shift(1).rolling(82, min_periods=10).sum())
    teams['Rolling_Games'] = teams.groupby('TEAM_ID')['Win_Flag'].transform(lambda x: x.shift(1).rolling(82, min_periods=10).count())
    teams['Win_Pct'] = teams['Rolling_Wins'] / teams['Rolling_Games']
    teams['Win_Pct'].fillna(0.5, inplace=True) # Default for early season
    
    # To find "Surprise", we need opponent's win percentage
    # Self-join on GAME_ID to get opponent's stats
    game_matchups = pd.merge(teams, teams, on='GAME_ID', suffixes=('', '_OPP'))
    game_matchups = game_matchups[game_matchups['TEAM_ID'] != game_matchups['TEAM_ID_OPP']]
    
    # Expected Margin Proxy: difference in win percentage * 20 (rough scale)
    game_matchups['Expected_Margin'] = (game_matchups['Win_Pct'] - game_matchups['Win_Pct_OPP']) * 20
    game_matchups['Actual_Margin'] = game_matchups['PTS'] - game_matchups['PTS_OPP']
    
    # Result Surprise
    game_matchups['Result_Surprise'] = game_matchups['Actual_Margin'] - game_matchups['Expected_Margin']
    
    # Excitement Score
    # Highly exciting if margin is close (absolute margin small) OR massive upset (huge surprise)
    game_matchups['Excitement_Score'] = (20 - game_matchups['Actual_Margin'].abs()) + (game_matchups['Result_Surprise'].abs() * 0.5)
    
    # Flag top 5% most exciting / shocking games in the decade
    excitement_threshold = game_matchups['Excitement_Score'].quantile(0.95)
    game_matchups['Is_Shocking_Game'] = game_matchups['Excitement_Score'] > excitement_threshold
    
    # Keep one row per game (drop duplicates)
    daily_nba = game_matchups.groupby('GAME_DATE').agg({
        'Is_Shocking_Game': 'max',
        'Excitement_Score': 'mean'
    }).reset_index()
    
    return daily_nba

def run_experiment():
    print("Loading data...")
    try:
        stocks = pd.read_csv('data/sp500_stock_data_2012_2026.csv')
        teams = pd.read_csv('data/nba_team_logs_2012_2026.csv')
    except Exception as e:
        print(f"Error loading data: {e}")
        return
        
    stocks = build_market_features(stocks)
    nba = build_nba_features(teams)
    
    print("Aligning dates...")
    stock_dates = sorted(stocks['Date'].unique())
    stock_date_df = pd.DataFrame({'Stock_Date': stock_dates})
    
    def get_next_trading_day(game_date):
        future = stock_date_df[stock_date_df['Stock_Date'] > game_date]
        if not future.empty:
            return future.iloc[0]['Stock_Date']
        return pd.NaT

    nba['Next_Trading_Date'] = nba['GAME_DATE'].apply(get_next_trading_day)
    nba = nba.dropna(subset=['Next_Trading_Date'])
    
    print("Running Coincidence Scan...")
    # Merge
    panel = pd.merge(stocks, nba, left_on='Date', right_on='Next_Trading_Date', how='inner')
    
    results = []
    
    # Scan all tickers to find consistent decadal coincidences
    tickers = panel['Ticker'].unique()
    
    for ticker in tickers:
        df_ticker = panel[panel['Ticker'] == ticker]
        if len(df_ticker) < 500:
            continue
            
        # Control group (boring NBA days) vs Treatment group (Shocking NBA days)
        treatment = df_ticker[df_ticker['Is_Shocking_Game'] == True]
        control = df_ticker[df_ticker['Is_Shocking_Game'] == False]
        
        if len(treatment) < 10:
            continue
            
        mean_vol_shock = treatment['Volume_Surprise'].mean()
        mean_vol_control = control['Volume_Surprise'].mean()
        
        mean_gap_shock = treatment['Abnormal_Gap'].mean()
        mean_gap_control = control['Abnormal_Gap'].mean()
        
        # We are looking for huge positive differences in volume surprise
        vol_diff = mean_vol_shock - mean_vol_control
        
        results.append({
            'Ticker': ticker,
            'Control_Days': len(control),
            'Shock_Days': len(treatment),
            'Avg_Vol_Surprise_Shock': mean_vol_shock,
            'Avg_Vol_Surprise_Control': mean_vol_control,
            'Volume_Difference': vol_diff,
            'Avg_Abnormal_Gap_Shock': mean_gap_shock,
            'Avg_Abnormal_Gap_Control': mean_gap_control,
            'Gap_Difference': mean_gap_shock - mean_gap_control
        })
        
    res_df = pd.DataFrame(results)
    res_df.sort_values(by='Volume_Difference', ascending=False, inplace=True)
    
    res_df.to_csv('data/decadal_coincidences.csv', index=False)
    
    print("\n--- TOP 10 STOCKS WITH HIGHEST ABNORMAL VOLUME AFTER SHOCKING NBA GAMES ---")
    for i, row in res_df.head(10).iterrows():
        print(f"{row['Ticker']}: +{row['Volume_Difference']:.2f} Z-Score volume difference (N={row['Shock_Days']} shock days)")
        
    print("\n--- TOP 10 STOCKS WITH HIGHEST ABNORMAL GAPS AFTER SHOCKING NBA GAMES ---")
    res_df.sort_values(by='Gap_Difference', ascending=False, inplace=True)
    for i, row in res_df.head(10).iterrows():
        print(f"{row['Ticker']}: +{row['Gap_Difference']*100:.3f}% gap difference (N={row['Shock_Days']} shock days)")

if __name__ == "__main__":
    run_experiment()
