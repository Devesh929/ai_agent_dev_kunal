import pandas as pd
import numpy as np

def run_youtube_miner():
    print("Loading data...")
    try:
        players = pd.read_csv('data/nba_player_logs_2012_2026.csv')
        stocks = pd.read_csv('data/sp500_stock_data_2012_2026.csv')
    except Exception as e:
        print(f"Error loading data: {e}")
        return

    players['GAME_DATE'] = pd.to_datetime(players['GAME_DATE']).dt.tz_localize(None)
    stocks['Date'] = pd.to_datetime(stocks['Date']).dt.tz_localize(None)
    stocks.sort_values(by=['Ticker', 'Date'], inplace=True)
    
    # Calculate simple up/down for stocks
    stocks['Pct_Change'] = stocks.groupby('Ticker')['Close'].pct_change() * 100
    stocks['Went_Up'] = stocks['Pct_Change'] > 0
    stocks['Went_Down'] = stocks['Pct_Change'] < 0

    # Let's focus on highly recognizable stocks for a general audience
    famous_tickers = {
        'TSLA': 'Tesla',
        'AAPL': 'Apple',
        'MSFT': 'Microsoft',
        'AMZN': 'Amazon',
        'NFLX': 'Netflix',
        'META': 'Meta (Facebook)',
        'KO': 'Coca-Cola',
        'MCD': 'McDonalds',
        'SBUX': 'Starbucks',
        'NKE': 'Nike',
        'DIS': 'Disney',
        'UBER': 'Uber'
    }
    
    stocks = stocks[stocks['Ticker'].isin(famous_tickers.keys())]

    # Let's focus on famous players
    famous_players = [
        "LeBron James", "Stephen Curry", "Kevin Durant", "Giannis Antetokounmpo", 
        "James Harden", "Russell Westbrook", "Luka Doncic", "Nikola Jokic", 
        "Kawhi Leonard", "Anthony Davis", "Damian Lillard", "Kyrie Irving", "Jimmy Butler"
    ]
    
    players = players[players['PLAYER_NAME'].isin(famous_players)]

    # Get Next Trading Day for NBA games
    stock_dates = sorted(stocks['Date'].unique())
    stock_date_df = pd.DataFrame({'Stock_Date': stock_dates})
    
    def get_next_trading_day(game_date):
        future = stock_date_df[stock_date_df['Stock_Date'] > game_date]
        if not future.empty:
            return future.iloc[0]['Stock_Date']
        return pd.NaT

    # To speed things up, map all unique game dates first
    unique_game_dates = pd.DataFrame({'GAME_DATE': players['GAME_DATE'].unique()})
    unique_game_dates['Next_Trading_Date'] = unique_game_dates['GAME_DATE'].apply(get_next_trading_day)
    players = pd.merge(players, unique_game_dates, on='GAME_DATE', how='left')

    # Define crazy events
    events = []
    
    for _, row in players.iterrows():
        p_name = row['PLAYER_NAME']
        date = row['Next_Trading_Date']
        if pd.isna(date): continue
            
        if row['PTS'] >= 40:
            events.append({'Date': date, 'Event': f"{p_name} scores 40+ points"})
        if row['FG3M'] >= 8:
            events.append({'Date': date, 'Event': f"{p_name} hits 8+ Three-Pointers"})
        if row['REB'] >= 18:
            events.append({'Date': date, 'Event': f"{p_name} grabs 18+ Rebounds"})
        if row['AST'] >= 15:
            events.append({'Date': date, 'Event': f"{p_name} gets 15+ Assists"})
            
    events_df = pd.DataFrame(events).drop_duplicates()
    
    if events_df.empty:
        print("No events found.")
        return
        
    print(f"Testing {len(events_df['Event'].unique())} unique super-events against the stock market...")
    
    results = []
    
    for event_name in events_df['Event'].unique():
        event_dates = events_df[events_df['Event'] == event_name]['Date']
        num_occurrences = len(event_dates)
        
        # Only care about events that happened at least 15 times so it's a "real pattern"
        if num_occurrences < 15:
            continue
            
        for ticker, company_name in famous_tickers.items():
            stock_slice = stocks[(stocks['Ticker'] == ticker) & (stocks['Date'].isin(event_dates))]
            
            if len(stock_slice) == 0: continue
            
            up_days = stock_slice['Went_Up'].sum()
            down_days = stock_slice['Went_Down'].sum()
            
            up_pct = (up_days / len(stock_slice)) * 100
            down_pct = (down_days / len(stock_slice)) * 100
            
            if up_pct >= 65:
                results.append({
                    'Pattern': f"Whenever {event_name}, {company_name} stock GOES UP the next day!",
                    'Accuracy': up_pct,
                    'Occurrences': len(stock_slice),
                    'Type': 'UP'
                })
            elif down_pct >= 65:
                results.append({
                    'Pattern': f"Whenever {event_name}, {company_name} stock CRASHES the next day!",
                    'Accuracy': down_pct,
                    'Occurrences': len(stock_slice),
                    'Type': 'DOWN'
                })

    res_df = pd.DataFrame(results)
    if not res_df.empty:
        res_df.sort_values(by=['Accuracy', 'Occurrences'], ascending=[False, False], inplace=True)
        res_df.to_csv('data/youtube_patterns.csv', index=False)
        print("\n=== TOP YOUTUBE-READY PATTERNS SAVED TO CSV ===\n")
    else:
        print("No patterns met the 75% accuracy threshold for YouTube.")

if __name__ == "__main__":
    run_youtube_miner()
