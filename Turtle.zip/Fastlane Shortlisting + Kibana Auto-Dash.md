Fastlane Shortlisting + Kibana Auto-Dashboard

A minimal pipeline to ingest text data into Elasticsearch, generate BM25 / Hybrid shortlists (with optional ELSER), and auto-provision Kibana Data Views, Saved Searches, Lens panels, and a Dashboard.

1) What this tool does

Connects to Elastic Cloud (via cloud_id) or self-managed Elasticsearch (via es_endpoint).

(Optionally) creates three indices:

Data index (e.g., fastlane-data-<run>): documents with text (and optional labels).

Pairs index (e.g., fastlane-pairs-<run>): shortlist results for each query doc.

Runs index (e.g., fastlane-runs-<run>): run-level metrics and metadata.

Ingests CSV in two modes:

text_pairs → Each CSV row becomes two docs (-A, -B) for pair mining.

text_cls → Each CSV row is a single doc for classification scenarios.

Builds shortlists using:

bm25 (fast), or

hybrid (BM25 + ELSER sparse embeddings) if the data index was (re)created with semantic_text.

Pushes run metrics.

Auto-creates Kibana:

Data Views, Saved Searches, Lens charts (metrics, time series, histograms, pies), and a Dashboard focused on hard negatives and run health.

2) Requirements

Python: 3.9+ recommended

Elasticsearch: 8.x (Elastic Cloud or self-managed)

Kibana: matching version to Elasticsearch

Python packages:

elasticsearch (v8.x client), requests, urllib3, pandas, tqdm

If using Hybrid mode with ELSER, your cluster must support the inference API and have access to the ELSER service (managed model). Your code calls es.inference.put and waits for the model to deploy.

3) Install
# Create & activate a virtualenv (recommended)
python3 -m venv .venv
source .venv/bin/activate

# Install packages
pip install --upgrade pip
pip install elasticsearch requests urllib3 pandas tqdm

4) Security & secrets

Do not hard-code passwords or API keys in source.

Prefer API keys for Elasticsearch & Kibana when possible.

Use TLS with proper CA verification (requests_verify=True or CA path).

If you copied the provided snippet with visible passwords, rotate those credentials now.

5) Configuration

The script uses a CONFIG dict + environment variables overrides. Recommended: keep the Python defaults minimal and manage everything via .env or your CI/CD secret store.

5.1 Environment variables

Create a .env file (not checked into git). Example:

# Choose ONE connection method
CLOUD_ID=your-deployment:ZXMu...               # Elastic Cloud (preferred)
# OR
# ES_ENDPOINT=https://your-es-host:9200

# Elasticsearch auth (BASIC or API key)
ES_USER=elastic
ES_PASS=***REDACTED***                          # rotate if leaked
# If you use API keys with the Python ES client, set CONFIG["api_key"] instead of BASIC auth.

# Kibana base URL and auth
KIBANA_URL=https://your-kibana-host:5601
KIBANA_USER=elastic
KIBANA_PASS=***REDACTED***

# TLS verification: "true"|"false"|"/path/to/ca.pem"
REQUESTS_VERIFY=true

# Optional: Kibana space prefix, e.g. "/s/ml-space"
KIBANA_SPACE=

# ---- Data choices (override per run) ----
RUN_NAME=cloud-demo1
DATA_INDEX=fastlane-data-cloud-demo1
PAIRS_INDEX=
RUNS_INDEX=

CREATE_DATA_INDEX=false
DATA_PATH=./quora_pairs_sample.csv
TASK=text_pairs                             # text_pairs | text_cls

# CSV column names
ID_COL=
TEXT_COL_A=question1
TEXT_COL_B=question2
TEXT_COL=
LABEL_COL=is_duplicate

# Shortlisting
TOPK=50
SHORTLIST_MODE=bm25                         # bm25 | hybrid
BATCH_SIZE=100
SAMPLE_FRAC=1.0
ONLY_SIDE_PREFIX=
HARDNEG=true

# ELSER
ELSER_INFERENCE_ID=fastlane-elser
ELSER_ALLOCATIONS=1
ELSER_THREADS=1

# Kibana automation
BUILD_KIBANA=true


Load .env locally before running:

set -a && source .env && set +a


The script already reads environment variables at startup to override CONFIG.

5.2 CONFIG fields (quick reference)
Key	Meaning	Example
cloud_id	Elastic Cloud deployment ID	my-deploy:ZXMu...
es_endpoint	Self-managed HTTPS endpoint	https://es.example.com:9200
es_user / es_pass	BASIC auth for Elasticsearch	elastic / secret
kibana_url	Kibana base URL	https://kibana.example.com:5601
kibana_user / kibana_pass	BASIC auth for Kibana	user / secret
requests_verify	TLS verify (True, False, or CA path)	True
kibana_space	Space prefix like /s/space-name	""
data_index	Data index name	fastlane-data-<run>
create_data_index	(Re)create data index from CSV	`True
pairs_index / runs_index	Pairs / runs index names	auto if None
task	text_pairs or text_cls	text_pairs
data_path	CSV path	./data.csv
id_col	Optional explicit ID column	id
text_col_a / text_col_b	Pair text columns	question1 / question2
text_col	Single text column (for text_cls)	text
label_col	Optional label column	label
topk	Shortlist size	50
shortlist_mode	bm25 or hybrid	bm25
batch_size	_msearch batch size	100
sample_frac	Sample fraction for shortlist	1.0
only_side_prefix	Filter by -A/-B	A
hardneg	Mark early high-rank label mismatches	True
elser_*	ELSER inference endpoint settings	fastlane-elser, etc.
build_kibana	Auto-create Kibana objects	True
6) Data model (indexes & fields)
6.1 Data index (created when create_data_index=True)

Fields

doc_id (keyword)

content (text, copy_to → content_lex and optionally content_sem)

content_lex (text) — used by BM25

content_sem (semantic_text, only if hybrid + creating index, inference_id = elser_inference_id)

label (keyword, optional)

content_hash (keyword) — SHA1(content)

ts_ingested (date)

unchanged (boolean)

6.2 Pairs index (always re-created per run)

Fields

qid (keyword) — query doc id

candidate_id (keyword)

rank (integer)

score (float)

label_same (boolean, nullable)

hard_negative (boolean)

ts (date)

6.3 Runs index (always re-created per run)

Fields

run_name, task, k, total_docs, unchanged_skipped, dup_collapsed, shortlist_pairs, hardnegs, elapsed_sec, notes, ts

7) Running the pipeline
7.1 Typical flows
A) Reuse an existing data index (fastest)

Ensure .env has CREATE_DATA_INDEX=false and DATA_INDEX=<existing>.

Set SHORTLIST_MODE=bm25 (or hybrid if your existing mapping has semantic_text).

Run:

python fastlane.py

B) Create a new data index from CSV

Set in .env:

CREATE_DATA_INDEX=true

DATA_PATH=./your.csv

TASK=text_pairs (with TEXT_COL_A, TEXT_COL_B) or TASK=text_cls (with TEXT_COL)

SHORTLIST_MODE=bm25 or hybrid (hybrid adds semantic_text and deploys ELSER)

Run:

python fastlane.py


You’ll see console logs like:

ES connection & version

Index names

(If needed) ELSER deployment progress

Shortlisting progress

Kibana object creation and the final dashboard URL

8) Kibana objects (auto-provisioned)

If BUILD_KIBANA=true, the script will:

Create Data Views for pairs and runs (time field = ts).

Create Saved Searches:

Runs table

Hard negatives (pairs with hard_negative: true)

Create a Dashboard titled: Fastlane USP (<run_name>) including:

Metrics: total pairs, hard negatives

Pie: hard negative share

Time series: hard negatives over time

Top terms (horizontal bar): most confusing queries by qid

Histograms: score distribution (all vs hard negatives)

Run health: counts over time, p95 elapsed_sec

Tables: runs; hard negatives

9) Hybrid mode (ELSER)

Set SHORTLIST_MODE=hybrid and CREATE_DATA_INDEX=true (to add semantic_text).

The script calls:

es.inference.put(task_type="sparse_embedding", inference_id=..., service="elser", ...)

waits for model deployment (best-effort, with timeout).

If your cluster lacks ELSER or permission, the step will fail — switch to bm25 or enable inference.

10) Operational tips
10.1 Performance & sizing

Increase BATCH_SIZE to reduce _msearch round trips (e.g., 200–500) if your cluster can handle it.

Tune TOPK depending on downstream needs; higher K = more pairs stored.

For large datasets, consider:

Dedicated index templates & ILM policies

refresh=False during bulk, then manual refresh at end (already done in code)

Throttle ingestion with smaller bulks if you hit 429s

10.2 Idempotency & cleanup

Pairs / Runs indexes are deleted and re-created on each run (by design).

If you set CREATE_DATA_INDEX=true, the Data index is deleted and re-created.

To fully reset a run, just re-run with the same RUN_NAME or change RUN_NAME to start fresh.